# Study notes



## Search purpose, choice, and human intelligence

> Search concerns choices made while exploring or solving problems. Different strategies can produce poor, adequate, or optimal paths from a start position s to a goal position g. Because planning involves evaluating alternatives and their consequences, search is relevant both to problem-solving procedures and to modeling aspects of human intelligence.

### Search as a model of choice

Maps clearly illustrate search, but search should not be equated with maps. The same kinds of choices can arise while exploring other domains, including problem solving in humanities courses. The central principle is that search is about choice.

**Start and goal positions**

```latex
s \to g
```

Search strategies can produce paths from a start position s to a goal position g.

### Different qualities of search

- A thief’s strategy illustrates a very poor path.
- An honest beginner finds a reasonably good but nonoptimal path.
- A highly expert strategy illustrates an optimal path.
- The depicted traversals represent the driver’s thoughts about possible routes, not necessarily literal movement through the map.

### Search and human intelligence

Search is presented as relevant both to problem-solving procedures and to understanding aspects of human cognition. When people make plans, they evaluate multiple possible choices and assess how those choices may work, including their consequences or effectiveness. The lecture treats planning as evidence that modeling human thought may require modeling search.

- Intelligent systems frequently require search-like procedures.
- Human visual problem solving is important to intelligence, but the lecture does not provide a theory of how visual systems find good paths.
- People can often find a good path visually within seconds, but the lecture does not explain the mechanism behind this ability.
- Programs lack eyes and visually grounded algorithms, so algorithmic search must use other procedures.

Lecture reference: 0:09–8:35, 35:14–43:17

## Exhaustive and uninformed search methods

> Exhaustive search explores every possible path, while depth-first search follows one branch at a time and breadth-first search develops the search tree level by level. Backtracking can help depth-first search recover from dead ends, but its status as part of depth-first search varies by textbook and is optional in this course.

### Exhaustive search and the British Museum approach

The British Museum approach exhaustively finds every possible path rather than saving work through selective exploration. It expands a complete tree of possible paths from the start node, so cleverness cannot save much work. Search trees are developed in lexical order, with child nodes listed alphabetically as a convention for quizzes.

**Path conventions and graph**

- Paths cannot revisit a node already on the current path; they cannot “bite their own tail.”
- The illustrated graph has start node s, intermediate nodes a, b, c, d, and e, and goal node g.
- From s, the available choices are a and b.

**Complete simple paths**

The complete simple paths described are:

s → a → b → c → e
s → a → d → g
s → b → a → d → g
s → b → c → e

The expansion follows lexical order: from s, consider a before b; from a, consider b before d; and from b, consider a before c.

### Depth-first search and backtracking

Depth-first search proceeds single-mindedly down one branch, choosing the left branch first by convention. From s, it initially selects a. The lecture introduces this as a different, non-exhaustive search behavior from the British Museum approach.

**Backtracking after a dead end**

1. Choose a branch and continue down it.
2. When the path reaches a dead end, return to the most recent point where an alternative branch was available.
3. Select the alternative branch and continue the search.

**Example**

Starting from s, a search chooses a, then b, followed by c and e, reaching a dead end. It backs up to the choice between b and d, selects d, and reaches g via s,a,d,g.

**Scope of backtracking**

> The process is also called backup or backtracking. Backtracking is generally useful with depth-first search, since depth-first search may descend along one branch and miss a branch leading to the goal. It is not relevant to exhaustive search such as the British Museum algorithm, because that search must find everything rather than stop after finding one path. Whether backtracking is considered part of depth-first search varies across textbooks; in this course it is treated as an optional add-on, and search problems will specify whether it should be used.

### Breadth-first search

Breadth-first search builds the search tree level by level and identifies a goal when scanning a level reveals a completed path to that goal. From s, the initial expansions include s to a or b; subsequent expansions include a to b or d and b to a or c.

**Level-by-level example**

At the next level, the paths include b to c, d to g, a to d, and c to e. Scanning this level finds g. With the starting position moved to the middle, breadth-first search finds a shorter path because the goal is nearby, but it spends much of its search looking far to the left.

**Search effort and path quality**

- Breadth-first search can retain a large and rapidly growing set of paths while constructing successive levels.
- Breadth-first search may spend substantial effort exploring directions that a person would not choose, even when a shorter path is nearby.
- The lecture distinguishes finding a path from finding an optimal path; optimal paths are not addressed in this segment, which focuses on heuristic or reasonably good paths.
- The lecture notes that stopping immediately upon encountering a goal is an implementation detail to be addressed separately.

Lecture reference: 0:09–8:35, 8:35–16:54

## Search implementation, queueing, and repeated-expansion control

> A general search maintains a queue of paths under consideration. Depth-first and breadth-first search use the same basic procedure but differ in whether newly generated paths are placed at the front or back of the queue. A list of previously expanded final nodes prevents repeated expansion of the same node.

### General queue-based search

The algorithm begins by initializing a queue of paths under consideration. Paths can be represented as list-like expressions, with the initial queue containing the one-node path s. The procedure removes the first path, checks whether it is a winning path, and, if not, extends it. Extending s produces the paths s,a and s,b, which are then placed back onto the queue.

**Initial and extended paths**

```latex
[s] \rightarrow [s,a], [s,b]
```

The initial queue contains s; extending it produces the paths s,a and s,b.

### Depth-first and breadth-first queue placement

- Depth-first Search places newly generated path extensions at the front of the queue, so the search continues with recently generated paths and plunges deeper into the tree.
- Breadth-first Search uses the same algorithm but places newly generated path extensions at the back of the queue.
- Paths already waiting in the queue remain valid possibilities while newly generated paths are processed first in Depth-first Search.
- Backtracking is not used with Breadth-first Search because it provides no benefit there.

Depth-first Search repeatedly removes the front path, checks whether it reaches the goal, extends it if possible, and places the resulting paths at the front of the queue. A failed path may have no extensions, producing a dead end and shortening the queue. The transcript ends while contrasting possible queue placement for Depth-first Search.

**Queue illustration**

The queue may contain paths such as s,a,b, s,a,d, and s,b. Depth-first processing takes s,a,b, extends it to s,a,b,c, and continues processing newly generated paths before older alternatives.

### Avoiding repeated expansion

The basic search algorithm is wasteful because it can expand multiple paths that terminate at the same node, even when that node was already expanded through another path. The algorithm also cannot determine whether a path is getting closer to or farther from the goal.

1. Maintain a list of nodes that have already served as the last node of an expanded path.
2. Remove the first path on the queue and check whether its final node has previously been expanded.
3. Expand the path only if its final node is not already on the list.
4. When expansion occurs, record the final node and place the resulting paths according to the selected search strategy.
5. Do not expand another path terminating at a node that has already been expanded, because doing so wastes time.

**Effect of the optimization**

> The filtering optimization helps both Depth-first Search and Breadth-first Search. In one illustration, the unfiltered search places 103 paths back on the queue; adding the expanded-node filter produces substantially fewer paths and reaches the result much faster. The lecture identifies repeated expansions involving paths reaching nodes such as a, b, and c, where equivalent destination nodes had already been expanded.

**Qualification**

> According to the lecture, the optimization does not help the British Museum algorithm.

Lecture reference: 8:35–16:54, 16:54–27:03

## Hill Climbing and informed-search classification

> Hill Climbing is an informed search method that prefers paths whose estimated distance to the goal is smallest. It resembles Depth-first Search because new paths are added to the front of the queue, but it orders those paths using heuristic distance. In the example, this reduces enqueueings from 48 to 23, although the method is not necessarily optimal and can be misled by a heuristic.

### From uninformed to informed search

Basic Breadth-first and Depth-first searches may explore in directions that appear to move away from the goal. A more informed strategy uses heuristic information about whether a candidate node seems to be getting closer. British Museum Search, Depth-first Search, and Breadth-first Search are described as uninformed because they do not use this information. Hill Climbing is informed because it uses estimated distance to the goal.

**Classification and availability**

- A heuristic can reduce search effort when numerical distance information is available.
- Heuristic distance information is not always available in a problem.
- Hill Climbing cannot be used when the problem provides no heuristic measurement of distance to the goal.

### How Hill Climbing chooses paths

Hill Climbing follows the currently available path that appears closest to the goal rather than following the ordinary Depth-first choice. It is presented as analogous to Depth-first Search, but with heuristic distance used to choose among paths. New paths are added to the front of the queue, and the paths being added are ordered by heuristic distance. The path with the minimum estimated distance appears first; this is summarized as Hill Climbing being front-sorted.

**Tie-breaking and measurement**

- Children are listed lexically beneath their parent node.
- When heuristic values tie, lexical order breaks the tie in the supplied example.
- The lecture emphasizes using numerical distance values rather than judging distances visually from the drawing.
- The supplied material also describes Hill Climbing as like Depth-first Search with a different rule for resolving ties; the span introducing the replacement rule ends before stating it.

### Graph example

From s, b is estimated to be closer to the goal than a, so Hill Climbing chooses b instead of taking the Depth-first route through a. When a and c are equally distant, lexical order resolves the tie. The available route then continues through d to the goal. The selected path proceeds directly to the goal without backtracking in this example.

**Qualification**

> The lack of backtracking is not a general guarantee; it is an artifact of this particular example. Hill Climbing does not necessarily produce an optimal or best path.

### Search effort and misleading heuristics

**Demonstrated search effort**

- Depth-first Search: 48 enqueueings.
- Hill Climbing: 23 enqueueings.
- Hill Climbing with the extended-list filter: 23 enqueueings, because the search was already proceeding directly toward the goal.

A heuristic can be misleading. A path that appears to approach the goal may lead into a blind alley, such as the noted modification involving e. In the discussed search classification, Hill Climbing uses backtracking and an enqueued list while also using heuristic information.

### Queue implementation and Beam Search

Hill Climbing can be implemented by changing the ordering used when adding new paths to the queue. Paths are added to the front, as in Hill Climbing, but are ordered by heuristic distance so that the minimum estimated distance is first. The lecture begins to ask how Beam Search modifies this mechanism, but the supplied material ends before that explanation is completed.

Lecture reference: 16:54–27:03, 27:03–35:14

## Beam Search and Best-first Search

> Beam Search combines breadth-first exploration with heuristic selection by retaining only a fixed number of the most promising paths at each level. Best-first Search repeatedly expands the leaf node that appears easiest or closest to the goal, allowing movement among different branches.

### Beam Search

Beam Search is presented as the heuristic counterpart or complement to Breadth-first Search, just as Hill Climbing is analogous to Depth-first Search. It begins like Breadth-first Search but limits the paths considered at each level to a small, fixed beam width. The basic breadth-first queueing mechanism is modified so that only the best-scoring paths are retained.

**Key properties**

- Only the w best candidates are retained at each level.
- With beam width two, only the two paths estimated to be closest to the goal are kept.
- Paths outside the selected beam are trimmed and are not continued.
- Beam Search avoids breadth-first exploration toward locations estimated to be farther from the goal.
- The locations where candidates are added to the queue do not matter if the algorithm ultimately retains only the w best candidates.

**Example**

With a beam width of two, the paths at one level are b, c, a, and d. The two estimated to be closest to the goal, b and d, are retained while the others are discarded. Expanding b and d produces c and g at the next level, where g is the goal.

### Best-first Search

Best-first Search repeatedly expands the leaf node judged easiest or closest to the goal. It can move between different branches of a tree rather than completing one path before considering others, including within an AND/OR search tree.

**Example**

In an integration program, the system can skip among different parts of an AND/OR tree because it continually selects the easiest remaining problem.

### Relationship among the search methods

- Beam Search starts from breadth-first exploration and restricts each level to a fixed beam of the most promising paths.
- Best-first Search repeatedly selects and expands the leaf node that appears closest to the goal.
- Depth-first, Breadth-first, Best-first, and Beam Search are identified as basic search methods.

Lecture reference: 27:03–35:14, 35:14–43:17

## Hill Climbing in continuous spaces

> Hill climbing in continuous spaces samples nearby directions and repeatedly moves in the direction that appears to increase the objective most. Local geometry can cause it to stop at a local maximum, make no progress on a flat region, or move downhill on every sampled cardinal direction even when an uphill diagonal path exists.

### Basic method

A simple continuous-space method samples steps in four compass directions, chooses the direction that moves upward most, and repeats the process. The lecture compares this to a hiker in fog who samples north, east, south, and west, selects the direction with the greatest apparent ascent, and continues climbing.

### Failure modes caused by local geometry

- A local maximum can stop the algorithm before it reaches the global maximum.
- A flat region, called the telephone-pole problem in the lecture, provides no direction that appears better, so local directional testing cannot make progress.
- A narrow ridge can fool the algorithm: every sampled cardinal direction may descend even though movement along a diagonal ridge would continue upward.

The ridge problem is especially acute in high-dimensional spaces. The lecture illustrates it in two dimensions with a contour map and a ridge along the 45-degree line. A flat shoulder on Mount Washington provides an intuitive analogy for why local directional climbing can fail.

Lecture reference: 35:14–43:17

## Genesis Story Understanding and Knowledge Representation

> Genesis can process stories in relatively natural English through Story Workbench, while balancing simplified prose against annotated adult prose. It represents commonsense and reflective knowledge, builds an elaboration graph, and identifies concepts such as revenge and Pyrrhic victory by matching their descriptions against graph patterns.

### Processing English Stories

Story Workbench makes English available to the Genesis system. The systems were connected so that Genesis could work with stories expressed in relatively natural English. A Macbeth story serves as a stylized example for question answering, including the question of why Macduff killed Macbeth.

**Two approaches to natural-language input**

- Rewrite a story into simple English so that the system can process it.
- Annotate more natural adult prose so that the system can process it.

### Knowledge Representation

The system represents knowledge in English, including commonsense knowledge such as the consequence that a person who is killed is dead. It also represents reflective knowledge: knowledge about concepts such as revenge.

While processing background knowledge and Macbeth, the system builds an elaboration graph. Higher-level concepts can emerge from explicitly stated information combined with conclusions produced by simple if/then rules.

### Recognizing Revenge and Pyrrhic Victory

The system identifies concepts by matching descriptions of those concepts against patterns instantiated in the elaboration graph. To detect revenge, it searches the graph for a pattern matching its description of revenge. In Macbeth, the system identifies revenge by finding such a pattern.

Pyrrhic victory is harder to detect but can also be found through graph search. It is a result that initially appears successful but ultimately produces a damaging outcome. Macbeth wants to become king and eventually succeeds, but he is later killed as a consequence; the system identifies this as a Pyrrhic victory.

Lecture reference: 35:14–43:17, 43:17–48:27

## Genesis question answering and language output

> Once concepts are identified, Genesis can report them in English and answer questions by examining connections in its goal tree. Common-sense explanations inspect local connections, while reflective explanations report on searches that generated information and on higher-level thoughts about the system’s own thoughts. English generation depends on connecting language output to a parser operating in reverse.

### How Genesis answers questions

For common-sense explanations, the system looks locally at connected elements in the goal tree. It can associate an incident with categories such as mistake, Pyrrhic victory, and revenge.

**Two explanation modes**

- Common-sense explanations: inspect locally connected elements in the goal tree.
- Reflective explanations: report on searches that generated information and identify higher-level thoughts about the system’s own thoughts.

### Examples of generated explanations

For why Macduff killed Macbeth, the system reports that Macbeth angered Macduff and connects the event with mistake, Pyrrhic victory, and revenge.

For why Macbeth murdered Duncan, the relevant common-sense explanation is that Macbeth wanted to become king while Duncan was king.

### English generation and limitations

The system’s ability to generate English answers depends on connecting language output to a parser operating in reverse. The demonstrated English generation became possible only after a recent change connecting language output to the parser system. The lecturer presents this capability as newly developed and previously unavailable for demonstration.

**Qualification**

> The generated speech output is characterized as technically useful but stylistically poor. The system does not answer a question if the input is misspelled.

Lecture reference: 43:17–48:27

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 4: Search: Depth-First, Hill Climbing, Beam. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=j1H3jAAGlEA) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-4-search-depth-first-hill-climbing-beam/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
