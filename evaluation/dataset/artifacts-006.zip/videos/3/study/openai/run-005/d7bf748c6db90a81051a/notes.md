# Study notes



## Search foundations and pathfinding

> Search is presented as a recurring topic in computer science and as a model of processes involved in human thinking. It concerns the choices made while exploring possibilities and making decisions. Maps illustrate these choices, but the same kinds of search can occur in other domains.

### Search as choice

The lecture emphasizes intuition and broader applications rather than only formal procedures. Search is about choosing among possibilities while exploring and making decisions; maps are only the illustrative setting. The lecture may later apply search ideas to problem-solving in a humanities class.

- Search is a recurring topic in computer science.
- The same kinds of search choices can arise when exploring things other than geographic maps.
- Programs generally lack eyes and visually grounded algorithms, so they require other methods for exploring possible solutions.

### Paths from a starting position to a goal

A map-pathfinding scenario compares routes from a starting position s to a goal position g. Different search behaviors can produce different paths, ranging from poor to optimal. The paths associated with the driver figures represent their thoughts or search choices, not necessarily literal traversal.

- A thief's search produces a very poor path.
- An honest beginner finds a fairly good path, but not necessarily the optimal one.
- A highly experienced physics researcher is used as an illustration of an optimal path.

**Limits of the visual analogy**

> Human visual problem-solving is important to overall intelligence, but the lecturer states that the mechanisms behind visually finding a good path are not yet understood well enough to explain here.

Lecture reference: 0:09–8:35

## Exhaustive search and lexical ordering

> The British Museum approach exhaustively expands every possible path from the starting position. Search trees are developed in lexical order, and a path cannot revisit a location already on that path.

### Exhaustive search

The British Museum approach finds every possible path from the starting position without relying on clever shortcuts, because all paths must be retained. The result is an exhaustive expansion of the search tree.

> Because the method must find everything, being clever cannot save much work.

### Lexical ordering and path restrictions

- The search begins at s, with outgoing choices listed in lexical order for orderly tree construction.
- The children beneath s are listed alphabetically.
- The same ordering convention is used when expanding subsequent nodes.
- When expanding a node, paths are not allowed to revisit a location already on that path; searches cannot “bite their own tail.”
- This ordering is identified as an explicit quiz requirement.

### Initial expansion and complete paths

The initial expansion is s → a or s → b. From a, the choices are b and d; from b, the choices are a and c. Paths that would return to a node already on the current path are excluded.

```text
s-a-b-c-e
s-a-d-g
s-b-a-d-g
s-b-c-e
```

These are the complete paths described by the exhaustive search.

Lecture reference: 0:09–8:35

## Depth-first search and backtracking

> Depth-first search follows one branch deeply, conventionally taking the left branch first. Backtracking returns to the most recent decision point after a dead end and selects an alternative branch. The lecture treats backtracking as an optional addition to depth-first search rather than an inherent part of it.

### Depth-first search

Depth-first search proceeds down one branch in a single-minded way, using the left branch first by convention. From s, the available choices are a and b, so the first move is from s to a.

**Search process**

1. Remove the front path from the queue.
2. Check whether the path reaches the goal.
3. If it does not reach the goal and can be extended, generate the resulting paths.
4. Place newly generated paths at the front of the queue.
5. Continue until a path reaches the goal.

**Queue behavior**

The queue retains other valid paths while newly generated extensions are inserted ahead of them. The illustrated queue evolves through paths such as `s, a, b`, `s, a, d`, and `s, b`; extensions are repeatedly placed before paths already waiting in the queue. A path that reaches a dead end is removed without adding extensions.

### Backtracking through an alternative branch

Backtracking recovers from a dead end by returning to the most recent decision point and selecting an alternative branch. In the example, the search follows a branch from s through a, c, and e, reaches a dead end, then backs up to the choice between b and d. It chooses the alternative branch and reaches the goal by the route `s → a → d → g`.

**Depth-first search and backtracking**

- Depth-first search follows a branch deeply, with the left branch taken first by convention.
- Backtracking returns to a recent decision point after a dead end and selects another branch.
- Backtracking is useful with depth-first search because a deep branch can miss a different branch leading to the goal.
- Backtracking is not relevant to a search that must find everything, because such a search cannot stop after finding one path.
- The lecture treats backtracking as an optional add-on rather than an inherent part of depth-first search; a search problem should specify whether it is required.

Lecture reference: 0:09–8:35, 8:35–16:54, 16:54–27:03

## Breadth-first search and comparative behavior

> Breadth-first Search constructs a search tree level by level. It uses the same procedure as Depth-first Search, but inserts newly generated paths at the back of the queue. Both methods can find paths, while their speed and apparent quality depend on the search structure and starting position.

### Level-by-level construction

From s, the initial alternatives are a and b. Breadth-first Search then examines the resulting paths level by level. In the listed search, scanning a later level finds g through d → g.

- From s, the initial alternatives are a and b.
- The next level includes a → b, a → d, b → a, and b → c.
- A subsequent level includes b → c, d → g, a → d, and c → e; scanning this level finds g.

### Queue insertion and implementation

Breadth-first Search changes only where newly generated paths are inserted: they go at the back of the queue. The implementation therefore requires replacing or changing one queue-insertion line, rather than restarting the overall algorithm design.

> Whether the implementation stops immediately upon encountering a goal is an implementation detail.

### Efficiency and path quality

Breadth-first Search may retain substantial growth in the set of paths under consideration. A demonstration generates many paths and is described as slow in that case. The basic versions are inefficient and do not inherently assess whether a path is moving closer to the goal.

The resulting path is not assumed to be the best path. The lecture postpones discussion of optimal paths and instead refers to reasonably good or heuristic paths.

### Effect of the starting position

- With the original starting position, Breadth-first Search scans levels until it finds the goal in the level containing the completed goal path.
- When the starting position is moved to the middle, the goal is nearby and Breadth-first Search finds a shorter path, but it still spends substantial effort searching to the left.
- The lecture characterizes this behavior as inefficient from a human perspective, while emphasizing that it follows the search procedure.

### Breadth-first and depth-first search

- Both Depth-first and Breadth-first Search can find paths.
- Breadth-first Search constructs the search tree level by level.
- Breadth-first Search places newly generated paths at the back of the queue, whereas the stated distinction from Depth-first Search concerns where those paths are inserted.
- Their speed and apparent quality depend on the search structure and starting position.

Lecture reference: 8:35–16:54, 16:54–27:03

## Queue-based search implementation and repeated-node filtering

> Search strategies use a queue of candidate paths. They differ in how newly generated paths are placed in that queue. Repeated-node filtering avoids extending paths whose final nodes have already been expanded, reducing the queue and speeding up Depth-first and Breadth-first Search, but not the British Museum algorithm.

### Queue-based search process

The algorithm begins by initializing a queue of candidate paths. A path can be represented as a list-like structure; initially, the queue contains the one-node path s. The algorithm removes the first path, checks whether it is a winning path, and, if it is not, extends it.

**Example**

Initial queue: [s]

Extend s: [s → a, s → b]

Check whether the removed path is a winner. If not, add the extended paths to the queue.

### Placement of newly generated paths

**Depth-first Search and Breadth-first Search**

- For Depth-first Search, newly generated paths should remain the focus so the search can continue plunging down the newly explored branch; the transcript ends while considering exactly where they should be placed.
- Backtracking is not used with Breadth-first Search because it provides no benefit there.

Different search strategies can therefore be expressed using a queue of paths under consideration, while their implementations differ in how newly generated paths are placed in that queue.

### Repeated-node filtering

**Filtering process**

1. Maintain a list of nodes already used as the final node of an extended path.
2. Extend a path only if its final node has never previously been the final node of an expanded path.
3. If another path terminates at a node already on the list, do not extend it again.

**Effect on the search**

The unfiltered search is wasteful because it extends paths whose final nodes have already been expanded through other paths. The filter reduces the number of paths placed on the queue and speeds up both Depth-first and Breadth-first Search. This optimization does not improve the British Museum algorithm.

**Illustrated result**

Without the repeated-node filter, the illustrated search placed 103 paths on the queue. Adding the filter produced a much smaller search and reached the result more quickly.

Lecture reference: 8:35–16:54, 16:54–27:03

## Hill Climbing Search and heuristic guidance

> Hill Climbing is an informed search that favors available paths appearing closer to the goal, using heuristic distance rather than ordinary Depth-first ordering. It can reduce search effort when the heuristic is useful, but it is not guaranteed to find an optimal path and may enter a blind alley.

### Heuristic guidance

British Museum Search, Depth-first Search, and Breadth-first Search are characterized as uninformed because they do not use heuristic information about distance to the goal. Hill Climbing uses this additional information to choose between nodes that appear to make better progress.

- Basic Depth-first and Breadth-first Search may explore away from the goal even when a more promising direction is visible.
- When heuristic information is available, following paths that appear closer to the goal will often reduce search effort.
- If a problem provides no useful measurement of distance to the goal, Hill Climbing cannot use this strategy.
- A misleading heuristic can lead the search into a blind alley.
- The availability of a heuristic depends on the problem; maps and other problems may not provide a usable distance-to-goal measure.

### Selection rule and example

Hill Climbing is described as like Depth-first Search, but with a different rule for breaking ties instead of lexical order. Nodes beneath a parent are still listed lexically, while the search selects the node with the smaller estimated distance to the goal. When paths are equally distant, lexical order breaks the tie. The precise tie-breaking rule is introduced but not completed in this lecture span.

- In the discussed graph, b is selected over a because b is six units from the goal while a is about seven or more units away.
- Later, a and c are equally distant, so lexical order determines the choice.
- The example reaches the goal without backtracking, but this absence of backtracking is specific to that example and is not guaranteed in general.
- The search is not guaranteed to produce an optimal or best path.

### Queue behavior and search results

Search behavior can be changed by modifying how newly generated paths are inserted into the queue. For Hill Climbing, newly generated paths are added to the front. These paths are sorted using heuristic distance, with the minimum-distance path placed first if desired. This produces a front-sorted queue. Hill Climbing can also use backtracking and an enqueued-list mechanism while using heuristic distance information.

- Depth-first Search: 48 enqueueings in the demonstrated case.
- Hill Climbing: 23 enqueueings in the demonstrated case.
- Extended-list filter: It does not reduce the Hill Climbing result below 23 because the search is already proceeding directly toward the goal.

> The lecture begins to ask how the queueing mechanism should be adapted for Beam Search, but the supplied span ends before that mechanism is specified.

Lecture reference: 16:54–27:03, 27:03–35:14

## Beam Search and Best-first Search

> Beam Search is an informed modification of Breadth-first Search that retains only the w best candidate paths at each level. Best-first Search repeatedly expands the leaf that appears closest to the goal, allowing the search to move between distant parts of the tree.

### Beam Search

Beam Search begins like Breadth-first Search, but at each level it keeps only a small fixed number of paths, called the beam width. A heuristic estimates which retained paths are closest to the goal. Paths outside the beam are trimmed and are not considered further at that level.

- The beam width is the fixed number of paths retained at each level.
- The retained paths are those estimated by the heuristic to be closest to the goal.
- The locations where new nodes are added to the queue do not matter if the algorithm ultimately keeps only the w best candidates.
- Beam Search is described as adding heuristic information to Breadth-first Search, in contrast with Hill Climbing's relationship to Depth-first Search.

**Illustrated run with beam width two**

1. The search initially proceeds like Breadth-first Search.
2. At the next level, paths labeled b, c, a, and d are considered.
3. The search retains b and d because they are judged closest to the goal.
4. Expanding b and d produces c and g, after which the goal is found.

Compared with ordinary Breadth-first Search in the illustrated run, Beam Search does not explore paths going left toward locations judged farther from the goal because those paths are excluded by the beam limit.

### Best-first Search

Best-first Search operates on a tree whose paths terminate in leaves. It repeatedly selects and expands the leaf estimated to be closest to the goal. Unlike a search that completes one path before considering others, Best-first Search can move between distant parts of the tree.

**Illustrated application**

An integration program illustrated Best-first Search by repeatedly selecting the easiest problem in an AND/OR search tree.

### Contrast between the methods

- Beam Search limits the number of retained paths at each level to a fixed beam width; Best-first Search repeatedly chooses the leaf that appears closest to the goal.
- Beam Search proceeds level by level like Breadth-first Search, while Best-first Search can move between distant parts of the tree.
- Beam Search trims paths outside the beam; Best-first Search selects the currently most promising leaf for expansion.

Lecture reference: 27:03–35:14, 35:14–43:17

## Hill Climbing in Continuous Spaces and Failure Modes

> In continuous spaces, Hill Climbing samples nearby directions, moves toward the direction with the greatest apparent increase in elevation, and repeats. It can fail on local maxima, flat regions, and ridges where all sampled directions descend even though a higher path exists.

### Basic strategy

A continuous-space Hill Climbing algorithm can be modeled as navigating mountainous terrain in fog. At each step, it samples nearby compass directions, evaluates their apparent elevation, moves in the direction that increases elevation most effectively, and repeats the process.

**Sampled directions**

- North
- East
- West
- South

### Failure on local maxima and flat regions

Hill Climbing may work well in some spaces, but its success depends on the structure of the search space. A local maximum can trap the algorithm even though a higher point exists elsewhere.

**Flat-region failure**

> Flat regions provide no useful direction for choosing the next move. The lecture describes this as the telephone-pole problem and relates it to broad, flat areas on the shoulders of Mt. Washington, where local directional checks would not guide someone toward the summit.

### The ridge problem

In a contour-map example, a sharp ridge runs along the 45-degree line. At a point on the ridge, movement north, south, east, or west crosses downward contour lines, even though movement along the ridge would continue upward.

**Why the algorithm is misled**

> Because all four sampled cardinal directions initially descend, the algorithm may be fooled into believing it is at the top rather than recognizing that movement along the diagonal ridge leads upward. This problem is especially acute in high-dimensional spaces.

Lecture reference: 35:14–43:17

## Search as a Model of Human Intelligence

> Modeling intelligent human behavior may require representing internal search processes. Planning provides evidence for this possibility because people evaluate multiple choices and consider how those choices might work.

### Search and planning

Search is presented as a component that may be needed to model intelligent human behavior, especially planning.

- Modeling intelligence may require representing internal search processes.
- When people make plans, they evaluate multiple choices and consider how those choices might work.
- Planning provides evidence for the possibility that human thought involves search.

Lecture reference: 35:14–43:17

## Genesis story representation and higher-level concept detection

> Genesis uses Story Workbench to process stories in English, combine explicit information with commonsense rules, and build an elaboration graph. It searches that graph for descriptive patterns representing higher-level concepts such as revenge and Pyrrhic victory.

### Story representation and question answering

The Genesis system uses Story Workbench to make English available for processing. A Macbeth story provides an example for question answering, including the question of why Macduff killed Macbeth. The story representation is somewhat stylized English, although stylized language is not inherently required. Genesis can work with stories expressed in relatively natural English.

**Representing stories in English**

- Rewriting a plot into simplified English can make interpretation easier.
- Annotating more natural adult English can preserve a more natural form of expression.
- The systems have been connected so Genesis can process stories expressed in relatively natural English.

### Knowledge and elaboration graphs

Genesis expresses stories, commonsense knowledge, and higher-level reflective knowledge in English. It combines explicitly stated information with conclusions produced by simple if/then rules. For example, commonsense knowledge includes the implication that if someone kills a person, that person is dead.

**Processing a story**

1. Genesis uses background knowledge and the Macbeth story as input.
2. It builds an elaboration graph from that information.
3. It searches the graph for patterns corresponding to higher-level concepts.

### Detecting revenge and Pyrrhic victory

Reflective knowledge concerns concepts and relations such as the meaning of revenge. A concept is detected when its descriptive pattern is sufficiently instantiated in the elaboration graph. Genesis recognizes revenge in Macbeth by matching the story’s graph against a description of what revenge is.

**Concepts identified in Macbeth**

- Revenge is found by searching for the revenge pattern in the elaboration graph.
- Pyrrhic victory is more difficult to detect but is nevertheless identified.
- Macbeth’s pursuit of kingship followed by his eventual death is identified as a Pyrrhic victory: an apparent success whose consequences make the outcome unfavorable.

Lecture reference: 35:14–43:17, 43:17–48:27

## Genesis question answering and language generation

> Once Genesis detects higher-level concepts, it can report them in English and answer questions by examining relationships in its goal and elaboration graphs. English output depends on connecting language generation to a parser operating in reverse, and the resulting speech is described as awkward.

### Answering through graph relationships

Genesis produces common-sense answers by looking locally at connections in a goal tree. For reflective-level answers, it reports on the searches that generated information and identifies higher-level thoughts in which the relevant incident appears.

- The system can relate an event to multiple concepts, including mistake, Pyrrhic victory, and revenge.
- The generated speech demonstrates the capability even though its output is described as awkward.

### Examples of Genesis answers

For the question of why Macduff killed Macbeth, the system links the event to Macduff’s anger toward Macbeth and to the concepts of mistake, Pyrrhic victory, and revenge. For why Macbeth murdered Duncan, the relevant common-sense explanation is that Macbeth wanted to become king while Duncan was king.

### Language-generation connection

The system’s ability to produce English answers depends on connecting language output to a parser operating in reverse to generate language from the system’s internal representations. This language-generation connection was described as a recent modification enabled by a parser system running in reverse, making the demonstrated English responses newly possible within the lecturer’s development timeline.

- The system is insensitive to capitalization.
- Questions must be correctly spelled.

Lecture reference: 43:17–48:27

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 4: Search: Depth-First, Hill Climbing, Beam. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=j1H3jAAGlEA) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-4-search-depth-first-hill-climbing-beam/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
