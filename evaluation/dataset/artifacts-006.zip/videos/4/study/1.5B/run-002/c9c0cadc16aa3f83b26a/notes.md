# Study notes



## Shortest Path Problem

> The shortest path problem is a fundamental concept in graph theory with various applications in navigation and routing.

### Initialization

**1. **Initialization**: Start at node S with a distance of 0.**

- Start at the source node S with an initial distance of 0.

Lecture reference: 0:08–7:20, 7:20–15:22, 15:22–24:24, 24:26–33:37, 33:42–42:28, 42:28–48:22

## Admissible Heuristic

> A heuristic function is admissible if it never overestimates the cost to reach the goal from a given node.

### Key Characteristics

**Never overestimates the cost.**

- 1. The heuristic function does not exceed the actual cost.
- 2. It provides a safe estimate of the remaining distance to the goal.

**Properties**

- 1. It guarantees reaching the goal without revisiting nodes.
- 2. It is always reliable in determining the shortest path.

Lecture reference: 33:42–42:28

## The Dead Horse Principle

> A heuristic is consistent if the estimated cost from any point to the goal is less than or equal to the actual cost from that point to the goal plus the estimated cost from the goal to the goal. This principle ensures that once a path is expanded, no future path through a dead horse (non-optimal path) can improve the estimate further. It guarantees optimality in A* search by preventing the overestimation of costs.

### Key Considerations

**Eliminate non-optimal paths**

- Paths that cannot possibly be optimal.

### Ensure each node is only expanded once for efficiency

**Ensure each node is only expanded once for efficiency**

- Example: Adjusting an algorithm to find a more efficient path.
- It's crucial for A* to have a consistent heuristic to guarantee optimality.

Lecture reference: 24:26–33:37, 42:28–48:22

## Heuristic Heistics: Pathological Cases

> Pathological cases occur when heuristics lead the search astray due to computational constraints.

### Bullets

**Exponential growth in search space can cause the algorithm to become inefficient.**

- Exponential search in large datasets leads to high computational costs.

**Computational limits can further exacerbate inefficiencies.**

- The complexity of the heuristic function itself can lead to unnecessary computations.

**Resource constraints such as memory and processing power can limit the effectiveness of he**

- time

**The heuristic may not always guide the search accurately.**

- incorrectly

**This phenomenon can lead to longer execution times for algorithms requiring extensive look**

- sions.

**It is a known limitation of heuristic search algorithms.**

- class of search algorithms.

**In practice, this can result in suboptimal solutions being returned.**

- inefficient results.

**This effect can be more pronounced in certain problem domains.**

- where the heuristic does not provide meaningful guidance.

**The phenomenon is also known to affect the convergence of certain heuristic-based algo**

- rithms.

**In some cases, this can even lead to incorrect conclusions being drawn.**

- incorrect results.

**This behavior is often referred to as the **

- pathological behavior

**effect**

- of heuristics

Lecture reference: 42:28–48:22

## Optimality

> A* is an optimal search algorithm, meaning it finds the shortest path to the goal from any given node.

### Optimality

**A* is an optimal search algorithm, meaning it finds the shortest path to the goal from any**

- given node.

Lecture reference: 33:42–42:28

## Heuristic Function

> A heuristic function estimates the cost from a given node to the goal.

### Key Definition

**A heuristic function estimates the cost from a given node to the goal.**

- A heuristic function estimates the cost from a given node to the goal.
- In the example, the heuristic is an underestimate of the actual distance to the goal.

Lecture reference: 33:42–42:28

## Efficiency of A* Algorithm

> The A* algorithm efficiently finds the shortest path by prioritizing promising nodes and combining branch-and-bound with an admissible heuristic, making it highly effective in various applications including video games, robotics, and route planning.

### Efficiency Overview

**By Prioritizing Promising Nodes**

- Picks nodes that are most likely to lead to the goal
- Combines branch-and-bound with an admissible heuristic for optimal performance

Lecture reference: 33:42–42:28

## Branch-and-Bound

> A search algorithm that explores nodes by expanding the most promising ones first, prioritizing nodes with the lowest estimated total cost.

### Definition

**Branch-and-bound is a search algorithm that expands the most promising ones first, priorit**

- Branch-and-bound is a search algorithm that explores nodes by expanding the most promising ones first, prioritizing nodes with the lowest estimated total cost.

Lecture reference: 33:42–42:28

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
