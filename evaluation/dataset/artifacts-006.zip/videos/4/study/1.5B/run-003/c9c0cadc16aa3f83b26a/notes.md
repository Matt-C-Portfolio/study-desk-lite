# Study notes



## General Heuristics

> A heuristic function estimates the shortest path between two points using straight-line distance.

### Definition

**h = 	ext{straight-line distance between two points}
    
    Note: This is an example of a**

```latex
	ext{straight-line distance between two points}
    
    Note: This is an example of a
```

h = 	ext{straight-line distance between two points}
    
    Note: This is an example of a

### Calculated as crow flies distance between nodes.

**h = 	ext{straight-line distance between two nodes}
    
    Note: This is an example of a**

```latex
	ext{straight-line distance between two nodes}
    
    Note: This is an example of a
```

h = 	ext{straight-line distance between two nodes}
    
    Note: This is an example of a

Lecture reference: 0:08–7:20, 33:42–42:28

## A* and Admissible Heuristics

> A* is a pathfinding algorithm that efficiently finds the shortest path in a weighted graph. Admissible heuristics are estimates of the remaining path cost to the goal that do not exceed the actual cost.

### The Dead Horse Principle

**The Dead Horse Principle**

- Continuing a path that does not lead to the destination to avoid redundant work.

### The Airline Distance Heuristic

**The Airline Distance Heuristic**

- Estimating the remaining distance to the goal using actual airline distances, providing a lower bound for the path length.

Lecture reference: 24:26–33:37

## Shortest Path Algorithms

> A heuristic-based algorithm for finding the shortest path in a graph, efficient and avoids exhaustive search by guiding the search towards the goal.

### Always Extend the Shortest Path

**Always extend the shortest path so far and check if it reaches the goal.**

- This approach always extends the shortest path found so far to explore adjacent nodes.
- If this new path reaches the goal, it is the shortest path in the graph.

**Use a Suitable Heuristic**

- A heuristic function estimates the cost to reach the goal from the current node.
- This estimation helps guide the search towards the goal more efficiently.

**Stop When a Path Meets or Exceeds the Heuristic's Estimate**

- If a path's estimated cost is equal to or exceeds the heuristic's estimate.
- It indicates that this path is either optimal or has been found.

Lecture reference: 7:20–15:22

## Solving the Branch Inbound Problem

> Finding the shortest path in a graph using an algorithm that processes paths through a queueing list and an extended list to avoid redundancy.

### Queueing List

**Queueing List - Processes paths to find the shortest one.**

- Processes paths to find the shortest one.

Lecture reference: 15:22–24:24

## Queueing List

> A queueing list processes paths to find the shortest one, but the N queueing list does not correctly prune paths.

### Queueing List - Processes paths to the goal.

**Queueing List - Processes paths to the goal.**

- Queueing list initializes paths to the goal.

Lecture reference: 15:22–24:24

## Extended List - Skips Redundant Work by Avoiding Paths Already Extended.

> An extended list avoids redundant work by skipping paths that have already been extended.

### Examples

**Extended list skips redundant work by avoiding paths already extended.**

- Extended list skips redundant work by avoiding paths already extended.

### Steps

**Avoiding redundant paths**

1. Avoiding redundant paths.
2. By selecting only the most relevant information.
3. This reduces unnecessary work.
4. Therefore, extended lists are a practical approach.

### Comparisons

**Extended list vs. Redundant work**

- Extended list: Skips redundant work by avoiding paths already extended.
- Redundant work: Repeats information that is already covered.

Lecture reference: 15:22–24:24

## Introduction

> MapQuest and its descendants are a family of pathfinding algorithms that extend the A* algorithm with heuristic functions to efficiently find optimal paths in large datasets, such as maps and graphs. They are particularly useful in real-world applications like route planning, robotics, and computer vision.

### Introduction

**1. Introduction**

- MapQuest and its descendants extend the A* algorithm with heuristic functions for efficient pathfinding.

**2. Heuristic Functions and Their Role**

- Heuristics guide search by estimating the cost from the current node to the goal, aiding in efficiency and optimality.
- laTeX{}: \text{Heuristics guide search by estimating the cost from the current node to the goal, aiding in efficiency and optimality.}

**3. Admissibility and Consistency**

- Admissibility ensures the algorithm doesn't overshoot the goal, while consistency prevents the algorithm from making suboptimal decisions based on inconsistent heuristic estimates.
- laTeX{}: \text{Admissibility ensures the algorithm doesn't overshoot the goal, while consistency prevents the algorithm from making suboptimal decisions based on inconsistent heuristic estimates.}

**4. Limitations of Heuristics**

- Heuristics can lead to suboptimal paths if their estimates are inaccurate.
- laTeX{}: \text{Heuristics can lead to suboptimal paths if their estimates are inaccurate.}

**5. Examples of MapQuest Algorithms**

- A pathfinding problem using MapQuest and its descendants.
- A real-world application of MapQuest algorithms.
- laTeX{}: \text{A pathfinding problem using MapQuest and its descendants.}

**6. S6:T1**

- Source ID for this topic.
- laTeX{}: \text{Source ID for this topic.}

**Examples**

- A pathfinding problem using MapQuest and its descendants.
- A real-world application of MapQuest algorithms.
- laTeX{}: \text{A pathfinding problem using MapQuest and its descendants.}

**Examples**

- A pathfinding problem using MapQuest and its descendants.
- A real-world application of MapQuest algorithms.
- laTeX{}: \text{A pathfinding problem using MapQuest and its descendants.}

**Examples**

- A pathfinding problem using MapQuest and its descendants.
- A real-world application of MapQuest algorithms.
- laTeX{}: \text{A pathfinding problem using MapQuest and its descendants.}

**Examples**

- A pathfinding problem using MapQuest and its descendants.
- A real-world application of MapQuest algorithms.
- laTeX{}: \text{A pathfinding problem using MapQuest and its descendants.}

**Examples**

- A pathfinding problem using MapQuest and its descendants.
- A real-world application of MapQuest algorithms.
- laTeX{}: \text{A pathfinding problem using MapQuest and its descendants.}

**Examples**

- A pathfinding problem using MapQuest and its descendants.
- A real-world application of MapQuest algorithms.
- laTeX{}: \text{A pathfinding problem using MapQuest and its descendants.}

Lecture reference: 42:28–48:22

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
