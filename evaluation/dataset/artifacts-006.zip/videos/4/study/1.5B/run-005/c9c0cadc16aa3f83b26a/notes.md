# Study notes



## Shortest Path Calculation

> The shortest path from S to G was determined by examining all possible paths and calculating their heuristic distances. The path S-A-D-G was identified as the shortest with a total distance of 11. This method involves using heuristic distances to estimate the cost from the current node to the goal, ensuring an efficient and accurate solution.

### Listed all possible paths from S to G.

**Listed all possible paths from S to G.**

- S-A-B-C-G
- S-A-D-G
- S-E-F-G

Lecture reference: 0:08–7:20

## Algorithm Overview

> This algorithm focuses on extending the shortest path until the goal is reached, optimizing for efficiency over traditional methods.

### Computational Complexity

**Computational Complexity: O(n^2)**

```latex
\text{Computational Complexity: O(n^2)}
```

The time complexity of this algorithm is O(n^2), where n is the number of nodes in the graph.

### Example

**The example provided uses a graph with nodes S, A, B, C, D, E, and the goal is at E.**

The example provided uses a graph with nodes S, A, B, C, D, E, and the goal is at E.

Lecture reference: 7:20–15:22

## BFS Algorithm

> A queue-based algorithm for traversing graphs, exploring all nodes level by level to find the shortest path to a goal node.

### Introduces the concept of a queue for managing paths and path extensions.

**Explains the importance of path extension to avoid redundant work.**

- Path extension is essential to prevent revisiting nodes and ensuring that each node is processed only once.
- This prevents the algorithm from getting stuck in loops and allows it to efficiently explore all possible paths.

**Discusses the trade-offs between N queued and extended lists.**

- If a node is enqueued multiple times, it can lead to increased memory usage.
- It can also slow down the algorithm as it processes the same node multiple times.
- This can result in inefficiencies in finding the shortest path.

**Emphasizes the need for an extended list to maintain optimality.**

- The extended list (also called a frontier) keeps track of all the nodes that need to be processed.
- This ensures that the shortest path is found without unnecessary expansions.
- Without this, the algorithm may get stuck or take longer to converge.

Lecture reference: 15:22–24:24

## Extended List

> The extended list reduces the number of extensions needed to go from S to B, achieving a substantial saving.

### Examples

**Extended List**

- The extended list reduces the number of extensions needed to go from S to B, achieving a substantial saving.

### Step-by-Step Process

**Step-by-Step**

1. 1. Identify the source list of extensions needed to go from S to B.
2. 2. Extend the list by including additional extensions.
3. 3. Evaluate the impact of the extended list on the final outcome.
4. 4. Compare the results with the original list to identify any savings.
5. 5. Implement the extended list if it achieves the desired outcome.
6. 6. Document the process and results for future reference.

Lecture reference: 24:26–33:37

## Efficient Search Algorithms

> The method uses lower bounds and admissible heuristics to guide the search efficiently.

### Lower Bounds

**Lower Bounds**

- static
- dynamic

### Admissible Heuristics

**Admissible Heuristics**

- consistency
- monotonicity

### Efficiency

**Efficiency**

- Ensures optimal solutions without overestimating the cost

Lecture reference: 24:26–33:37

## Admissible Heuristics Reduce Extensions

> Admissible heuristics ensure that the heuristic estimate is always optimistic, thereby reducing the number of extensions in A* search.

### The number of extensions is reduced when an admissible heuristic is used

**The number of extensions is reduced when an admissible heuristic is used**

- The number of extensions is reduced when an admissible heuristic is used.
- Admissible heuristics ensure that the heuristic estimate is always optimistic.

### Admissible heuristics ensure that the heuristic estimate is always optimistic.

**Admissible heuristics ensure that the heuristic estimate is always optimistic.**

- Admissible heuristics ensure that the heuristic estimate is always optimistic.
- Admissible heuristics ensure that the heuristic estimate is always optimistic.

Lecture reference: 33:42–42:28

## Importance of Admissibility in Heuristics

> Admissibility of heuristic functions is crucial for the correctness and efficiency of A* search.

### Definition

**A heuristic function is admissible if it never overestimates the actual distance to the ****

- the actual distance to the goal.

### Ensures Correctness

**Ensures no incorrect pruning of nodes.**

- no incorrect pruning of nodes.

Lecture reference: 33:42–42:28

## Pathological Cases in A*

> A* can fail due to improper heuristic design.

### Examples

**1**

- A heuristic function that overestimates the cost to reach the goal can cause A* to prematurely prune nodes.
- A heuristic function that underestimates the cost to reach the goal can lead to infinite loops.
- A heuristic function that is not consistent or monotonic can cause A* to fail.

Lecture reference: 33:42–42:28

## Heuristics in Pathfinding

> Heuristics play a crucial role in efficient pathfinding algorithms, particularly in problems like the shortest path problem. An admissible heuristic ensures that the estimated distance to the goal is never greater than the actual distance, which is essential for the A* algorithm. However, it may not guarantee optimality. A consistent heuristic, which satisfies the triangle inequality, is a stronger condition and ensures optimality.

### Admissible Heuristics

**An admissible heuristic ensures that the estimated distance to the goal is never greater.**

- the actual distance.

### Consistent Heuristics

**A consistent heuristic ensures optimality.**

- when the heuristic satisfies the triangle inequality.

Lecture reference: 42:28–48:22

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
