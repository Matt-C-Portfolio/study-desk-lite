# Study notes



## Search Algorithms and Techniques

> Heuristic distance is used in search algorithms like hill climbing and beam search to guide the search process efficiently. By extending the shortest available path at each step, the algorithm finds the shortest path without needing an Oracle, provided edge weights are non-negative. An extended list tracks processed nodes to optimize the search. Pruning paths that cannot be the shortest path and using admissible and consistent heuristics further enhance efficiency and optimality. A* combines branch and bound, extended list, and admissible heuristic for efficient and optimal search.

### Key Concepts

**Heuristic Distance and Search Optimization**

- Heuristic distance helps in pruning the search space by evaluating which paths are more promising.
- Example: Node E is close to G but is a dead end, highlighting that proximity alone isn't sufficient.
- Hill climbing selects the next node that brings it closer to the goal.
- Beam search uses heuristic values to evaluate and keep only the top candidates.
- Always extend the shortest path available.
- No need for Oracle if edge weights are non-negative.
- Example demonstrated with a tree structure.
- Start from the root node (S).
- Choose the shortest initial path (S to A with length 3).
- Extend the shortest available path iteratively.

### Path Evaluation and Pruning

**Path Extension and Pruning**

- Check all paths to ensure no shorter path exists after reaching the goal.
- Initializes a queue with paths to explore.
- Extends the first path in the queue if it doesn't reach the goal.
- Maintains an 'extended list' to track nodes already processed, avoiding redundant extensions.
- Prunes paths that have already been extended, saving computational effort.
- Reduces the number of paths examined by skipping those already processed.
- Improves efficiency by focusing only on the most promising paths.
- Example demonstrated in the lecture shows significant reduction in path extensions.
- Eliminate paths once they are determined to be non-optimal.
- Reduces unnecessary extensions and improves efficiency.

### Heuristics and Optimization

**Heuristics in Search Algorithms**

- Provides a lower bound on the distance.
- Helps in prioritizing paths with shorter potential distances.
- Tends to be more efficient in certain problem setups.
- Can reduce the number of extensions significantly.
- Used to break ties in path selection.
- Example: Choosing path S->B over S->D when both have the same lower bound.
- Branch and bound provides a framework for exploring paths.
- Extended list prioritizes paths based on estimated cost.
- Admissible heuristic ensures optimality by underestimating costs.
- Branch and bound alone: 57 extensions.

### Efficiency and Optimality

**Efficiency and Consistency**

- With admissible heuristic: 6 extensions.
- Combining both in A*: 27 extensions.
- Graph with nodes S, A, B, C, G.
- Heuristic estimates: A=100, B=0, C=0.
- Actual distances: S-A=1, A-C=1, C-G=10; S-B=1, B-C=1, C-G=10.
- A* correctly selects the optimal path despite heuristic inconsistency.
- Inconsistent heuristics may lead to exploring more nodes.
- Consistency ensures heuristic doesn't decrease faster than actual cost.
- Efficiency and optimality are balanced with consistent heuristics.
- Definition: Heuristic estimate ≤ actual distance.

Lecture reference: 0:08–7:20, 7:20–15:22, 15:22–24:24, 24:26–33:37, 33:42–42:28, 42:28–48:22

## Pathfinding and Shortest Path Verification

> Verifying the shortest path involves systematically exploring all potential alternatives to ensure accuracy. This process is crucial in real-world applications, such as route optimization, where even a small miscalculation can lead to significant inefficiencies. The example of Juana's suggested path S-A-D-G with a total distance of 11 highlights the importance of thorough verification. Systematic approaches like Dijkstra's algorithm provide reliable solutions by evaluating all possible routes, ensuring optimal results in complex networks.

### Verification Process

**Key Considerations**

- Example: Juana's suggested path S-A-D-G with a total distance of 11 needs verification.
- Importance of systematic approaches like Dijkstra's algorithm in real-life applications.

Lecture reference: 0:08–7:20

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
