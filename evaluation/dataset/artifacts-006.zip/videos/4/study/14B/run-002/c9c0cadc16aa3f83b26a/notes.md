# Study notes



## Historical Context

> The historical development of transportation infrastructure in the United States, particularly the role of Route 66 and the Interstate system, highlights the impact of military and economic priorities on road networks. Eisenhower's Interstate system, inspired by the German Autobahn, replaced Route 66 as the primary highway, illustrating how infrastructure decisions shape transportation systems.

### Key Points

**Historical Overview**

- Route 66 was the main highway between Chicago and Los Angeles
- Interstate system created by Eisenhower for military purposes
- Example of how infrastructure decisions impact transportation systems

Lecture reference: 0:08–7:20

## Algorithms: Heuristic Distance and Shortest Path Verification

> The lecture introduces the concept of heuristic distance and demonstrates how to verify the shortest path using a map example. The professor emphasizes the importance of checking all possible paths to ensure the shortest one is correct. The algorithm extends the shortest path found so far until the goal is reached, comparing path lengths to determine the shortest extension. The process terminates when all other paths are longer than the shortest path found. An algorithm that explores the shortest path first, extending it and marking nodes as extended to avoid redundant work. An optimization technique that tracks nodes already extended to avoid revisiting them, improving efficiency. A* (AStar

### Explanation

**Heuristic Distance and Shortest Path**

Heuristic distance is used to estimate the shortest path. The algorithm extends the shortest path available and maintains an extended list to track nodes that have been processed. Nodes are marked as extended to avoid redundant exploration. Non-negative path lengths guarantee an optimal solution. The process terminates when all other paths are longer than the shortest path found. Branch and bound forms the base, extended list prioritizes paths, and admissible heuristic guides towards the goal. Extended lists help manage state space, and admissible or consistent heuristics enhance performance. Failure to use proper heuristics can lead to computationally expensive solutions.

### Examples

**Example Path**

Example path suggested by Juana: S -> A -> D -> G with total distance 11.

### Steps

**Shortest Path Algorithm Steps**

1. Extend the shortest path found so far until the goal is reached.
2. Always extend the shortest path available.
3. Accumulated path lengths are tracked.
4. Path S-A has length 3.
5. Path S-B has length 5.
6. Path S-A-B has length 7.
7. Path S-B-A and S-B-C have length 9.
8. Path S-A-B-C has length 11.
9. Path S-B-A-D has length 12.
10. Path S-B-C-E has length 15.

### Comparisons

**Algorithm Comparisons**

A* combines branch and bound, extended list, and admissible heuristic for efficient search. Using extended lists and appropriate heuristics can significantly improve the efficiency of pathfinding algorithms, avoiding exponential complexity.

Lecture reference: 0:08–7:20, 7:20–15:22, 15:22–24:24, 33:42–42:28, 42:28–48:22

## Optimizations

> Optimizations involve eliminating paths that cannot lead to the shortest path, thereby reducing computational effort. A heuristic that never overestimates the actual cost is used to provide a lower bound for the remaining distance, making the process more efficient. This method resulted in fewer path extensions, as demonstrated by the reduction from 835 to 38 in the example. The effectiveness of this approach may vary depending on the specific problem.

### Key Concepts

- Prune paths that cannot lead to the shortest path
- Reduces the number of extensions needed
- Airline distance example used as a heuristic
- Helps in pruning paths effectively
- Compared with the extended list method
- Reduced extensions from 835 to 38
- More efficient than admissible heuristic in the given case
- Effectiveness may vary depending on the problem

Lecture reference: 24:26–33:37

## Heuristics and Methods

> Admissible heuristics never overestimate the actual distance to the goal, while consistent heuristics ensure the estimated difference between nodes does not exceed the actual distance. Admissible heuristics are useful but not sufficient for all cases, whereas consistent heuristics ensure optimal pathfinding in non-map environments.

### Admissible Heuristics

**Key Points**

- Definition: Heuristic ≤ actual distance.
- Example: Estimate of 100 vs actual distance of 2 (inadmissible).
- Limitation: Fails in non-map scenarios.

### Consistent Heuristics

**Key Points**

- Definition: |h(X) - h(Y)| ≤ actual distance(X,Y).
- Importance: Ensures optimal pathfinding in non-map environments.
- Example: Correct heuristic estimate of 2 vs faulty 100.

Lecture reference: 42:28–48:22

## Admissible Heuristics

> Admissible heuristics, while optimal in theory, can lead to practical issues in non-Euclidean spaces. They may underestimate actual distances, resulting in suboptimal paths. An example demonstrates how these heuristics can fail when assumptions about the search space are incorrect.

### Key Characteristics

**Key Points**

- Always underestimate actual distance.
- Can lead to suboptimal paths if not accurate.
- Example demonstrates heuristic pitfalls.

Lecture reference: 33:42–42:28

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
