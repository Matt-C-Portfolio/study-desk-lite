# Study notes



## Interstate Highway System

> The Interstate Highway System was established under President Eisenhower to enhance military logistics and rapid deployment of nuclear weapons, drawing inspiration from the German Autobahn. This system revolutionized transportation in the United States, creating a standardized, efficient network of highways that continues to serve as a backbone for modern travel.

### Overview

The Interstate Highway System is one of the most significant infrastructure projects in U.S. history, designed to connect major cities and facilitate the rapid movement of goods, people, and military resources across the country. Its creation was driven by the need for improved defense capabilities during the Cold War era, as well as the growing demand for reliable transportation infrastructure in a rapidly industrializing nation.

### Purpose and Design

The system was designed with several key objectives in mind, including the efficient movement of military convoys, the evacuation of urban populations in case of nuclear attack, and the promotion of interstate commerce and tourism.

- Created for rapid movement of nuclear weapons.
- Inspired by the German Autobahn's efficiency.
- Resulted in a modern highway system.

### Inspiration and Legacy

The design of the Interstate Highway System drew heavily from the German Autobahn, which was known for its high-speed, limited-access highways. Eisenhower's experience during World War II highlighted the importance of robust transportation networks for military logistics, which influenced the system's development.

### Outcome

The Interstate Highway System fundamentally transformed American transportation, creating a standardized network of highways that remain a critical component of the nation's infrastructure. Its impact extends beyond military logistics, playing a key role in the growth of suburban communities, the expansion of interstate commerce, and the evolution of American culture.

Lecture reference: 0:08–7:20

## Search Algorithms

> Heuristic distance is a critical component in guiding search algorithms to find optimal solutions efficiently. By extending the shortest path and maintaining candidate paths, the algorithm ensures correctness in non-negative weight graphs. The example of S → A → D → G with a total distance of 11 demonstrates the practical application of these principles.

### Key Concepts

**Heuristic Distance and Search Algorithms**

- Heuristic distance is the straight-line distance between two points.
- Used to evaluate potential paths in search algorithms.
- Example: Pink lines on the map representing heuristic distances.
- Involves maintaining a set of candidate paths.
- Selects paths with the best heuristic estimates for further exploration.
- Example: Keeping nodes D and B while rejecting A and C based on heuristic distance.
- Path: S → A → D → G.
- Total distance: 11 units.
- Importance of verifying solutions to ensure accuracy.
- Always extend the shortest accumulated path.

### Examples

**Example Paths and Distances**

- Path: S, A, D, G.
- Distance: 11.

Lecture reference: 0:08–7:20, 7:20–15:22

## Pruning and Optimization in Search

> Pruning and optimization in search involve systematically exploring paths while prioritizing shorter ones and avoiding redundant work. By eliminating paths that cannot lead to the optimal solution early in the process, computational resources are saved, improving algorithm efficiency. This approach involves initializing a queue, testing paths, extending them, and using an extended list to track explored nodes. The process efficiently manages a large number of paths and reduces unnecessary explorations, ensuring optimal resource utilization.

### Process Overview

**Search Process Steps**

1. Initialize a queue with the first path.
2. Test if the first path leads to the goal; if so, the algorithm stops.
3. Extend the first path by adding neighboring nodes and put them back into the queue.
4. Process 1,354 paths in the queue and extend 835,000 paths.
5. Use an extended list to track nodes that have been fully explored to avoid redundant work.
6. Prune the search space by ignoring longer paths to nodes already extended.
7. Prune paths that cannot lead to the optimal solution.
8. Improve algorithm efficiency by reducing unnecessary explorations.

Lecture reference: 15:22–24:24, 24:26–33:37

## Heuristics in Search

> Heuristics in search algorithms provide estimates to guide the search towards the goal efficiently. Admissible heuristics offer a lower bound on the cost to reach the goal, ensuring optimality but not necessarily the optimal path. Consistency ensures that the heuristic's estimated cost differences align with actual distances, crucial for optimal pathfinding in non-metric spaces.

### Admissible Heuristics

**Key Points**

- Examples include airline distances as a heuristic
- Helps in efficiently pruning paths
- Can significantly reduce the number of extensions needed
- Admissible heuristics are necessary but not sufficient for optimal performance.

### Consistency

**Key Points**

- Example given where an admissible heuristic fails to find the shortest path.
- Mathematical condition for consistency: |h(X) - h(Y)| ≤ cost(X, Y).
- Consistency is a stronger condition than admissibility.
- Example demonstrates that a consistent heuristic leads to the correct optimal path.
- Failure to use a consistent heuristic can result in missing the optimal path.
- Consistency ensures the heuristic guides the search correctly without premature termination.

**Consistency Condition**

```latex
$|h(X) - h(Y)| \leq \text{cost}(X, Y)$
```

The mathematical condition for consistency ensures the heuristic's estimate difference does not exceed the actual cost between nodes.

Lecture reference: 24:26–33:37, 42:28–48:22

## Search Techniques and Tools

> Search techniques vary in efficiency and effectiveness depending on the problem context. While they may require more computational resources, they offer a systematic approach to problem-solving. The use of tools like extended lists can enhance performance, but no single method fits all scenarios. Understanding these trade-offs and leveraging available tools is crucial for optimizing search processes.

### Key Considerations

**Search Techniques Overview**

- May require more computational resources
- Offers a different approach to pathfinding
- Has limitations such as node extension frequency
- Performance can differ based on problem specifics
- Testing different starting points can reveal varying results
- No one-size-fits-all solution; method choice depends on context
- Extended list helps manage the search process more efficiently.
- Importance of leveraging all available tools to enhance search performance.

Lecture reference: 24:26–33:37, 42:28–48:22

## A* Algorithm and Its Components

> The A* algorithm efficiently combines branch-and-bound, extended list, and admissible heuristic techniques to achieve optimal search results. By integrating these components, A* significantly reduces the number of state extensions compared to using individual methods alone.

### Components and Efficiency

**Efficiency Comparison**

- Branch-and-bound alone required **57 extensions** to complete the search.
- Admissible heuristic alone reduced the extensions to **6**.
- Combining branch-and-bound with an extended list further optimized the process, resulting in **27 extensions**.

Lecture reference: 33:42–42:28

## Pathological Cases and Heuristic Issues

> Even admissible heuristics can lead to suboptimal paths in certain non-Euclidean spaces due to heuristic optimism and inconsistency.

### Example Graph

**Graph Structure**

- Nodes: S, A, B, C, G
- Edge costs: S-A=1, A-C=100, C-G=1, S-B=100, B-G=100
- Heuristics: h(S)=100, h(A)=100, h(B)=0, h(C)=0

### Heuristic Optimism

**Heuristic Behavior**

- Admissible heuristics never overestimate the actual cost.
- Heuristic optimism can mislead the search if not consistent.

### Impact on A*

**Algorithm Behavior**

- A* prioritizes nodes with lower f(n) = g(n) + h(n).
- Inconsistent heuristics can cause A* to choose longer paths despite admissibility.

Lecture reference: 33:42–42:28

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
