# Study notes



## Heuristic Concepts

> Heuristics are estimated distances used to guide search algorithms, providing efficiency but with limitations in non-Euclidean spaces. They must never overestimate costs and may require consistency for optimal performance.

### Heuristic Distance

**Key Concepts**

- Estimate of the straight-line distance between two points.
- Guides algorithms like hill climbing and beam search.
- Helps in pruning paths that cannot improve the current best solution.
- Admissible heuristics guarantee estimates ≤ actual cost.

### Admissible Heuristics

**Properties and Limitations**

- Never overestimates the cost to the goal.
- Ensures estimates are always less than or equal to actual costs.
- May fail in non-geometric problems due to space constraints.

### Consistent Heuristics

**Stronger Conditions**

- Heuristic difference between nodes ≤ actual cost between them.
- Ensures correct node ordering in certain algorithms.

### Examples and Pitfalls

**Scenarios and Limitations**

- Heuristic overestimation in non-map scenarios.
- Inconsistent heuristics leading to incorrect paths.
- Dependence on problem space accuracy.

Lecture reference: 0:08–7:20, 24:26–33:37, 33:42–42:28, 42:28–48:22

## Search Algorithm Fundamentals

> Search algorithms efficiently find the shortest path using heuristic information. They extend the shortest path found so far, prioritize shorter paths, and stop when the shortest path is found or all other paths are longer. Key algorithms include Hill climbing and Beam search, with systematic exploration and verification crucial for accuracy.

### Algorithm Approach

**Steps**

- Initialize a queue with paths to explore.
- Process the first path in the queue.
- Extend the path if it hasn't been extended before.
- Keep track of nodes that have been extended.
- Prune paths leading to nodes already in the extended list.
- Reduce the number of paths that need to be explored.

### Key Components

**Features**

- Hill climbing: Focuses on moving towards the goal.
- Beam search: Prioritizes paths with lower heuristic distance.
- Verification is crucial to ensure the shortest path.
- Maintains a list of extended nodes to avoid redundant path exploration.
- Starts with the shortest path (e.g., S to A with length 3).
- Extends it further (e.g., S-A-B with length 7).
- Compares with other paths (e.g., S-B with length 5).
- Compares lengths of all available paths.
- Extends the shortest one first.
- Repeats until the goal is reached.

### Verification Process

**Verification Steps**

- Once the goal is reached, verify other paths.
- Ensure no shorter path exists.
- This guarantees the shortest path is found.

Lecture reference: 0:08–7:20, 7:20–15:22, 15:22–24:24

## A* Algorithm Components

> The A* algorithm efficiently finds the shortest path by integrating branch and bound, a priority queue, and an admissible heuristic. The heuristic guides the search towards the goal, reducing the number of explored nodes.

### Branch and Bound

**Branch and Bound**

Branch and bound is a method that systematically explores the search space while pruning branches that cannot lead to a better solution than the current best. This ensures optimality by avoiding unnecessary explorations of suboptimal paths.

### Priority Queue (Extended List)

**Priority Queue**

A priority queue, or extended list, manages the nodes to be explored next, ordered by their priority. Nodes with lower priority (lower f-value) are explored first, ensuring efficient search.

### Admissible Heuristic

**Admissible Heuristic**

An admissible heuristic function estimates the cost from the current node to the goal without overestimating the actual cost. This ensures that the algorithm is both optimal and efficient.

### Example Graph

**Example Graph**

Consider a graph with nodes S, A, B, C, and G. Distances from S are 1 to A, B, C, and 100 to G. Heuristics are S=100, A=0, B=0, C=0. The algorithm prioritizes nodes based on f(n) = g(n) + h(n).

### Algorithm Workflow

**Algorithm Workflow**

1. Initialize the priority queue with the start node S.
2. While the queue is not empty:
3.   Extract the node with the lowest f-value.
4.   If the node is the goal, return the path.
5.   Explore the node's neighbors, calculate their f-values, and add them to the queue.

Lecture reference: 33:42–42:28

## Efficiency and Pruning Techniques

> Pruning techniques, such as branch-and-bound combined with extended lists and admissible heuristics, significantly enhance search efficiency by eliminating non-optimal paths early. The extended list method demonstrated greater efficiency in specific cases, though effectiveness varies depending on the problem. Admissible heuristics are crucial for guiding the search towards optimal solutions without unnecessary computations.

### Key Benefits

**Efficiency Gains**

- Reduces unnecessary computations by pruning non-optimal paths early.
- Improves efficiency by eliminating paths that cannot be optimal.
- Extended list method required 835 extensions in the given example.
- Admissible heuristic method required only 38 extensions.
- Extended list method was more efficient in specific cases.
- Effectiveness may vary depending on the problem.
- Branch-and-bound with extended lists.
- Use of admissible or consistent heuristics.

### Examples

**Pathological Cases**

> Pathological cases can lead to inefficiency in pruning techniques, highlighting the importance of problem-specific heuristics.

Lecture reference: 24:26–33:37, 42:28–48:22

## Verification of Path S → A → D → G

> The suggested path S → A → D → G with a total distance of 11 requires verification to ensure it is the shortest route. This involves checking each segment's distance and confirming no shorter alternative exists.

### Path Analysis

**Path Details**

- Path: S → A → D → G
- Total distance: 11
- Verification is necessary to confirm the shortest path

Lecture reference: 0:08–7:20

## Algorithm Comparison and Optimization

> A* algorithm demonstrates superior efficiency in pathfinding compared to basic branch and bound techniques by significantly reducing unnecessary explorations. The comparison highlights the importance of heuristic functions in optimizing search algorithms.

### Algorithm Performance Comparison

**Algorithm Extensions Comparison**

- Basic branch and bound: 57 extensions.
- With admissible heuristic: 6 extensions.
- Combining both: 35 extensions.
- A*: 27 extensions.

Lecture reference: 33:42–42:28

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
