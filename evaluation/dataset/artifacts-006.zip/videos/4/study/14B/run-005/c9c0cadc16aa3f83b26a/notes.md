# Study notes



## Historical Context of Highway Systems

> President Eisenhower created the Interstate highway system for defense purposes, inspired by the German autobahn's efficiency in troop movement. Route 66, while significant, was eventually replaced by the Interstate system. The development of the Interstate system was driven by defense needs, including the movement of nuclear weapons, and drew lessons from the success of the German autobahn during WWII.

### Key Points

- Route 66 was a significant highway but was replaced by the Interstate system.
- Eisenhower's motivation included defense needs, such as moving nuclear weapons.
- The Interstate system's development was influenced by the German autobahn's success during WWII.

Lecture reference: 0:08–7:20

## Shortest Path Problem

> The shortest path problem involves finding the minimum distance between nodes in a graph. Algorithms like Dijkstra's and A* use heuristics and extended lists to optimize the search. Admissible and consistent heuristics ensure optimality, but challenges arise in non-map scenarios. The problem is fundamental in AI and algorithm design, with applications in pathfinding and optimization.

### Key Concepts

**Heuristics in Pathfinding**

- Heuristic distance refers to the straight-line distance between two points, regardless of actual paths.
- Hill climbing and beam search algorithms use heuristic distance to guide pathfinding.
- Example: S, A, D, G path with a total distance of 11.
- Extend the shortest path at each step.
- Accumulate path lengths.
- Ensure all other paths are checked to confirm they are not shorter.
- Greedy approach for efficiency.
- Starting from node S.
- Choose the shortest initial path (S-A with length 3).
- Extend paths from A (S-A-B and S-A-D).

### Algorithm Process

**Steps in the Algorithm**

- Continue extending the shortest available path.
- Reach the goal through S-A-D-C with a total length of 11.
- Check other paths to ensure no shorter route exists.
- Extend S-B-A to D (total length 12).
- Extend S-B-C to E (total length 15).
- Confirm all other paths are longer than the goal path.
- Ensure the shortest path is found.
- Zero-length edges may affect outcomes.
- Non-negative edge lengths ensure correctness.
- No need for Oracle if edge lengths are known.

### Optimization Techniques

**Extended List and Pruning**

- Initializes a queue with paths to explore.
- Tests the first path; if it reaches the goal, the algorithm stops.
- If not, extends the path and adds new paths to the queue.
- Maintains an extended list to track nodes already explored.
- Prunes paths leading to nodes already extended with shorter routes.
- Reduces redundant work and computational effort.
- Avoids revisiting nodes with longer paths than already found.
- Significantly reduces computational effort.
- Ensures optimality by preventing redundant exploration.
- Optimizations reduce but do not eliminate computational load.

### Heuristic Types

**Admissible vs Consistent Heuristics**

- Definition: Heuristic estimate ≤ actual distance.
- Works for map-based problems but fails in others.
- Example: Heuristic estimate of 100 vs actual distance of 2.
- Definition: |h(X) - h(Y)| ≤ actual distance(X, Y).
- Ensures reliability in non-map problems.
- Example: Heuristic estimate of 2 vs actual distance of 2.
- Need for extended lists to optimize.
- Admissible heuristics may fail in non-map cases.
- Consistent heuristics guarantee optimal paths.
- Practical applications like MapQuest.

### Examples

**Example Scenarios**

- Example 1: Classroom example where the extended list helps skip paths leading to nodes already extended with shorter routes.
- Example 2: Cambridge example (not detailed in the lecture).
- Without extended list: 835,000 paths extended.
- With extended list: Fewer extensions required.
- The lecture's example still required significant processing time.

Lecture reference: 0:08–7:20, 7:20–15:22, 15:22–24:24, 24:26–33:37, 33:42–42:28, 42:28–48:22

## Verification of Solutions

> Verifying solutions is essential to ensure accuracy, especially when relying on external sources or algorithms. This process involves careful examination and cross-checking to avoid errors and confirm the validity of proposed solutions.

### Importance of Verification

**Key Considerations**

- Juana's suggested path (S, A, D, G) is treated with caution and verified for accuracy.
- The importance of cross-checking solutions is emphasized to avoid errors.

Lecture reference: 0:08–7:20

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
