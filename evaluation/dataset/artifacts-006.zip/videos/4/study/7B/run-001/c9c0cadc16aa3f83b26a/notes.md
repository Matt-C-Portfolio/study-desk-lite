# Study notes



## Introduction to Shortest Path Algorithms

> The lecture introduces the A* algorithm for finding the shortest path in a tree-like structure, prioritizing nodes closer to the goal.

### Heuristic-Based Approach

**Heuristic Function**

```python
The heuristic function estimates the cost from the current node to the goal (G). For example, h(A) = 5, h(B) = 3, h(D) = 2, h(G) = 0 (since it's the goal). This helps prioritize paths closer to the goal.
```

Heuristic function example: h(A) = 5, h(B) = 3, h(D) = 2, h(G) = 0 (goal).

Lecture reference: 0:08–7:20, 7:20–15:22, 15:22–24:24

## Heuristic and Search Techniques

> Heuristic-based methods efficiently find optimal paths by eliminating non-optimal routes early, using admissible and consistent heuristics to ensure accuracy.

### Eliminates Inefficient Paths Early

**Heuristic-Based Pruning**

```en
Reduces computational effort by removing paths that can't be optimal early in the search process, improving efficiency without sacrificing accuracy.
```

Using heuristic-based pruning optimizes the search process by eliminating non-optimal paths early, enhancing efficiency and reducing computational overhead.

### Reduces Computational Effort

**Extended List Pruning**

```en
Keeps track of all possible extensions to determine if a path can be pruned based on accumulated costs, though it can become memory-intensive.
```

Extended list pruning is more efficient in terms of computational resources but requires more memory to track all possible extensions.

**Heuristic-Based Pruning**

```en
Uses heuristic estimates to prune paths that can't possibly be optimal, making the search process more efficient and scalable.
```

Heuristic-based pruning is more efficient with fewer extensions compared to extended list pruning, making it preferable for large-scale problems.

### Admissible Heuristics

**Admissible Heuristic**

```en
An admissible heuristic ensures that the estimated cost never overestimates the actual cost, guaranteeing optimal pathfinding.
```

Admissible heuristics ensure that the estimated cost is always less than or equal to the actual cost, providing a reliable basis for pathfinding.

### Consistent Heuristics

**Consistent Heuristic**

```en
A consistent heuristic ensures that the estimated cost is within actual distances between nodes, enhancing accuracy and reliability.
```

Consistent heuristics provide accurate estimates relative to actual distances, ensuring that the search process is both efficient and reliable.

Lecture reference: 24:26–33:37, 42:28–48:22

## Branch and Bound

> Branch and bound is a method for solving optimization problems by systematically dividing them into smaller subproblems and pruning non-optimal branches to reduce the search space.

### Description

**Code Block**

```text
Branch and bound algorithm typically follows these steps:
1. Divide the problem into smaller subproblems.
2. Solve each subproblem optimally.
3. Prune subproblems that cannot yield a better solution than the current best.
4. Repeat until the optimal solution is found or all subproblems are exhausted.
```

Code example of branch and bound algorithm steps in pseudocode format.

### Admissible Heuristics

**Code Block**

```text
Admissible heuristics never overestimate the cost to reach the goal, ensuring optimal solutions are not missed.
```

Explanation of admissible heuristics in algorithm design.

### A* Algorithm

**Code Block**

```text
The A* algorithm combines branch and bound with admissible heuristics:
1. Use a priority queue to explore nodes based on f(n) = g(n) + h(n).
2. g(n) is the cost from the start to the current node.
3. h(n) is the heuristic estimate to the goal without overestimation.
```

Explanation of A* algorithm using admissible heuristics in pseudocode.

Lecture reference: 33:42–42:28

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
