# Study notes



## Shortest Path Algorithm

> The shortest path between two points is determined by summing the distances of the edges along the path, considering both actual and heuristic distances.

### Path Calculation

**Path Details**

- The shortest path from S to G is S-A-D-G with a total distance of 11.

### Distance Calculation

**Distance Components**

- This path is calculated by summing the distances between each consecutive node: S-A (3), A-D (4), and D-G (4).

### Alternative Path

**Other Paths**

- Other possible paths, such as S-C-F-G, have a longer total distance of 13, making S-A-D-G the shortest path.

### Heuristic Consideration

**Heuristic Distances**

- The heuristic distance, or the straight-line distance, from each node to G is considered, but the actual path follows the shortest route on the map.

### Importance of Heuristics

**Path Significance**

- This problem demonstrates the importance of considering both heuristic distances and actual path distances when determining the shortest route.

Lecture reference: 0:08–7:20

## Oracle Checking Algorithm

> Efficient shortest path algorithm for graphs with non-negative edge weights, prioritizing paths with the least accumulated distance.

### Principle of Operation

**Start at node S with distance 0.**

> Initialization begins at the starting node S with a distance of 0. This node is the beginning of all possible paths under consideration. From S, all adjacent nodes are evaluated to determine their tentative distances from S. The node with the smallest tentative distance is selected for exploration first, ensuring that the algorithm prioritizes the shortest paths first. This approach is akin to a priority queue mechanism, where the next node to explore is always the one with the least accumulated distance, similar to Dijkstra's algorithm. The algorithm systematically explores nodes, updating distances and adding new nodes to the priority queue based on the shortest path found so far. If a node has already been reached with a smaller distance, it is ignored to avoid unnecessary processing and cycles. The process continues until the goal node G is reached, guaranteeing that the shortest path is found. If the goal is not reached, the algorithm continues exploring all possible paths in the order of increasing distance, ensuring that all paths considered are shorter than those not yet explored. The algorithm's efficiency stems from its systematic approach, which avoids redundant or unnecessary explorations of longer paths. It is particularly effective in graphs where edge weights are non-negative, as negative weights could lead to incorrect shortest path calculations by allowing the 

Lecture reference: 7:20–15:22

## Branch-and-Bound Algorithm

> Efficiently solves optimization problems by systematically exploring nodes using a queue, guided by heuristics to reduce redundant work.

### Initialization

**Queue Initialization**

```en
Start by enqueuing the root node representing the initial state or starting point of the problem.
```

The algorithm begins with the root node in the queue, ready to explore possible paths.

### Node Processing

**Node Processing**

```en
For each node, generate its children (possible extensions) and check if they've been processed before to avoid redundancy.
```

Each node's children are generated, and only unprocessed nodes are enqueued to prevent revisiting and redundant work.

### Extended List

**Extended List**

```en
Use an extended list to track processed nodes, reducing the number of extensions and improving efficiency.
```

Maintaining a list of processed nodes ensures each path is explored only once, enhancing efficiency.

### Admissible Heuristic

**Admissible Heuristic**

```en
Apply an admissible heuristic to guide the search, prioritizing nodes likely to lead to the optimal solution.
```

Heuristics help prioritize nodes, reducing the number of extensions and leading to more efficient pathfinding.

### A-star Combination

**A-star Combination**

```en
Combine with A-star algorithm to use heuristics for prioritizing node exploration, enhancing efficiency.
```

Integration with A-star allows prioritization of paths, ensuring efficient exploration of the most promising routes.

Lecture reference: 15:22–24:24, 33:42–42:28

## Efficiency in Pathfinding Algorithms

> An efficient pathfinding algorithm prunes unnecessary paths using the dead horse principle and airline distances as lower bounds, resulting in reduced extensions and faster computation times compared to lower bound heuristics.

### Pruning Non-Winning Paths

**Dead Horse Principle**

> The algorithm employs the dead horse principle to discard paths that cannot be optimal, ensuring unnecessary exploration is minimized.

**Pseudocode Example**

````en
```plaintext
function findOptimalPath(graph, start, end):
    initialize queue with start node
    while queue not empty:
        current_node = dequeue()
        if current_node is end:
            return path
        for neighbor in graph.neighbors(current_node):
            if distance estimate < current path length:
                prune this neighbor
                enqueue neighbor
    return no path found
```
````

An example of how the algorithm might prune paths that cannot lead to the optimal solution.

Lecture reference: 24:26–33:37

## A-star Algorithm

> A-star is an optimized search algorithm combining branch and bound with an admissible heuristic to efficiently find the shortest path in weighted graphs.

### Algorithm Components

**Optimizations Over Branch and Bound**

- A-star is an optimized version of the branch and bound algorithm.

**Extended List for Path Tracking**

- It incorporates an extended list to keep track of the minimum path cost.

**Admissible Heuristic for Goal Guidance**

- An admissible heuristic is used to guide the search towards the goal.

### Examples

**Efficiency Demonstration**

- The lecture explains how A-star reduces the number of extensions to 27 compared to the initial 57.

**Path Finding Illustration**

- The professor uses an example to illustrate how A-star efficiently finds the shortest path.

### Source and Topic

**Source ID**

```

```

Source ID: S5

**Topic ID**

```

```

Topic ID: S5:T2

Lecture reference: 33:42–42:28

## Heuristic Functions

> Heuristic functions estimate distances to guide efficient pathfinding, with admissible and consistent heuristics ensuring optimal performance.

### Key Points

**Admissible Heuristic**

- Does not overestimate actual distance.

**Consistent Heuristic**

- Requires specific constraints between nodes.

**Example**

- Heuristic of 100 vs. 0 for nodes X and Y with actual distance 2.

**Admissible Heuristic Example**

- Estimating goal distance as 2 for node X.

**Conclusion**

- Both admissible and consistent heuristics are crucial for optimal performance in algorithms like A*.

Lecture reference: 42:28–48:22

## Understanding Heuristic Pitfalls

> Heuristics, while efficient, can lead to unexpected issues, especially in specific contexts.

### Introduction

**Key Points**

> Heuristics are valuable for efficiency but can cause problems if not validated in context. Admissible heuristics, which never overestimate, can still fail in specific scenarios due to misapplication or context-specific issues. Always validate heuristics thoroughly in their intended context to ensure reliability and effectiveness. Consider potential pitfalls in map constructions and other scenarios where heuristics may not perform as expected. Use heuristics cautiously, balancing efficiency with accuracy, and validate their reliability in specific contexts. Identify signs of problematic heuristics, such as consistent overestimation, to inform validation efforts. Balance heuristic development to minimize pitfalls while maintaining efficiency. Research guidelines for heuristic development to minimize risks while maximizing effectiveness. Consider creating context-specific heuristics to address unique challenges. Stay informed about heuristic advancements and limitations in your field. Use heuristics with caution, especially in complex or nuanced scenarios. Regularly evaluate and update heuristics based on new insights and experiences. Approach heuristic development with a focus on context and validation to ensure reliability and effectiveness in real-world applications. Always be aware of potential pitfalls and validate heuristics thoroughly in their intended context to ensure you

Lecture reference: 33:42–42:28

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
