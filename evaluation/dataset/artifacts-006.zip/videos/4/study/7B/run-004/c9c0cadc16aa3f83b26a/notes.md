# Study notes



## Historical Routes and Modern Solutions

> The shortest path concept evolved from Route 66 to modern interstates, reflecting technological advancements and efficiency needs.

### Route 66: A Historical Route

**Route 66 Overview**

- Route 66 was a major highway connecting Chicago to Los Angeles, serving as the shortest route during its time.

### Modern Interstates: An Evolution

**Interstate Advantages**

- Interstates offer more extensive networks, providing multiple routes and faster travel times.
- They are designed with considerations for efficient troop movements and reliability.

Lecture reference: 0:08–7:20

## Heuristic-Based Algorithms

> Heuristic-based algorithms, such as A*, use estimated costs (heuristics) to guide search towards the goal, balancing efficiency and optimality.

### Heuristic Distance

**Heuristic Function**

```en
h(n) = estimated cost from node n to goal, guiding search towards target while ensuring optimality if admissible and consistent are met.
```

Heuristic function h(n) is crucial for guiding the search in heuristic-based algorithms like A*.

Lecture reference: 0:08–7:20

## Verification of Solutions

> Always verify potential solutions, especially after intuition. Treat suggested answers as references but ensure thorough checking.

### Key Points

**Verification Process**

- Juana suggested the path S-A-D-G with a total length of 11.
- The professor verifies that no shorter path exists.
- Treat Juana as an Oracle but still verify her answer.

**Steps to Verify a Solution**

1. Evaluate alternative routes or methods to ensure no shorter path exists.
2. Cross-check calculations and logic to confirm accuracy.
3. Consider edge cases or variations in the problem setup.

### Important Considerations

**Verification Tips**

- Thoroughly review each step of the solution.
- Look for any assumptions that might affect the outcome.
- Compare with known results or theoretical expectations.

Lecture reference: 0:08–7:20

## Algorithmic Approach to Shortest Path

> An efficient method to find the shortest path in a graph involves prioritizing the exploration of the shortest known paths first, using a priority queue to manage the order of exploration, and applying heuristics to estimate remaining distances to guide the search effectively.

### Graph Representation

**Nodes and Edges**

```en
Nodes: S, A, B, C, D, E
Edges: Paths connecting the nodes with specific weights or costs, e.g., S-A (2 units), S-B (3 units), etc.
Source: S, Destination: E
```

Graph representation with nodes and edges indicating path lengths between them.

### Priority Queue in Action

**Exploring Shortest Path**

```en
Start at S, explore S-A (2 units) first due to priority queue.
Compare with other paths like S-B (3 units).
Update shortest path estimates as new paths are explored.
```

Using a priority queue to explore the shortest path first, ensuring efficiency.

Lecture reference: 7:20–15:22

## Branch-and-Bound Algorithm Overview

> The Branch-and-Bound algorithm systematically explores paths in a graph to find the shortest path by initializing a queue, testing paths, and extending them. It prioritizes paths without considering their lengths, stopping upon finding the first goal path.

### Initialization

**Initialize Queue**

```en
Start with a queue containing paths to explore, beginning with the initial node S and its neighbors like A and B in the example provided. For instance, the initial paths are S -> A and S -> B, each with a length of 1 step. The queue is processed in a breadth-first manner, ensuring that all paths are explored in the order they were added. This approach guarantees that the first path to reach the goal is the shortest one if the algorithm stops immediately upon finding it. However, in cases where multiple shortest paths exist, the algorithm may need to explore all paths to confirm the shortest route, though this can be inefficient for large graphs. To optimize, the algorithm may use a priority queue ordered by path length, similar to Dijkstra's algorithm, which would allow it to stop as soon as the first shortest path is found. This approach is more efficient but requires careful implementation to prevent infinite loops and redundant processing by marking nodes as visited once processed. The algorithm's efficiency can vary based on the graph's structure, with large graphs potentially causing significant computational overhead. Despite its simplicity, the Branch-and-Bound algorithm is a foundational method for understanding pathfinding and optimization problems, offering a clear and systematic approach to exploring all possible paths to find the optimal solution.
```

This example illustrates the initial paths from the starting node S to its neighbors A and B, each with a length of 1 step. The queue processes these paths in a breadth-first manner, ensuring that all paths are explored in the order they were added. This approach guarantees that the first path to reach the goal is the shortest one if the algorithm stops immediately upon finding it. However, in cases where multiple shortest paths exist, the algorithm may need to explore all paths to confirm the <

Lecture reference: 15:22–24:24

## Queueing Method Challenges

> The N queueing method struggles with guaranteeing the shortest path and experiences inefficiency due to redundant path extensions.

### Inability to Guarantee Optimal Path

**Issue**

> N queueing cannot ensure the shortest path extension, potentially missing optimal routes in some cases.

### Redundant Work and Inefficiency

**Problem**

- Extended paths are revisited, causing redundant work and inefficiency.

Lecture reference: 15:22–24:24

## Extended List Optimization

> Efficiently tracks previously extended paths to avoid redundant work, ensuring each node is processed once with the shortest distance.

### Optimization Purpose

**Prevent Redundant Processing**

1. Track nodes that have been extended to prevent re-extension.

**Ensure Optimal Processing**

- Only the shortest path to a node is kept.

### Mechanism

**How It Works**

1. An extended list is used to track nodes that have been processed and their shortest distances.
2. When considering a new path, if a node is already in the list with a shorter or equal distance, it is skipped.

### Example

**Example Path Processing**

```

```

Path S -> B -> C -> E was extended once and not re-extended.

Lecture reference: 15:22–24:24

## Efficiency Improvement

> Implementing the extended list approach significantly reduced computational effort by decreasing the number of extensions from 835,000 to just 835, resulting in a 999x reduction and improved system performance.

### Reduction in Extensions

**Before: 835,000 extensions for optimal path searches.**

- Before implementing the extended list approach, the system generated 835,000 extensions for optimal path searches.

Lecture reference: 15:22–24:24

## Dead Horse Principle

> Eliminates non-winning paths to optimize graph search algorithms.

### Reduces the number of extensions

**Code**

```Python
In A*, the next nodes to explore are those with the lowest f-score, where f(n) = g(n) + h(n). Here, g(n) is the cost from the start to node n, and h(n) is the heuristic estimate from n to the goal. By prioritizing nodes with lower f-scores, A* effectively implements the Dead Horse Principle by discarding paths that can't possibly lead to the optimal solution.
```

Code example showing how A* prioritizes paths using f-scores to discard non-optimal paths, implementing the Dead Horse Principle.

Lecture reference: 24:26–33:37

## Shortest Path Considerations

> Using airline distances to estimate lower bounds on path lengths helps in pruning non-optimal paths efficiently.

### Heuristic Estimates

**Estimate Path Lengths**

- Airline distances provide heuristic estimates for path lengths.

### Pruning Non-Optimal Paths

**Optimize Path Selection**

- These estimates help in pruning non-optimal paths.

Lecture reference: 24:26–33:37

## Comparison of Heuristic Methods and Extended Lists

> Heuristics offer quick solutions with potential for inaccuracy, while extended lists provide more reliability and efficiency, especially in complex scenarios.

### Heuristic Methods

**Pros**

- Heuristics provide quick solutions.

**Cons**

- Heuristics may miss important cases.

Lecture reference: 24:26–33:37

## Introduction to Search Algorithms

> Admissible heuristics enhance the efficiency of branch and bound search by reducing the number of nodes explored, ensuring optimal solutions are found without unnecessary computations.

### What Are Admissible Heuristics?

**Definition**

> An admissible heuristic never overestimates the cost to reach the goal, ensuring optimal solutions are found.

**Significance**

> By providing accurate lower bounds, admissible heuristics prioritize optimal paths, reducing the search space.

### Examples of Admissible Heuristics

**Example 1**

```en
Without a heuristic: 57 extensions. With an admissible heuristic: 6 extensions.
```

Comparison of search extensions with and without an admissible heuristic.

Lecture reference: 33:42–42:28

## The A* Algorithm

> A* is an optimal search algorithm that efficiently finds the shortest path in a graph by combining branch and bound with an admissible heuristic.

### Overview

**Pseudocode**

```en
function A*(start, goal)
    if start == goal
        return start
    openList = priority queue ordered by f(n)
    closedList = set
    g(start) = 0
    openList.add(start)
    while openList not empty
        node = openList.pop()  // node with lowest f(n)
        if node == goal
            return path
        closedList.add(node)
        for each neighbor in node's neighbors
            if neighbor in closedList
                continue
            tentative_g = g(node) + cost(node, neighbor)
            if neighbor not in openList or tentative_g < g(neighbor)
                g(neighbor) = tentative_g
                f(neighbor) = g(neighbor) + h(neighbor)
                if neighbor not in openList
                    openList.add(neighbor)
        return no path found if openList is empty
      
```

**Comparison**

- Compared to branch and bound, which explores all possibilities, A* prioritizes nodes using f(n) = g(n) + h(n).
- The heuristic h(n) guides the search towards the goal, making it more efficient.

**Heuristic Function**

```en
A heuristic function h(n) is admissible if it never overestimates the actual cost to reach the goal.
```

**Priority Queue**

```en
Used to manage nodes to explore, prioritized by f(n).
```

**Comparison**

- A* is optimal, ensuring the shortest path is found.
- A* generalizes Dijkstra's algorithm when h(n) = 0.

Lecture reference: 33:42–42:28

## Optimized A* Algorithm

> The optimized A* algorithm uses a priority queue to efficiently track the minimum f-score without sorting, enhancing performance.

### Data Structure Choice

**Heap Usage**

```en
A min-heap is used to efficiently track and extract the node with the lowest f-score, reducing time complexity for insertion and extraction operations to O(log n). This avoids the inefficiency of sorting the entire queue each time, which is O(n log n). By using a heap, the A* algorithm achieves a more optimal performance, especially with a large number of nodes and complex environments where efficiency is crucial for real-time applications like video games and robotics navigation systems. The heap ensures that each insertion and extraction operation is handled in logarithmic time, significantly improving the algorithm's scalability and responsiveness without compromising the accuracy of pathfinding decisions. The key insight is that the heap allows for constant-time access to the minimum f-score, enabling the algorithm to dynamically prioritize nodes based on their estimated costs to the goal, thus avoiding unnecessary sorting and maintaining the integrity of the heuristic estimates while enhancing computational efficiency.
```

A heap data structure is used to efficiently track and extract the node with the lowest f-score, reducing time complexity for insertion and extraction operations to O(log n). This avoids the inefficiency of sorting the entire queue each time, which is O(n log n). By using a heap, the A* algorithm achieves a more optimal performance, especially with a large number of nodes and complex environments where efficiency is crucial for real-time applications like video games and robotics navigation. The

Lecture reference: 33:42–42:28

## Admissible Heuristics

> Admissible heuristics ensure optimal pathfinding by providing accurate cost estimates, reducing explored nodes and guiding efficient search.

### Definition

**Code Block**

```en
Admissible heuristic: h(n) ≤ actual cost from n to goal (C*(n)). This ensures no overestimation of costs, guiding the search optimally without missing the optimal path. For example, using straight-line distance in routefinding is admissible as it doesn't overestimate the actual path cost. This allows the algorithm to explore fewer paths while still finding the shortest route. In games, admissible heuristics like straight-line distance ensure no position is overvalued, preventing missed winning strategies. In real-time systems, this ensures timely decisions with optimal quality. The balance between heuristic accuracy and computational cost is crucial, as highly accurate heuristics might require more computation. In routefinding, using a heuristic like straight-line distance reduces the number of nodes explored, making the algorithm more efficient. In games like chess, admissible heuristics evaluate positions accurately, ensuring no winning strategy is overlooked. In real-time systems, this allows timely decisions with optimal quality. The application of admissible heuristics requires careful design and understanding of the problem domain to avoid pitfalls. In routefinding, using a heuristic like straight-line distance reduces the number of nodes explored, making the algorithm more efficient. In games like chess, admissible heuristics evaluate positions accurately, ensuring nowin
```

Example of an admissible heuristic reducing extensions from 57 to 6.

Lecture reference: 33:42–42:28

## Pathological Cases

> Admissible heuristics, while generally safe, can lead to issues in specific configurations. Careful analysis is essential to avoid unintended consequences.

### Admissible Heuristics

**Admissible Heuristics**

- Admissible heuristics are generally safe but can cause issues in specific configurations.

**Pathological Cases**

1. Pathological cases require careful analysis.

### Examples

**Code Example**

```python

```

Example of a heuristic leading to unexpected results.

**Heuristic Function**

```latex
h(n) = oxed{	ext{min}(d_{	ext{Manhattan}}(n, g_1), d_{	ext{Manhattan}}(n, g_2))}
```

Heuristic function using Manhattan distance to two goal nodes.

**Result**

Lecture reference: 33:42–42:28

## Next Steps

> The lecture introduces the 8-puzzle problem and the A* algorithm as a key algorithm for pathfinding and problem-solving.

### The 8-Puzzle Problem

**The 8-puzzle problem is a classic example in computer science used to explore search and规划**

- It consists of a 3x3 grid with tiles numbered 1-8 and one empty space.
- The goal is to rearrange the tiles into a specific order, typically from 1 to 8 with the empty space at the bottom right.

### The A* Algorithm

**The A* algorithm is a popular pathfinding and graph traversal algorithm used in various AI**

- It is an informed search algorithm that uses heuristics to guide its path.
- A common heuristic used is the Manhattan distance, which estimates the shortest path from one tile to another.
- It balances the cost of moving to a new tile with the heuristic estimate of the remaining journey.

Lecture reference: 0:08–7:20

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
