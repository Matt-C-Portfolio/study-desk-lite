# Study notes



## Understanding the Shortest Path Problem

> The shortest path problem involves finding the most efficient route between two points, considering factors like distance, roads, and sometimes using heuristics.

### Historical Context

**Route 66 Example**

> Route 66 is a classic example of the shortest path between Chicago and LA, highlighting the importance of efficient routing in historical transportation systems [S1]. This route was chosen for its efficiency, saving time and resources compared to other available paths at the time [S1]. The lecture uses this example to introduce the concept of finding the shortest path in a network [S1].

Lecture reference: 0:08–7:20

## Heuristic Methods for Pathfinding Algorithms

> Efficiently finding the shortest path in complex environments using heuristic prioritization

### What Are Heuristic Methods?

**Definition**

Heuristic methods prioritize nodes closer to the goal node, using heuristic functions to guide the search process towards more promising paths. These methods balance exploration and exploitation to find optimal or near-optimal solutions efficiently in complex environments. They are particularly useful when exhaustive search methods like depth-first search are impractical due to computational constraints or inefficiency in finding the shortest path. The heuristic function estimates the cost or distance from the current node to the goal, helping the algorithm focus on the most promising paths first. This prioritization reduces unnecessary work and improves the efficiency of the search process compared to blind or exhaustive methods. The quality of the heuristic directly impacts the algorithm's performance and success in finding the shortest path. A good heuristic is both admissible (never overestimates the actual cost) and consistent (satisfies the triangle inequality) to ensure optimality under certain conditions. For example, the Manhattan distance heuristic is often used in grid-based pathfinding to estimate the minimum distance between two points, guiding the search towards the goal efficiently. In contrast, a less effective heuristic might overestimate the remaining distance, leading the algorithm to explore less optimal paths unnecessarily. The balance between heuristic ad候

### Examples of Heuristic Methods

**Hill Climbing**

Hill climbing is a simple heuristic method that explores neighboring nodes, selecting the one with the highest heuristic value closest to the goal. It uses a greedy approach, always moving towards the node that seems most promising based on the heuristic function. While it can efficiently find local optima, it may get stuck in local maxima and fail to find the global optimum. For example, in a grid-based map of Cambridge, hill climbing might find a path to the goal but miss a shorter path that requires revisiting some nodes. This method is easy to implement but lacks the ability to backtrack or explore alternative paths, making it less reliable for complex problems. However, it serves as a foundational technique for understanding heuristic prioritization in pathfinding algorithms. The heuristic function in hill climbing could be the Manhattan distance to the goal, guiding the algorithm to prioritize nodes closer to the destination. While this approach is computationally efficient, it may not always yield the shortest path, especially in environments with many obstacles or varying terrain costs. The trade-off between computational efficiency and solution optimality is a key consideration when applying hill climbing methods to real-world problems like routefinding in navigation systems or pathfinding in video games. The algorithm's simplicity allows for quick execution but may at

**Beam Search**

Beam search is a heuristic method that explores the most promising nodes at each step, maintaining a limited number of open nodes (the beam width) based on their heuristic scores. This approach focuses on exploring the most likely paths first, reducing the search space and computational complexity. For instance, in a Cambridge map with numerous possible routes, beam search might narrow down the exploration to a subset of nodes with the highest heuristic values, such as the nearest to the goal, ensuring that the algorithm efficiently finds a path without exploring all possibilities. However, the effectiveness of beam search depends on the beam width and the quality of the heuristic. A narrow beam width might miss the optimal path, while a wide width could revert to a less efficient exhaustive search. By balancing these factors, beam search can provide a good trade-off between exploration and exploitation, making it suitable for applications where computational resources are limited but solution quality is still important. The heuristic function in beam search could prioritize nodes based on their estimated distance to the goal, such as using the A* algorithm's f-score to guide the selection of the most promising nodes. This method ensures that the search remains focused on the most viable paths, improving efficiency while still having the potential to find an optimal solution if

### Comparison with Other Methods

**Depth-First Search**

Depth-first search (DFS) is a non-heuristic method that explores all possible paths level by level until the goal is found. While DFS can find the shortest path in certain cases, it is not guaranteed to do so in all scenarios, especially in graphs with varying edge costs or complex topologies. DFS is computationally intensive as it explores every possible path before backtracking, making it unsuitable for large-scale problems or environments with many obstacles. In contrast, heuristic methods like hill climbing and beam search prioritize paths closer to the goal, reducing unnecessary exploration and improving efficiency. However, the trade-off is that these methods may not always find the absolute shortest path, relying instead on heuristic guidance to focus on the most promising routes. For example, in Cambridge's map, DFS might explore a winding path to the goal, while hill climbing and beam search would focus on direct routes based on their heuristic values. The choice between DFS and heuristic methods depends on the specific requirements of the problem, such as whether finding the absolute shortest path is critical or if computational efficiency is a higher priority. Heuristic methods are particularly valuable in scenarios where computational resources are limited or the problem size is too large for DFS to handle effectively. Their ability to guide the search towards the

Lecture reference: 0:08–7:20, 7:20–15:22

## Introduction to Branch-and-Bound Algorithm

> The branch-and-bound algorithm efficiently finds the shortest path in a graph by exploring paths in order of their accumulated length, ensuring no redundant processing by extending nodes only once.

### Algorithm Overview

**Process Steps**

1. 1. Start at the initial node S with a path length of 0.
2. 2. At each step, choose the path with the shortest accumulated length.
3. 3. Extend the chosen path by exploring its unvisited neighbors.
4. 4. Repeat until the goal node is reached.

**Path Length Calculation**

```latex
f(n) = g(n) + h(n)
```

Where f(n) is the total estimated cost, g(n) is the known cost from start to node n, and h(n) is the heuristic cost from node n to goal.

Lecture reference: 7:20–15:22, 15:22–24:24, 33:42–42:28

## Efficiency and Pruning

> By comparing accumulated path lengths to the goal's length, the algorithm prunes unnecessary paths, enhancing efficiency.

### Pruning Mechanism

**Code Block**

```en
if (accumulatedLength >= goalLength) { stopExploringPath(); } // Prune paths longer than the goal's length

keepTrackExtendedNodes(); // Avoid revisiting nodes to save computational effort

pruneRedundantPaths(); // Remove paths that are not necessary for finding the shortest path

return improvedEfficiency(); // Enhanced algorithm efficiency achieved by pruning and tracking extended nodes
          }
```

**Comparison with Other Algorithms**

- Efficiency: Pruning unnecessary paths reduces the number of paths to explore, making the algorithm faster.
- Comparison with Dijkstra's Algorithm: Unlike Dijkstra's, which considers all paths, this algorithm prunes unnecessary ones based on accumulated lengths.
- Comparison with A*: While A* uses heuristics, this method focuses on pruning paths that exceed the goal's length.

**Comparison**

- If a path's accumulated length is greater than or equal to the goal's length, stop exploring that path.
- Extended list keeps track of nodes already extended to avoid redundant work and save computational effort.

**Formula**

```latex
 \text{If accumulated path length } 
ightarrow \text{goal length, prune the path} \rightarrow \text{pruneRedundantPaths()}
```

Formula for pruning paths based on accumulated lengths.

Lecture reference: 7:20–15:22, 15:22–24:24

## Heuristic Comparison and Benefits

> Heuristics significantly enhance pathfinding efficiency by guiding searches and pruning suboptimal paths.

### Dead Horse Principle

**Definition**

> Prunes paths that can't lead to the optimal solution, saving computational resources.

### Airline Distance

**Concept**

```en
A lower bound on remaining distance, ensuring admissible heuristic.
```

A* uses airline distance to prioritize paths with the lowest f-score.

### Extended List Method

**Mechanism**

```en
Each node extended only once, avoiding redundancy.
```

Systematic exploration reduces unnecessary work.

### Heuristic Comparison

**Efficiency**

- Extended list is more efficient than admissible heuristics.

### Admissible Heuristics

**Properties**

```en
Never overestimates actual cost, ensuring optimal paths are found.
```

A* efficiently finds the shortest path by prioritizing nodes with the lowest f-score.

### Examples

**Scenario 1**

```
Using heuristic reduces extensions by 50%.
```

Comparison shows heuristic effectiveness.

### Pruning Paths

**Mechanism**

> Prunes paths that can't lead to the optimal solution, saving computational resources.

Lecture reference: 24:26–33:37, 33:42–42:28

## Heuristic Functions and Theory

> Heuristic functions guide search algorithms towards the goal efficiently, with admissible and consistent heuristics ensuring reliable pathfinding in various problem spaces.

### Definitions

**Heuristic Function**

A heuristic function is a technique that estimates the cost from the current state to the goal state in search algorithms. It helps in guiding the search towards the goal efficiently by prioritizing more promising paths first. While not always accurate, a good heuristic can significantly speed up the search process and find a solution more quickly than exhaustive search methods like BFS or DFS.

### Admissible Heuristics

**Properties**

Admissible heuristics never overestimate the cost to reach the goal. They provide a lower bound on the actual cost, ensuring that the heuristic does not lead the search astray by overestimating the remaining distance to the goal.

### Consistent Heuristics

**Properties**

Consistent heuristics require that the estimated cost from any node to the goal does not exceed the actual cost to move to an adjacent node and then apply the heuristic again. This ensures reliability across nodes and avoids misleading paths.

### Examples

**Example 1**

In non-Euclidean spaces, heuristics might mislead the search towards suboptimal paths. For instance, an A* algorithm using a heuristic that estimates the distance between nodes in a non-Euclidean space might result in a longer path due to incorrect distance estimates.

### Examples

**Example 2**

A case study demonstrates how an overly optimistic heuristic can result in a longer path due to incorrect distance estimates. For example, using an admissible heuristic with an estimate of 100 for the distance between two nodes when the actual distance is 2 leads to unreliable results and a longer path.

### Non-Euclidean Spaces

**Impact**

In non-Euclidean spaces, the reliability of heuristics can be compromised, leading to suboptimal paths. This is because the heuristic function might not accurately reflect the actual cost in such spaces, causing the search algorithm to misguide the pathfinding process.

### Case Study

**Example**

The example highlights a scenario where heuristic estimates led to a longer path despite being admissible. For instance, using an A* algorithm with a heuristic that estimates the distance between nodes in a non-Euclidean space might result in a longer path due to incorrect distance estimates.

### Computational Efficiency

**Impact**

Using admissible heuristics with branch-and-bound can be computationally expensive and unreliable. This is because the heuristic's admissibility ensures it never overestimates the cost, but it might lead to unnecessary computations and unreliable results in certain problem spaces.

### Extended Lists

**Implications**

Extended lists and consistent heuristics are necessary for more efficient and reliable pathfinding. Consistent heuristics ensure that the heuristic estimates are reliable across nodes, leading to more efficient search algorithms and better reliability in finding optimal paths.

Lecture reference: 33:42–42:28, 42:28–48:22

## Optimization and Conclusion

> Efficient algorithms and careful heuristic choice are crucial for optimizing pathfinding, ensuring reliability and performance.

### Heuristic Choice

**Heuristics reduce computational cost but must be carefully chosen to ensure reliability.**

- Branch-and-bound with an extended list can be computationally intensive without heuristics.
- Heuristics are essential for guiding search algorithms efficiently.
- Heuristic functions help prioritize paths towards the goal.
- Admissibility ensures no overestimation but may not guarantee optimality.
- Consistency improves reliability by providing accurate heuristic estimates.

### Algorithm Efficiency

**Efficient algorithms like branch-and-bound with extended lists are essential for practical**

- Efficient algorithms reduce computational time and resources.
- Extended lists in branch-and-bound improve search accuracy.
- Optimized heuristics ensure faster convergence to solutions.
- Practical applications rely on balanced heuristic choices.

Lecture reference: 42:28–48:22

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
