# Study notes



## Shortest-path problem and heuristic distance

> The shortest-path problem seeks the very shortest route between two points, not merely a good or acceptable one. Heuristic distance estimates closeness to the goal using straight-line distance, which can guide search but cannot guarantee the best solution.

### Shortest paths as a search problem

Route 66 provides historical motivation for asking how to find the shortest route between locations. Finding the best path is presented as an expected skill in an artificial intelligence course, even though it may not directly model an obvious process in the human mind. Maps are used because they are visual and convenient, but the underlying subject is choice, not maps.

### Heuristic distance

Heuristic distance is the distance “as the crow would fly” between two places: a straight-line estimate of how close a location is to the goal, even when no direct road connects them.

**Limitation of closeness**

> Being close to the goal is generally useful, but it is not guaranteed to lead to the best solution. A node may appear promising because it is near the goal yet be a dead end; node E illustrates this limitation.

### Use in search algorithms

- Hill climbing and beam search use closeness to the goal as an objective.
- In a prior beam-search example, candidates A, B, C, and D were compared by airline distance.
- Candidates D and B were retained, while A and C were rejected because they were farther from the goal.
- The heuristic concept is emphasized because it is needed for the algorithms being introduced.

Lecture reference: 0:08–7:20

## Branch-and-bound shortest-path search and pruning

> A proposed route must be checked against alternative paths. The search repeatedly selects the queued partial path with the smallest accumulated distance, not the smallest estimated remaining distance. With non-negative edge lengths, paths whose current length is at least a known goal-path length cannot produce a shorter solution. Zero-length extensions may produce additional equally short paths.

### Candidate route and verification

For the smaller map, the proposed path from S to G is S → A → D → G, with stated total length 11. It is initially treated as an answer supplied by an oracle, but the oracle’s answer is not accepted blindly. Alternative paths must be developed and shown to have lengths greater than 11.

The systematic checking process starts at S with accumulated length 0. Paths through A and B are compared, and the shorter one is extended. After each extension, the resulting alternatives are compared globally with the other queued paths.

### Selecting and extending partial paths

- The search tracks the accumulated path length already traveled; it does not use heuristic estimates of remaining distance to the goal.
- The process repeatedly selects the shortest unextended partial path.
- For the graph discussed, S to A has length 3 and S to B has length 5, so S-A is extended first.
- Extending S-A produces S-A-B with length 7 and S-A-D with length 6; the length-6 path is then selected.
- The search considers partial-path lengths 7, 6, 9, and 9 before extending the length-6 path to reach the goal.

### Oracle-based pruning and shortest-path confirmation

Once a goal path of length 11 is known, a partial path of length 11 cannot improve it, and a longer path cannot match it if future edge lengths are non-negative. Thus, paths with accumulated lengths 12 or 15 are pruned because every continuation has non-negative additional length.

In the example, S-A-B-C reaches the goal with length 11. S-B-A-D has length 12, and the branch through C toward E has accumulated length 15, so neither branch is extended further. The remaining candidates are checked to confirm that none can produce a path shorter than 11.

**Guarantee and qualification**

> The shortest-path guarantee relies on non-negative edge lengths. Before any goal is found, no work is known to be wasted if every explored partial path is shorter than the eventual goal path. When a first goal is reached, the oracle-based process continues checking the remaining shortest unextended paths until all are no shorter than the discovered goal path.

### Queue-based algorithm

1. Initialize the queue.
2. Test the first path on the queue.
3. If the first path reaches the goal, stop. Because the queue is sorted by path length, every other queued path is at least as long and cannot provide a shorter goal path.
4. If the first path does not reach the goal, extend it, place its extensions back on the queue, sort the queue, and repeat.

The algorithm repeatedly examines the shortest queued path, accepts it if it reaches the goal, or extends it and requeues the resulting paths.

### Zero-length extensions

A path of equal length could produce another equally short solution if later extensions have total length zero. The shortest-length guarantee remains valid, but an implementation intended to enumerate all shortest paths must account for possible zero-length extensions.

Lecture reference: 0:08–7:20, 7:20–15:22, 15:22–24:24

## Extended lists for avoiding redundant path expansion

> For optimal-path search, record nodes or paths that have already been extended. A later path reaching the same node should be skipped when an earlier, shorter path has already been extended from that node. This extended-list rule prunes redundant branches and can greatly reduce the search effort.

### Why an extended list is needed

A queued-path list records paths placed on the queue, but that criterion is not sufficient for this optimal-path search. The relevant record is an extended list: it tracks nodes or paths whose paths have already been extended. A path reaching a node should not be extended if another path has already reached and been extended from that node with a shorter distance.

- The unpruned procedure can perform extensive redundant work.
- The extended-list rule eliminates large regions of the search tree because repeated, longer arrivals at already extended nodes cannot improve an optimal path.
- The flow chart should test the first path and extend it only if it has not already been extended at the relevant location.
- An earlier label or statistic referring to “N queued” should instead have referred to extended paths for this case.

### Statistics and comparison with the basic method

The lecture tracks the number of extensions as a statistic for comparing the basic method with branch-and-bound using an extended list. In the discussed run, 1,354 paths were placed on the queue, and approximately 835,000 paths reached the front of the queue and were extended. For the classroom example, the basic case was reported as having 835 extensions; the lecture then introduced the extended-list version to compare its extension count.

### Walkthrough of the classroom graph

1. From S, the initial alternatives reach A with path length 3 and B with path length 5.
2. Extending A produces alternatives reaching B and D with path lengths 7 and 6; the transcript then corrects the immediate ordering and continues with B producing paths to A and D of lengths 7 and 6.
3. The shortest current path is to B, which is extended to A and C with path lengths 9 and 9.
4. The next shortest path is to D, which extends to G with path length 11.
5. A later path reaching B is skipped because B has already been extended through a shorter path.
6. Later paths reaching B and A are also skipped for the same reason.
7. Only the path reaching C is extended, producing E at path length 15.
8. The search is then complete for this example, with redundant branches pruned.

The explicitly traced path lengths are 3, 5, 7, 6, 9, 9, 11, and 15, associated with the successive reaches of A, B, D, A, C, G, and E as described in the walkthrough.

### Pruning principle

- A path that returns through A need not be extended if a shorter path has already reached A.
- A path reaching B need not be extended again after another shorter path to B has already been extended.
- The extended-list rule avoids re-extending nodes already reached by shorter paths and finishes after extending only necessary alternatives in the classroom graph.

Lecture reference: 15:22–24:24

## Heuristic lower bounds and admissible heuristic search

> Heuristic search improves branching by discarding partial paths that cannot lead to a winning path. It expands the path with the smallest estimated total distance, combining accumulated distance with airline distance. The airline-distance estimate is admissible because it never exceeds the actual remaining distance.

### Lower bounds for partial paths

A path from S to B has already accumulated length 5, so any complete path extending it must be at least that long. A stronger lower bound combines the accumulated distance with the airline distance to the goal.

**Lower-bound score**

```latex
lower\ bound = accumulated\ distance + airline\ distance\ to\ goal
```

The score estimates the smallest possible total distance for a path extension.

For a path through B, the accumulated distance is 5 and the airline distance to G is 6, giving a lower bound of 11. Airline distance is a lower bound because a direct straight-line road would have that length, while an actual available route cannot be shorter than the straight-line distance.

### Heuristic search process

The method is an improvement layered on top of branching, not a different algorithm. The initial paths through A and B have accumulated distances 3 and 5. Adding airline distances to G gives potential scores of slightly more than 10 through A and 11 through B, so the path with the shortest potential is expanded.

1. From A, the path S-A-B has accumulated distance 7 and airline distance 6, for a score of 13.
2. The path S-A-D has accumulated distance 6 and airline distance 5, for a score of 11.
3. The candidate paths through D and B tie with scores of 11; the tie is resolved lexically, with B selected before D.
4. Expanding B produces paths toward A and C, each with accumulated distance 9 and an estimated total of 16.
5. The path reaching G has accumulated distance 11 and airline distance 0, giving a final score of 11 and becoming the best option.

The demonstrated paths have the following values:

- S-A-B: accumulated = 7, airline = 6, estimated total = 13
- S-A-D: accumulated = 6, airline = 5, estimated total = 11
- S-B-A: accumulated = 9, airline = 7, estimated total = 16
- S-A-B-G: accumulated = 11, airline = 0, estimated total = 11

### Admissibility and performance

The airline-distance estimate is called an admissible heuristic because it is guaranteed to be less than or equal to the actual remaining distance, making it safe for this pruning purpose.

- Heuristic search: 70 extensions in this example.
- Search without the improvement: 835 extensions.
- Extended-list method: 38 extensions in this example.

> The demonstrated extended-list approach performed better on this particular example than the airline-distance heuristic: 38 extensions versus 70. This result is not sufficient to conclude that extended lists are generally more useful; performance depends on the problem itself. Changing the starting point or the problem structure may produce a different comparison.

Lecture reference: 24:26–33:37

## Comparing search enhancements and A* path selection

> An extended list and an admissible heuristic can each reduce search effort, but neither is uniformly superior. A* combines branch-and-bound, an extended list, and an admissible heuristic; it ranks paths by accumulated distance plus an estimate of remaining distance and can outperform either enhancement used independently.

### Independent search enhancements

The extended list prevents repeating movements through the same node. However, it contains no information about the remaining distance to the goal and may therefore explore an irrelevant region of the search space. An admissible heuristic can direct the search toward the goal, but its usefulness, like that of the extended list, depends on the nature of the space being explored.

**Reported effects on search effort**

- In one test, baseline branch-and-bound required 57 extensions, while adding an admissible heuristic reduced this to 6 extensions.
- In another test, using an extended list reduced the number of extensions to 35, whereas the admissible heuristic performed worse.
- These results show that the relative effectiveness of the two techniques depends on the problem space; neither technique is uniformly superior in every problem.

### A* combines the enhancements

A* is described as branch-and-bound plus an extended list plus an admissible heuristic. In the original test problem, A* required 27 extensions, outperforming either enhancement used independently. In another configuration, the extended list provided no additional benefit because the admissible heuristic already directed the search tightly toward the goal.

The lecture reports an A* result of 27 extensions in the original problem, compared with 35 for the extended-list approach and 6 for the admissible-heuristic approach in the separately discussed test cases.

### Path evaluation and selection

**A* path evaluation**

```latex
f(path) = g(path) + h(path)
```

The evaluation combines accumulated distance with the admissible estimate of the remaining distance.

After a path is extended, paths are ranked by accumulated distance plus the admissible heuristic rather than by accumulated distance alone. A complete sort is unnecessary: the algorithm only needs to track which available path has the minimum evaluation value. The next path to extend is therefore the shortest according to the combined accumulated-distance and heuristic measure.

Lecture reference: 33:42–42:28

## Limits of admissibility and the role of consistency

> Admissibility guarantees that a heuristic does not overestimate remaining distance, and it is characterized as sound for optimal search on maps. In a general non-geometric graph, however, admissibility alone may allow a search with an extended list to commit to a nonoptimal path. Consistency adds a constraint on heuristic differences between connected nodes and avoids the demonstrated failure.

### Admissibility in map-based and general search

For map-based search, admissibility is characterized as a sound way to perform an optimal search. However, search problems need not represent geographical maps: they may model systems whose links have arbitrary costs, including costs that do not correspond to physical distances. In this non-geometric setting, the basic logic of admissibility can produce problematic cases.

**Admissibility condition**

```latex
h(X) \le d(X,\ goal)
```

Here, h(X) is the estimated distance from node X to the goal, and d(X, goal) is the actual distance from X to the goal.

### Pathological graph example

The pathological graph has start node S, branches through A and B, a merge at C, and a goal G. One route has stated actual link distances of 1, 1, 1, and 10, while another link has distance 100. The heuristic estimates are 100 for one node and 0 for the other two. Zero is an admissible underestimate, and the estimate of 100 is also admissible because the corresponding actual remaining distance is 101.

**How the search proceeds**

1. From S, the path through A has accumulated distance 1 plus heuristic 100, giving an evaluation of 101.
2. The path through B has accumulated distance 1 plus heuristic 0, giving an evaluation of 1.
3. A* initially extends the path through B because it has the lower accumulated-distance-plus-estimated-distance value.
4. The search reaches the goal with total cost 111.
5. After another route is expanded, node C would have accumulated cost 2 and estimated remaining cost 0, for a total of 2.
6. Because C has already been expanded, the extended list prevents reopening it. The algorithm therefore stops with the nonoptimal cost-111 path instead of finding the shorter route.

### Why consistency is additionally required

The heuristic values are 100 at one node and 0 at another, while the actual distance between those nodes is 2. The heuristic difference is therefore much larger than the distance connecting the nodes. The example shows that branch-and-bound with an extended list works in the earlier setting, but adding an admissible heuristic is not sufficient for this non-geometric graph.

**Consistency condition**

```latex
|h(X)-h(Y)| \le d(X,Y)
```

Consistency requires the absolute difference between heuristic estimates at two nodes and the goal to be no greater than the actual distance between those nodes.

**The example’s heuristic**

- Admissibility: The heuristic remains admissible because each estimate is no greater than the corresponding actual remaining distance.
- Consistency: The heuristic is inconsistent because |100-0|=100, while the actual distance between the nodes is 2.
- Correction: Changing the estimate of the goal-related node from 0 to 2 would preserve admissibility and make the heuristic consistent.
- Consequence: A consistent heuristic avoids the demonstrated failure in the general non-map setting.

Lecture reference: 33:42–42:28, 42:28–48:22

## Practical optimal pathfinding trade-offs

> Practical optimal pathfinding combines branch-and-bound with search-management and heuristic techniques. An extended list avoids repeatedly expanding the same nodes, while admissible or consistent heuristics guide the search toward a good path without abandoning optimality.

### Managing the search

Branch-and-bound can be extremely expensive, including pathological cases with exponential growth relative to the distance to the goal. Practical pathfinding therefore uses additional techniques to reduce the amount of work.

**Search techniques**

- An extended list is generally used to avoid repeatedly expanding the same nodes.
- Depending on the circumstances, the search can use an admissible or consistent heuristic.
- These techniques support finding an optimal path while guiding the search toward a heuristically good path.

### Applications

The lecture identifies this combination of search management and heuristic guidance as the basis for how MapQuest and related systems find routes.

Lecture reference: 42:28–48:22

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
