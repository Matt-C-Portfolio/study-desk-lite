# Study notes



## Shortest-path problem framing and search as choice

> The shortest-path problem asks for the very shortest path between two points, not merely an arbitrary or good path. Maps provide visual examples, but the underlying subject is choice: search algorithms help identify the best path when visual inspection cannot reliably establish it.

### Framing the problem

The lecture asks for the shortest path between S and G and uses a smaller map as the working example. Route 66 provides historical motivation for asking how to find the shortest route across a network.

### Why search is needed

Visual inspection may identify a good path, but it cannot reliably establish the best possible path. Finding the best path is presented as an expected skill in artificial intelligence, although it is not necessarily a direct model of an obvious mental process.

### Beyond maps

- The map representations are intended to clarify concepts behind search algorithms.
- The same search ideas can be applied beyond geographic routes.

Lecture reference: 0:08–7:20

## Heuristic distance, lower bounds, and pruning comparisons

> Heuristic distance is the straight-line, or airline, distance between locations. Combining accumulated path length with this estimate gives a lower bound for pruning and path selection when the heuristic is admissible. In the demonstrated example, the extended-list method used 38 extensions versus 70 for the airline-distance method, but the result depends on the search problem.

### Heuristic distance and search objectives

Heuristic distance is the straight-line, or crow-flies, distance between two locations, even when no direct road connects them. As a general heuristic, being closer to the goal is considered desirable. Hill climbing and beam search use closeness to the goal as an objective.

**Limitation of closeness**

> Closeness to the goal does not guarantee a good route. Node E appears close to G but is a dead end.

The airline-distance method is an efficiency adjustment layered on top of branching, not a different search algorithm.

**Beam-search example**

- C, B, A, and D were candidates for the next search round.
- D and B were retained based on straight-line distance to the goal.
- A and C were discarded as farther from the goal.

### Lower bounds and admissibility

The dead-horse principle says to stop extending a path as soon as it cannot possibly be the winning path. A path can be discarded when its best possible total length is already no better than competing paths.

The lower bound combines the path's accumulated distance with an airline-distance estimate to the destination. A straight-line or airline distance provides a lower bound because an available road or path cannot be shorter than the direct distance between its endpoints.

**Lower-bound calculation**

```latex
5 + 6 = 11
```

For a path from S to B with accumulated distance 5 and remaining airline distance 6, the possible total length is bounded below by 11.

An airline-distance estimate is called an admissible heuristic because it is guaranteed to be less than or equal to the actual remaining distance. It can therefore help determine whether a path could still become optimal without overestimating its eventual cost.

### Graph simulation with airline-distance estimates

In the graph simulation, the initial choices have accumulated distances 3 through A and 5 through B. Adding airline distances to G gives potential scores of slightly more than 10 through A and 11 through B, so the path through B is selected first.

After expanding through A, the paths S-A-B and S-A-D both receive a potential score of 11. S-A-B has accumulated distance 7 plus an airline distance of 6. S-A-D has accumulated distance 6 plus an airline distance slightly greater than 7. The tie is resolved by choosing the lexically least option, B before D.

Expanding B produces S-B-A with accumulated distance 9 and potential score 16. Extending the best current branch to G yields accumulated distance 11 and airline distance 0, for a final score of 11.

### Comparison of demonstrated search methods

**Extension counts and interpretation**

- Using only the airline-distance lower bound required 70 extensions.
- The extended-list method required 38 extensions in the same demonstrated setting.
- The extended-list method performed better in this example, but one example does not show that extended lists are always superior.
- The relative effectiveness of the methods depends on the particular search problem.
- The lecture proposes testing this dependence by starting the search from the middle rather than from the extreme left.

Lecture reference: 0:08–7:20, 24:26–33:37

## Shortest-path verification and accumulated-cost search

> A shortest path is certified by showing that every remaining alternative has accumulated cost at least that of the discovered goal path. With non-negative edge lengths, expanding the unextended partial path of smallest accumulated cost guarantees a shortest path; zero-length edges may produce additional tied shortest paths.

### Verification as a hypothesis test

A proposed shortest path should be treated as a hypothesis rather than accepted without checking. For the candidate path S–A–D–G, the reported total length is 11. Verification develops the other possible paths and confirms that each is longer than 11. The transcript ends as this development of alternatives begins.

**Example alternatives**

- The explored alternative S → B → A → D has cost 12 and is pruned after the goal cost 11 is known.
- A branch through C → E has cost 15 and is also pruned after the goal cost 11 is known.
- The final verification examines S → A → B → C at cost 11, S → A → D at cost 12, and the branch through C → E at cost 15.

### Accumulated-cost search

The search begins with only the start node, S, at accumulated length 0. At each step, it compares all available partial paths and extends the one with the smallest distance traveled so far. It does not estimate how far a state remains from the goal, unlike heuristic search.

**Worked search sequence**

1. Start with S at cost 0.
2. Consider S → A at cost 3 and S → B at cost 5.
3. Extend S → A, generating paths of cost 7 and 6.
4. Return to the currently shortest unextended path, S → B at cost 5.
5. From S → B, generate paths to A and C, each with cost 9.
6. Continue with the shortest accumulated-cost frontier path. The path S → A → D has cost 6 and reaches the goal with total cost 11.
7. The worked graph also contains S → A → B → C, which reaches the goal with total cost 11.

### Stopping rule and shortest-path guarantee

The algorithm cannot stop immediately when the goal is first reached. Every remaining frontier path must be checked until its accumulated cost is at least the discovered goal cost. In the worked graph, other partial paths have costs such as 12 and 15, so extending them cannot produce a shorter solution once a goal cost of 11 is known. Work performed before reaching the goal is not wasted because each expanded path was shorter than the eventual goal path.

**Oracle and non-oracle cases**

> If an oracle supplies the length of a path to the goal, no partial path with accumulated cost at least that length needs further extension when all edge lengths are non-negative. The oracle is not necessary: continue extending the shortest accumulated-cost path until a goal is reached, then continue until every remaining unextended path has cost no less than that goal path. Once every remaining path has accumulated cost at least 11, the solution is certified as shortest.

**Finding one shortest path versus all tied shortest paths**

- For finding one shortest path, a remaining path whose accumulated length equals the known goal cost need not be extended.
- A zero-length continuation cannot reduce the total cost, but it can produce another path with the same total cost.
- If all shortest paths must be enumerated, the implementation must account for these zero-length alternatives.

**Required condition**

> The guarantee depends on edge lengths being non-negative. Non-negative lengths ensure that extending a path cannot reduce its accumulated cost. Zero-length edges can therefore create additional paths tied for the shortest length, but cannot create a shorter path from an already equal-cost frontier path.

Lecture reference: 0:08–7:20, 7:20–15:22

## Branch-and-bound flow, extended lists, and search cost

> The search repeatedly examines the shortest queued path, extending it when necessary and stopping when the shortest queued path reaches the goal. For optimal paths, duplicate suppression must use an extended list: once a node has been reached and extended at a shorter distance, later paths reaching that node need not be extended. This can remove large portions of the search tree, although the unpruned search may perform many extensions even with relatively few queued paths.

### Search flow

The lecture briefly recalls depth-first search, which produces a path that is not short in the example, before applying the same comparison to a more complicated Cambridge map. The queue is kept sorted by path length, so the first queued path is always the shortest currently available path.

1. Initialize the queue and test the first path in it.
2. If the first queued path reaches the goal and the queue is sorted by path length, stop. Every other queued path is at least as long and cannot produce a shorter goal path.
3. If the first path is not a goal path, extend it, return its extensions to the queue, resort, and repeat.
4. Extend the first path only if it has not already been extended.

The lecture ends as the lecturer is about to introduce the label for the accumulated-cost strategy.

### Queued paths and extended nodes

- An N-queued list records paths placed on the queue and can prevent adding another path terminating at a node already represented in the queue.
- An extended list records nodes or paths that have already been extended and prevents extending them again.
- The earlier N-queued approach may work for prior searches, but it does not work for these optimal paths because a queued path is not necessarily the shortest path that will reach its node.

The algorithm therefore tracks paths ending at nodes unless those nodes have already been extended beyond that location. Once a shorter path has reached a node and has been extended, another path reaching the same node is guaranteed to be longer than an already processed route, so extending it is unnecessary.

- A path that passes through A again need not be extended if a shorter path has already reached and extended A.
- The same reasoning applies to a later path reaching B after another path to B has already been extended.
- This pruning can remove vast areas of the tree from examination.

### Classroom graph example

1. From S, the initial alternatives reach A with length 3 and B with length 5.
2. Extending A produces alternatives reaching B and D, with path lengths 7 and 6.
3. The shortest current path is then the one reaching B, which is extended to A and C with path lengths 9 and 9.
4. The next shortest path reaches D and extends to G with path length 11.
5. A later path reaching B is skipped because B has already been extended.
6. Paths reaching A are also skipped because A has already been extended. The remaining necessary extension is the path reaching C, which leads to E with length 15.
7. The search is then complete for this example.

In the classroom graph, after shorter paths to A and B have been extended, later queued paths reaching A or B are skipped. Only the queued path reaching C still requires extension, producing a path to E with length 15 before the search finishes.

### Search cost and the animated comparison

The earlier statistics reported 1,354 paths placed on the queue and 835,000 paths extended from the front of the queue. Thus, the unpruned search can place relatively few paths on the queue while still performing a very large number of extensions.

The revised algorithm still appears to examine many paths and may take substantial time, despite pruning redundant extensions. The lecture begins an animated comparison using branch-and-bound with an extended list. The supplied span introduces the revised count as a statistic to observe, but does not state its final value.

Lecture reference: 7:20–15:22, 15:22–24:24

## A* combination and path selection

> A* combines branch-and-bound with an extended list and an admissible heuristic. It selects the path with the lowest evaluation value, combining distance already traveled with estimated distance remaining, while avoiding unnecessary full sorting of all paths.

### Combining the two methods

The extended-list method prevents repeated movement through the same node. An admissible heuristic estimates the remaining distance to the goal. These methods address different inefficiencies: the extended list avoids repeated node exploration, while the heuristic directs the search toward the goal.

**A* structure**

> A* is branch-and-bound plus an extended list plus an admissible heuristic.

### Path evaluation and selection

**Evaluation value**

```latex
f(n)=g(n)+h(n)
```

The evaluation value combines actual distance traveled with estimated distance remaining.

Paths should be ranked by accumulated distance plus the admissible heuristic, rather than by accumulated distance alone. Because only the minimum-valued path is needed, an implementation can track the shortest path instead of sorting the entire list.

### Demonstrated search results

The demonstrated results show that the two methods can reduce the number of extensions, although their benefits depend on the search space. In one centered-start case, the heuristic already directed the search so tightly that the extended list added no benefit.

- Baseline branch-and-bound required 57 extensions.
- The extended-list method alone reduced the demonstrated search to 35 extensions.
- An admissible-heuristic search required 6 extensions in one case.
- In the original demonstration, combined A* required 27 extensions and outperformed either technique independently.

Lecture reference: 33:42–42:28

## Limits of admissibility and heuristic consistency

> Admissibility guarantees that a heuristic does not overestimate the true remaining distance, but it is not sufficient for optimal A* search in every abstract graph when previously extended nodes are not reconsidered. Consistency adds a neighboring-node constraint that prevents the illustrated failure.

### Admissibility and the abstract graph

An admissible heuristic estimates the remaining distance from a node without exceeding the actual remaining distance. A zero estimate is always admissible because it cannot overestimate. However, admissibility alone can fail to support optimal search in an abstract, non-geometric graph when the algorithm does not reconsider nodes that have already been extended.

**Graph and search details**

- The graph has the structure S branching to A or B; both paths merge at C, and C leads to G.
- The link costs are 1 from S to A, 1 from S to B, 1 from A or B to C, and 10 from C to G; an alternative link is assigned cost 100 as part of the constructed case.
- Link values need not represent geographic distances. They may model transitions in an abstract system with arbitrary costs.
- The search selects the node with the smallest sum of accumulated distance and estimated remaining distance.

**Admissibility condition**

```latex
h(X) \le d(X,\,\text{goal})
```

Here, h(X) is the estimated distance from X to the goal, and d(X, goal) is the actual distance.

### The pathological search result

The heuristic assigns an estimate of 100 to one node and 0 to two others. The estimate of 100 is admissible where the actual remaining distance is 101, and the zero estimates are also admissible. From S, the path through A has accumulated cost 1 plus heuristic 100, giving 101, while the path through B has accumulated cost 1 plus heuristic 0, giving 1. A* therefore expands the B path first.

**How the failure occurs**

1. Following the apparently promising route to C reaches the goal with total accumulated distance 111, even though a shorter path exists.
2. After A is extended, the path through A and C has accumulated distance 2 and estimated distance 0, giving a total of 2.
3. Because C was already extended, the algorithm stops there rather than reconsidering C, so it fails to find the shortest path.

**Search methods in the example**

- Branch-and-bound and branch-and-bound with an extended list are contrasted with adding an admissible heuristic.
- The addition of an admissible heuristic does not work reliably for this non-geometric graph when previously extended nodes are not reconsidered.
- The issue is that the example cannot be represented as a map on a plane.

### Consistency as a stronger condition

For a general non-map situation, consistency is introduced as a stronger condition than admissibility. It constrains the difference between heuristic estimates at neighboring nodes.

**Consistency condition**

```latex
|h(X)-h(Y)| \le d(X,Y)
```

The absolute difference between the estimates at X and Y cannot exceed the actual distance between those nodes.

**The example’s consistency failure**

- With estimates 100 and 0 and an actual inter-node distance of 2, the estimate difference is |100 − 0| = 100.
- Because 100 > 2, the consistency condition fails.
- Thus the heuristic is admissible but inconsistent, and it fails in the example.
- If the estimate at the first node were 2 instead of 100, the heuristic would remain admissible and would also be consistent, because the estimate difference would be 2.

Lecture reference: 33:42–42:28, 42:28–48:22

## Practical search strategy and conclusion

> Branch-and-bound alone can be extremely expensive, potentially with exponential cost relative to the distance to the goal. A practical search should use an extended list and, depending on the circumstances, an admissible or consistent heuristic to support finding an optimal path or a heuristically good path.

### Managing search cost

Branch-and-bound alone can be extremely computationally expensive, including pathological cases with exponential cost relative to the distance to the goal. An extended list is presented as a practical advantage for reducing unnecessary work.

**Recommended search components**

- Use an extended list to reduce unnecessary work.
- Depending on the circumstances, use an admissible or consistent heuristic together with the extended list.

### Conclusion

These methods support finding an optimal path as well as a heuristically good path. This approach is identified as the basis of how MapQuest and its descendants work.

Lecture reference: 42:28–48:22

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
