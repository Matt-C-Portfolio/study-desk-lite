# Study notes



## Shortest-path search foundations

> Shortest-path search aims to determine the shortest possible path between two points, not merely any acceptable or good path. Maps provide visual examples, while the underlying subject is search: choosing among alternatives.

### The goal of shortest-path search

The goal is to determine the shortest possible path between two points, rather than any acceptable or merely good path. Finding the best path is presented as an expected skill in an artificial intelligence course, even though it may not directly model an obvious mental process.

**A distinction between good and best**

> A person may be able to identify a good path visually but not reliably establish that it is the best possible path.

### Maps as examples of a general search problem

Maps are convenient visual examples because they make the concepts behind the algorithms easier to understand. However, the map-based examples are distinct from the underlying concept: search concerns choosing among alternatives, not maps.

- Route 66 is introduced as a historical example of a major cross-country highway associated with a short route between Chicago and Los Angeles.
- The lecture will use both the Cambridge example and the Blackboard example to study shortest-path search.

### Illustrative path

On the smaller map, the proposed path from S to G is S ightarrow A ightarrow D ightarrow G, with total length 11.

Lecture reference: 0:08–7:20

## Heuristic distance and goal proximity

> Heuristic distance is the straight-line, or crow-flight, distance between two locations, even when no direct road connects them. Moving toward a location that is close to the goal is generally useful, but this heuristic can mislead the search: node E appears close to G yet is a dead end. Goal proximity was the objective in earlier discussions of hill climbing and beam search.

### Meaning and limitation

Heuristic distance measures the straight-line, or crow-flight, distance between two locations, regardless of whether a direct road connects them. It is generally useful to move toward a location that is close to the goal according to this distance, but proximity alone does not guarantee progress.

**A heuristic can mislead**

> In the illustrative example, node E appears close to G but is a dead end. Thus, being near the goal is not always beneficial.

### Use in search examples

Being close to the goal was the objective in the earlier discussions of hill climbing and beam search. In a beam-search example, C, B, A, and D were candidate nodes. Based on airline distances, D and B were retained, while A and C were rejected because they were farther from the goal as the crow flies.

Lecture reference: 0:08–7:20

## Uniform-cost shortest-path search and oracle-based verification

> A candidate shortest path supplied by an oracle can be checked with uniform-cost search. The procedure always extends the partial path with the smallest accumulated distance, uses non-negative edge lengths to discard paths that cannot improve the candidate, and continues after first reaching the goal until every remaining alternative is at least as long. Zero-length edges may leave additional tied shortest paths.

### Oracle answers are candidates, not trusted results

A practical initial strategy is to ask someone who knows the answer, or to use Google, to obtain a candidate solution. Juana is treated as an oracle who asserts that the shortest path is S → A → D → G, with path length 11. The candidate is provisionally accepted, but it must still be checked rather than trusted blindly. Verification asks whether every other possible path is definitely longer.

### Selecting paths by accumulated distance

- Begin with the path containing only the start node, whose accumulated length is 0.
- Among all extendable paths, always extend the one with the smallest accumulated length.
- When a path is extended, its new accumulated length is the prior length plus the edge length.
- Unlike heuristic search, which estimates how far each state is from the goal, this procedure considers only the distance already traveled.

From S, the paths to A and B have lengths 3 and 5, so S → A is extended first. Extending S → A to B gives S → A → B with accumulated length 7. Paths through S → B can produce S → B → A and S → B → C, each with accumulated length 9.

### Verifying a proposed path of length 11

Assume all edge lengths are non-negative. Once a path to the goal has length 11, a partial path whose accumulated length is 11 cannot produce a shorter solution. It could only produce another equally short path if its later extensions have total length 0. Paths of length 12 or 15 can be discarded without further expansion.

After finding S → A → B → C with length 11, the alternatives S → B → A → D and S → B → C → E have lengths 12 and 15, so they are not extended further. The search considers distances 3 and 5 from S, then distances 7 and 6 from S → A, followed by two paths of length 9 through S → B. It next extends S → A → D, reaches the goal with length 11, and checks the remaining alternatives: one extends to length 11, another to 12, and another to 15.

### Finding the goal distance without an oracle

1. Start with S at distance 0 and expand the currently shortest partial path.
2. Continue selecting the shortest unextended path until a path reaches the goal.
3. When the goal is first reached with length 11, do not stop immediately.
4. Compare the remaining unextended alternatives with 11 and continue expanding the shortest one.
5. Terminate once all remaining alternatives have accumulated lengths greater than or equal to the goal path length.

**Guarantee and tied paths**

> Before the goal is found, no completed work is wasted: every explored partial path is shorter than the as-yet-unknown goal path. With non-negative lengths, the procedure guarantees a path no longer than any other available path. It may find one shortest path without finding every shortest path. If zero-length edges exist, another path of equal length may still be reachable after the first shortest path is found; whether all such tied paths are enumerated is an implementation detail.

Lecture reference: 0:08–7:20, 7:20–15:22

## Queue-based shortest-path search

> The search repeatedly examines the shortest path currently on the queue. It stops when that path reaches the goal; otherwise, it extends the path, returns all extensions to the queue, sorts them by path length, and repeats.

### Comparison with depth-first search

The lecture applies the same ideas to a more complicated Cambridge map and recalls depth-first search as a comparison. The lecturer observes that the depth-first route shown is not a short path.

### Search process

1. Initialize the queue and test the first path on it.
2. If the first queued path reaches the goal, stop. Every other queued path is at least as long.
3. If the path does not reach the goal, extend it and put all extensions back on the queue.
4. Sort the queued paths by path length and repeat.

### Cited run

> The initial version performed substantial work: 1,354 paths were queued and 835,000 paths were extended in the cited run.

### Scope of the supplied lecture span

The lecture introduces the next search idea, but the supplied span ends before its label or full explanation is given.

Lecture reference: 7:20–15:22, 15:22–24:24

## Extended lists and branch-and-bound pruning

> Optimal-path search must track nodes whose paths have already been extended, not only nodes represented by queued paths. An extended list prevents redundant extensions through nodes reached by shorter paths, while branch-and-bound pruning discards branches that cannot produce the optimal solution. In the example, extensions decrease from 835 to 38; this is an efficiency improvement to branching, not a replacement for the underlying search algorithm.

### Why a queued list is insufficient

A queued list can prevent adding another path that terminates at a node already represented by a queued path. However, the queued path is not necessarily the shortest path to that node. The queued-list approach worked for the prior search, but optimal-path search should extend a path only when it is known to be short.

**Correction to the statistic label**

> The lecture corrects the earlier statistic label: what was called “N queued” should have been “extended.” The lecture tracks the number of extensions as the relevant comparison statistic.

### Extended-list pruning

The algorithm is decorated to test each path and extend it only if its location has not already been extended. When a node has already been extended through a shorter path, extending another path that reaches the same node at greater distance cannot improve the result. This avoids repeated extensions through A and B when shorter paths have already reached those nodes.

**Effect of pruning**

- Branches are discarded as soon as it is clear that they cannot produce the winning path.
- The method avoids extending paths that cannot possibly lead to the optimal solution.
- Pruning can remove large areas of the search tree from examination.
- The extended-list version is described as branch-and-bound with an extended list.

### Classroom example

```text
S -> A: length 3
S -> B: length 5
A -> B or D: resulting lengths 7 and 6
B -> A or C: resulting lengths 9 and 9
D -> G: resulting length 11
C -> E: resulting length 15
```

The path lengths show why later, longer routes to already extended nodes can be skipped.

In the classroom example, the shortest queued path is repeatedly extended. When a path reaching B or A appears after those nodes have already been extended, it is skipped. Only the path reaching C still needs extension, producing E at length 15, after which the example is complete.

### Efficiency comparison and qualification

- Earlier version: 835 extensions were cited.
- Enhanced branch-and-bound version: 38 extensions are required in the example.
- The reduction is a substantial efficiency adjustment to branching, not a different search algorithm.

The lecture switches to branch-and-bound with an extended list to compare how much work is saved. For the earlier version, the cited number of extensions was 835; no final revised count is stated in the supplied span beyond the example’s 38 extensions.

Lecture reference: 15:22–24:24, 24:26–33:37

## Airline-distance lower bounds and heuristic search evaluation

> For a partially traveled path, accumulated distance plus airline distance to the goal is a lower bound on any complete path continuing from its endpoint. The search expands the path with the smallest such score. Although admissible heuristics and extended lists can reduce work, their relative performance depends on the problem.

### Lower bounds and admissible heuristics

A path that has already traveled 5 units cannot have a total length below 5. If the airline distance from its current node to the goal is 6, any complete path must be at least the accumulated distance plus 6. Airline distance is a lower bound because a straight-line route may not exist as an actual road; an available route can only be equal to or longer than the direct distance.

**Potential total distance**

```latex
f(\text{path})=g(\text{path})+h(\text{current node},\text{goal})
```

Here, g is the accumulated distance and h is the airline-distance estimate to the goal.

**Admissibility**

> A heuristic is admissible when its estimate is guaranteed not to exceed the actual remaining distance.

### Search evaluation in the example

The search extends the path with the smallest potential total distance, calculated as accumulated distance plus airline distance. From S, the accumulated distances to A and B are 3 and 5. The airline distance from A to G is slightly more than 7, giving A a score slightly above 10. The airline distance from B to G is 6, giving B a score of 11. Therefore, the path through A is expanded.

**Candidate scores**

- The path S-B has accumulated distance 5 and airline distance 6 from B to G, so its lower-bound score is 11.
- The paths S-A-B and S-A-D both receive a score of 11.
- S-A-B has accumulated distance 7 plus airline distance 6.
- S-A-D has accumulated distance 6 plus airline distance 5.

When scores tie, the lexically least choice is selected, so B is expanded before D. From B, the path to A has accumulated distance 9 and airline distance 7, giving a score of 16. The path ultimately reaching G has accumulated distance 11 and airline distance 0, giving a score of 11. The path reaching G has the smallest score and is selected.

**Final path score**

```latex
11+0=11
```

The final path reaching G has accumulated distance 11 and an airline distance of 0.

### Comparing search methods

**Extensions in the example**

- Using the airline-distance lower bound alone requires 70 extensions.
- The extended-list approach requires 38 extensions and therefore appears more useful for this particular graph.
- The unenhanced approach previously required 835 extensions.

The extended-list method benefits from ensuring that each node is extended only once in the relevant cases. Pruning can reduce a search from an impractically long computation to one completed in seconds; the instructor contrasts this reduction with cases that might otherwise take longer than the remaining lifetime of the universe.

**Problem dependence**

> A conclusion based on one problem may be premature: changing the problem can change which method performs better. The comparison between the extended list and admissible heuristics remains problem-dependent. The lecture proposes testing this by starting the search from the middle rather than the extreme left and seeing whether the relative results change.

Lecture reference: 24:26–33:37

## A* path selection and combined optimizations

> A* combines branch-and-bound, an extended list, and an admissible heuristic. It ranks candidate paths by accumulated distance plus estimated remaining distance, then extends the path with the lowest value. In the demonstrated problem, A* required 27 extensions, compared with 57 for branch-and-bound alone, 6 for the heuristic alone, and 35 for the extended list alone.

### Combining search techniques

An extended list prevents repeated movement through the same node. An admissible heuristic estimates the remaining distance to the goal. Combining these methods with branch-and-bound produces A*.

**Key properties**

- A* is branch-and-bound plus an extended list plus an admissible heuristic.
- The usefulness of the extended list depends on the search space; when the heuristic channels search tightly toward the goal, the extended list may add no benefit.

### Results in the demonstrated problem

- Branch-and-bound without additional techniques: 57 extensions.
- Admissible heuristic alone: 6 extensions.
- Extended list alone: 35 extensions. It still explored areas such as the left side because it had no information about the remaining airline distance to the goal.
- A*: 27 extensions, outperforming either technique used independently.

### Selecting the next path

A* need not fully sort all candidate paths. A complete sort adds computation. Instead, the algorithm can identify the shortest-valued path and extend that path.

**Path value**

```latex
f(\text{path}) = g(\text{path}) + h(\text{path})
```

The path value is the sum of the actual distance traveled and the estimated distance remaining.

**Ranking criterion**

- Rank candidate paths by accumulated distance plus the admissible heuristic, rather than by accumulated distance alone.
- The relevant path value combines the actual distance traveled with the estimated distance remaining.

Lecture reference: 33:42–42:28

## Admissibility, consistency, and heuristic failure cases

> An admissible heuristic never overestimates the actual remaining distance. This supports optimal search in the discussed map-based setting, but admissibility alone can fail in a non-geometric graph when an already extended node is not reconsidered. Consistency adds a stronger bound on heuristic differences between connected nodes.

### Admissibility and its scope

An admissible heuristic is an underestimate of the actual remaining distance. A heuristic estimate of zero is always an underestimate and is therefore admissible. For map-based search, admissibility provides a sound method for optimal search. However, search problems are not limited to maps: link costs may represent an abstract model rather than geometric distance.

- A pathological graph can illustrate how admissibility may cause trouble outside ordinary map settings.
- The lecture's pathological example is only partially developed in the supplied span; the transcript ends while clarifying that link values need not come from a geometrically accurate map.
- The issue is that the graph cannot be represented as a map on a plane; admissibility is sufficient for the discussed map case but not for this general case.

**Admissibility condition**

```latex
h(X) \le d(X, goal)
```

The estimated distance from X to the goal is no greater than the actual distance.

### Failure of search in the pathological graph

The graph has the structure S connecting to A and B; both paths merge at C and then lead to G. The actual link distances are described as 1, 1, 1, and 10 on one route, with a corresponding alternative link of 100. The heuristic is 100 at A and 0 at B and C. The estimate of 100 at A is admissible because the actual remaining distance there is 101, while zero is also admissible because it is an underestimate.

**Search sequence**

1. From S, the candidate through A has accumulated distance 1 plus heuristic 100, for a total of 101. The candidate through B has accumulated distance 1 plus heuristic 0, for a total of 1, so A* selects the path through B first.
2. The search first extends a path to C, obtaining accumulated distance 11 and estimated remaining distance 0, for a total of 11. Extending onward reaches the goal with total cost 111.
3. When A is later extended through a different route, the path to C has accumulated distance 2 and estimated distance 0, for a total of 2.
4. C has already been extended, so the algorithm does not reconsider it and therefore misses the shorter path.

**Result**

> The displayed search values include an initial estimate of 1, a route through C with accumulated cost 11 and total 11, a later route to C with accumulated cost 2 and total 2, and a first discovered goal path with total cost 111. Branch-and-bound works, and branch-and-bound with an extended list works in the discussed setting, but adding only an admissible heuristic does not guarantee success for this non-geometric graph.

### Consistency

Consistency requires heuristic differences between connected nodes to be bounded by the actual edge distance. In the example, one node has heuristic value 100 and another has value 0, while their actual distance is 2. The heuristic is admissible but not consistent because the heuristic difference is greater than the actual distance.

**Consistency condition**

```latex
|h(X) - h(Y)| \le d(X,Y)
```

The absolute difference between the heuristic values at X and Y cannot exceed their actual distance.

**Example of the consistency check**

- Heuristic difference: |100 - 0| = 100.
- Actual distance between the locations: 2.
- Because 100 is greater than 2, the consistency inequality fails.
- A heuristic value of 2 in the first location would remain admissible and would also satisfy consistency in the example.

**Relationship to search success**

> The lecture claims that admissible heuristics can be constructed for which search loses, whereas a consistent heuristic succeeds in the corresponding situation.

Lecture reference: 33:42–42:28, 42:28–48:22

## Practical optimal pathfinding

> Practical optimal pathfinding combines branch-and-bound, an extended list, and an appropriate heuristic to find an optimal path while balancing solution quality against computational cost.

### Core approach

Branch-and-bound alone can be extremely expensive, including pathological cases with exponential dependence on the distance to the goal. An extended list is generally used to avoid repeatedly expanding nodes that have already been handled.

Depending on the circumstances, the search should use an admissible or consistent heuristic in addition to the extended list. The heuristic guides the search toward a heuristically good path while the overall objective remains finding an optimal path.

### Key components

- Branch-and-bound provides the basis for seeking an optimal path.
- An extended list prevents repeated expansion of already handled nodes.
- An admissible or consistent heuristic can guide the search efficiently.
- The method balances solution quality against computational cost.

### Applications

The lecture identifies this approach as the basis for systems such as MapQuest and its descendants.

Lecture reference: 42:28–48:22

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
