# Study notes



## Shortest-Path Problem and Candidate Verification

> The goal is to determine the very shortest path between two points, not merely an acceptable route. A proposed answer must be independently checked against competing possibilities: for the smaller map, the candidate S → A → D → G has total length 11, and verification requires developing alternative paths and confirming that each is longer.

### The problem as a choice task

Route 66 motivates the question of how to find the shortest path across a network. Although maps provide convenient and visual examples, the underlying artificial-intelligence problem concerns choice rather than maps themselves. Finding the best path is presented as a skill expected from someone who has studied artificial intelligence.

### Candidate route

The lecture uses a route between nodes S and G as the classroom search problem. For the smaller map, the proposed route is S → A → D → G, with a stated total length of 11.

### Why verification is necessary

Visual inspection may reveal a good path but cannot reliably establish that it is optimal. The proposed shortest path is framed as an oracle’s claim that must be independently verified rather than accepted without checking all competing possibilities.

1. Develop other possible paths between S and G.
2. Compare each alternative path with the candidate route of length 11.
3. Confirm that every alternative is longer than 11.

**Current lecture point**

> The lecture ends as the process of developing and checking alternatives is about to begin.

Lecture reference: 0:08–7:20

## Heuristic distance foundations

> Heuristic distance is the straight-line, or “as-the-crow-flies,” distance between a location and the goal, even when no road directly connects them. It generally helps guide search, but closeness to the goal can be misleading and does not guarantee an optimal path.

### Definition and role in search

Heuristic distance measures how close a location is to the goal using straight-line distance, even when no road directly connects them. Being close to the goal by this measure is generally useful for guiding search.

### Uses and limitations

- Hill climbing and beam search use closeness to the goal as an objective.
- Heuristic guidance can fail: node E appears close to G but is a dead end in the illustrative map.
- The heuristic is useful but does not guarantee an optimal path.

### Beam-search comparison

In a prior beam-search example, candidates A, B, C, and D were compared by airline distance. D and B were retained, while A and C were rejected because they were farther away.

Lecture reference: 0:08–7:20

## Shortest-path expansion, stopping, and guarantees

> The search always expands the partial path with the smallest accumulated distance traveled, without estimating the remaining distance to the goal. After a goal length is known, it stops only when every remaining candidate has accumulated length at least that amount. With non-negative edge lengths, this guarantees a shortest path; zero-length edges may produce additional paths of the same shortest length.

### Expansion rule

Begin with the path containing only the start node, whose accumulated length is 0. At each step, compare all currently extendable paths and expand the one with the shortest accumulated length. This criterion concerns only how far the search has traveled, not an estimate of how far a path remains from the goal.

- In the worked graph, paths include S→A with length 3, S→B with length 5, S→A→B with length 7, and S→B→A and S→B→C with length 9.
- The search first expands S→A rather than S→B because 3 < 5.
- Extending S→A produces S→A→B with length 7 and S→A→D with length 6; the length-6 path is then selected.

### Stopping after finding a goal

1. Continue expanding the shortest accumulated path until a goal is encountered.
2. When the first goal is reached, continue processing the shortest unexpanded candidates rather than stopping immediately.
3. Stop when every remaining candidate has accumulated length at least the discovered goal length.

If a path has already reached the known goal length, extending it cannot produce a shorter solution. A path with accumulated length greater than the known goal length can also be discarded. The oracle is therefore not required: the search verifies the result by checking that no remaining unexpanded path can lead to a shorter solution.

In the example, S→A→B→C reaches the goal with length 11. The remaining candidates S→B→A→D have length 12 and S→B→C→E have length 15, so neither is extended. Starting from S, the considered lengths are 3, 5, 6, 7, and two paths of 9; the length-6 path reaches the goal at total length 11. Remaining candidates lead to lengths 11, 12, and 15, confirming that 11 is shortest.

### Guarantee and zero-length edges

> The guarantee depends on non-negative path lengths. With non-negative lengths, extending a path cannot reduce its accumulated length, so the method guarantees a path no longer than any other possible path.

- Before a goal is found, every explored partial path is shorter than the eventual goal path because the goal path is not yet known.
- Zero-length edges do not invalidate the shortest-path guarantee.
- An equal-length extension is possible only through zero-length edges, so equal-length alternatives may still exist.
- Handling all equal-length alternatives is an implementation detail.

Lecture reference: 7:20–15:22

## Larger-map application and priority-queue procedure

> The lecture applies the same search ideas to a more complicated map of Cambridge. The procedure repeatedly examines the shortest path currently on the queue, stopping when it reaches the goal or extending it and resorting the queue.

### Context

The next activity applies the shortest-path idea to the larger map. The lecture briefly recalls a depth-first traversal, which is explicitly characterized as not being a short path.

### Search procedure

1. Initialize the queue.
2. Test the first path on the queue.
3. If it reaches the goal, stop. Because the queue is sorted by path length, every other queued path is at least as long and cannot produce a shorter goal path.
4. If it does not reach the goal, extend it, place all extensions back on the queue, sort the queue, and repeat.

Lecture reference: 7:20–15:22, 15:22–24:24

## Extended lists and redundant-work reduction

> For optimal-path search, duplicate prevention must be based on nodes that have already been extended, not merely nodes that have appeared on the queue. An extended list avoids repeated expansions while preserving the shortest-path search, although the method may still examine many paths.

### Why queued-node prevention is insufficient

A queued-node list prevents adding paths that terminate at nodes previously placed on the queue, but that criterion is insufficient for this optimal-path search. The relevant rule is to extend the first path only if its terminating node has not already been extended. If a node was already reached and extended by a shorter path, extending another path to that same node cannot improve the result.

**Correction to the earlier statistic label**

> Although an N-queued approach worked in the prior search, only the extended-node criterion works here because every extended path must be known to be short enough to justify expansion.

### Effect on redundant work

The unpruned procedure can perform substantial redundant work. Maintaining an extended list can prune large portions of the search tree by eliminating extensions that revisit nodes already extended by shorter paths. The lecture tracks the number of extensions as a comparison statistic.

- In the discussed run, 1,354 paths were placed on the queue and 835,000 paths reached the front of the queue and were extended.
- The extended-list method still examines many paths, but it eliminates extensions that revisit nodes already extended by shorter paths.
- The initial procedure was reported as performing 835 extensions in the referenced comparison case; the lecture then changes the method to branch-and-bound with an extended list and begins a slower demonstration to compare the resulting work.

### Small-graph demonstration

1. Starting from S, the search considers A at length 3 and B at length 5, then expands the currently shortest available path.
2. The expansion through A produces candidate path lengths 7 and 6.
3. Expanding B produces candidate path lengths 9 and 9, followed by a path to G of length 11 through D.
4. When a shortest queued path reaches B again, it is not extended because B has already been extended by a shorter path.
5. Paths reaching A again are likewise skipped because A has already been extended.
6. Only the path reaching C still requires expansion, producing E at length 15 before the example finishes.

The example demonstrates that previously extended nodes allow substantial pruning compared with examining every repeated path, while preserving the shortest-path search.

Lecture reference: 15:22–24:24

## Branch-and-bound pruning with airline-distance lower bounds

> Branch-and-bound improves branching by discarding partial paths that cannot possibly produce the best complete path. It estimates each candidate’s potential total as accumulated distance plus airline distance to the goal, then expands the candidate with the smallest estimate. In the example, this required 38 extensions instead of 835; using only the airline-distance lower bound required 70 extensions, so the comparison favored the extended-list method for this particular problem, without establishing a general result.

### Pruning principle and lower bounds

The method is an efficiency improvement layered on top of branching, not a separate algorithm. Its underlying principle is to stop extending paths that are provably unable to produce the best solution. A partial path’s accumulated distance plus the airline distance to the goal provides a lower bound on any complete path extending that partial path.

**Potential total distance**

```latex
\text{estimated total} = \text{accumulated distance} + \text{airline distance to the goal}
```

The estimate is a lower bound on the total distance of any complete path extending the partial path.

**Why the estimate is a lower bound**

- A path that has already traveled a distance of 5 cannot have a total length below 5.
- If a direct straight-line route between two locations would have length 6 but no such road exists, 6 is still a lower bound on the actual remaining route.
- The airline-distance estimate is admissible because it is guaranteed to be no greater than the actual remaining distance.

### Search order in the example

The search evaluates candidate paths using accumulated distance plus airline distance and expands the candidate with the smallest potential total. From S, the accumulated distances to A and B are 3 and 5. The airline distance from A to G is slightly more than 7, producing a score slightly above 10; the airline distance from B to G is 6, producing a score of 11.

**Candidate expansion**

1. From S, consider the paths through A and B using their accumulated distances and airline distances to G.
2. Select the path with the smallest estimated S-to-G distance.
3. From A, the paths through B and D both receive a score of 11.
4. Resolve the tie lexically by selecting B before D.
5. Expanding through B produces a path to G with accumulated distance 11 and airline distance 0, for a final score of 11.

**Search scores in the example**

```text
S -> A: accumulated distance = 3
S -> B: accumulated distance = 5
S -> A -> B: accumulated distance = 7; airline distance = 6; score = 13
S -> A -> D: accumulated distance = 6; airline distance = 5; score = 11
S -> B -> A: accumulated distance = 9; airline distance = 7; score = 16
S -> B -> G: accumulated distance = 11; airline distance = 0; score = 11
```

The path through D and the path through B initially tie at 11, so B is expanded first by the lexical tie-break rule.

### Comparison with the extended-list method

**Extensions in the cited comparison**

- Unpruned branching search: 835 extensions.
- Branch-and-bound search: 38 extensions.
- Search using only the airline-distance lower bound: 70 extensions.
- The heuristic search performs considerably less work than the unpruned branching search in practical cases.
- The extended-list method required fewer extensions than using only the airline-distance lower bound, so it appeared more useful for this case.

**Qualification about the comparison**

> The comparison is not conclusive in general because performance depends on the problem itself. The instructor challenges the preliminary conclusion that the extended list is generally better than the admissible heuristic. Changing the problem may change which method performs better.

**Proposed altered test**

The lecture proposes testing the methods on a changed problem by starting the search in the middle rather than at the extreme left. No result from that altered problem is supplied in this span.

Lecture reference: 24:26–33:37

## Comparing improvements and A* implementation

> An extended list and an admissible heuristic can each improve branch-and-bound, but their effectiveness depends on the problem instance. A* combines both with branch-and-bound and selects paths using accumulated distance plus estimated remaining distance.

### Comparing the improvements

The two improvements do not have a fixed relative advantage. In one case, the admissible heuristic performed much better; in another, the extended-list method performed better. Their usefulness depends on the structure of the space being explored.

- Baseline branch-and-bound required 57 extensions in the demonstrated case.
- Using an admissible heuristic reduced the count to 6 extensions.
- Using an extended list alone reduced the count to 35 extensions in another comparison.
- On the original problem, A* required 27 extensions, outperforming either component used independently in the comparison.

The extended list prevents repeating movements through the same node, but it does not use the remaining airline distance to the goal. Consequently, it may still explore an unpromising region such as the left side. Combining the extended list with the admissible heuristic is desirable because each method can provide benefits that the other lacks.

### A* search and evaluation

A* is described as branch-and-bound plus an extended list plus an admissible heuristic. In another starting position, the extended list provided no additional benefit because the admissible heuristic already directed the search tightly toward the goal.

```latex
f(n)=g(n)+h(n)
```

The evaluation combines accumulated distance with the admissible estimate of remaining distance.

A* extends paths according to accumulated distance plus the admissible estimate of remaining distance. Sorting paths by this value is potentially expensive, so the algorithm does not need to sort all candidate paths.

1. Keep track of the candidate path with the minimum evaluation value.
2. Select the next path to test based on accumulated distance plus estimated remaining distance.
3. Continue without requiring the entire list of candidate paths to be sorted.

Lecture reference: 33:42–42:28

## Limits of admissibility and heuristic consistency

> Admissibility prevents a heuristic from overestimating the true remaining distance, but it may be insufficient in deliberately pathological, non-geometric graphs when already extended nodes are not reopened. Consistency imposes a stronger relationship between heuristic estimates and actual link distances and is presented as preserving optimal results in such cases.

### Admissibility in map-based and abstract search

An admissible heuristic is sound for optimal search in the map-based setting discussed. However, search problems are not limited to geographic maps: links may represent relationships in a model that is not geometrically accurate. Such non-Euclidean or abstract arrangements can produce pathological cases.

**Admissibility condition**

```latex
h(X) \le d(X, goal)
```

The estimate from X to the goal does not exceed the actual remaining distance.

Here, h(X) is the estimated distance from X to the goal, while d(X, goal) is the actual distance from X to the goal. The lecture also clarifies that a search evaluation adds the distance already traveled to the estimated distance remaining.

### Pathological graph example

- The graph includes paths S-A-C-G and S-B-C-G. The supplied link distances are 1, 1, 1, and 10 on one route, and 100 on the other indicated link.
- The heuristic estimates are 100 at A, 0 at B, and 0 at C.
- The estimate 0 is always an underestimate. The estimate 100 at A is admissible because the actual remaining distance from A to G is 101.
- Thus, the listed estimates form an admissible heuristic set even though the graph is deliberately pathological.

**Initial path evaluations**

```latex
1+100=101 \qquad 1+0=1
```

The path through A has accumulated distance plus heuristic 101, while the path through B has evaluation 1.

A* therefore expands the path through B first. Following this heuristic reaches C with accumulated distance 11 and then the goal with total distance 111. After extending A, the route S-A-C gives C an accumulated distance of 2 and an estimate of 0, for an evaluation of 2. Because C has already been extended, the algorithm does not reopen it and fails to find the shorter path of cost 2.

**Qualification**

> The example remains unresolved at the transcript boundary while the lecturer explains that the links need not form a geometrically accurate map. The lecture contrasts this non-geometric case with map-like geometric search, where admissibility is presented as sufficient.

### Consistency as a stronger condition

**Consistency condition**

```latex
|h(X)-h(Y)| \le d(X,Y)
```

The difference between heuristic estimates at two nodes cannot exceed the actual distance between them.

- Admissible: h(X) does not exceed the actual remaining distance from X to the goal.
- Consistent: the heuristic estimates at two nodes differ by no more than the actual distance between those nodes.
- With heuristic values 100 and 0 and an actual connecting distance of 2, admissibility holds, but consistency fails because |100 − 0| = 100 > 2.
- If the estimate at the first node were 2 instead of 100, the heuristic would remain admissible and would also satisfy consistency.

The lecture predicts that admissible heuristics can be made to lose in such cases, whereas consistent heuristics still yield the optimal result.

Lecture reference: 33:42–42:28, 42:28–48:22

## Search-efficiency trade-offs

> Branch-and-bound can be computationally very costly, potentially exponential in the distance to the goal. Search therefore tracks already extended nodes and may combine this extended list with an admissible or consistent heuristic to find an optimal path more practically.

### Balancing optimality and computational cost

Branch-and-bound without additional guidance can be extremely expensive, potentially requiring computation that is exponential in the distance to the goal. The overall objective is to preserve an optimal path while using heuristic information to make the search computationally practical.

**Key mechanisms and connections**

- An extended list tracks nodes that have already been extended.
- Depending on the circumstances, the extended list can be combined with an admissible or consistent heuristic.
- The lecture connects these principles to how MapQuest and its descendants find paths that are both optimal and heuristically efficient.

Lecture reference: 42:28–48:22

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
