# Study notes



## Search problem framing and choice

> The search problem is to choose the very shortest path between two nodes, rather than merely any workable or reasonably good path. Maps provide convenient visual examples, but the broader subject is choosing among alternatives.

### The goal of search

The goal is to find the very shortest path between two nodes, not simply any workable or reasonably good path. Finding the best path is presented as a skill expected from someone who has taken an artificial intelligence course, even though it may not directly model an obvious mental process.

### Maps as visual examples

Maps are convenient visual examples for search, and map-based examples make the concepts behind the algorithms easier to visualize. A person can often identify a good path visually, but cannot reliably determine the best possible path.

- Route 66 is used as an intuitive example of a historically important direct route between Chicago and Los Angeles.
- The lecture uses both a Cambridge example and a Blackboard example.

### The underlying issue

> Although the examples use maps and routes, the general subject is choosing among alternatives rather than navigating maps specifically. The underlying issue is choice.

Lecture reference: 0:08–7:20

## Heuristic distance

> Heuristic distance is the straight-line, or crow-flight, distance between two locations, whether or not a connecting road exists. States closer to the goal are generally preferred, although this measure can be misleading when a nearby node is a dead end.

### Definition and general use

Heuristic distance measures the straight-line, or crow-flight, distance between two locations, regardless of whether a connecting road exists. In general, a state that is closer to the goal by heuristic distance is considered preferable.

### Role in search examples

- Being close to the goal was the objective in hill climbing and beam search.
- Heuristic distance can be misleading: node E appears close to G but is a dead end in the example.

In a prior beam-search example, candidates at C, B, A, and D were compared by airline distance. D and B were retained, while A and C were rejected because they were farther from the goal.

Lecture reference: 0:08–7:20

## Shortest-path search and branch-and-bound flow

> A candidate route such as S → A → D → G, with length 11, must be verified against other possible routes. The search always expands the frontier path with the smallest accumulated length and can stop at a goal when the queue is sorted and all edge lengths are non-negative.

### Candidate route and verification

The proposed route is S → A → D → G, with a total path length of 11. The instructor treats this answer as an oracle-based initial hypothesis rather than unquestionable truth. Verification requires developing the other possible paths and showing that each is definitely longer than 11.

A general problem-solving strategy is to ask someone who knows the answer, or consult a source such as Google, and then verify the result. In this setting, the oracle supplies a possible goal distance, but the search can also establish the shortest path without an oracle.

### Search principle

Starting from S with distance 0, the algorithm considers only the accumulated path length so far; it does not use heuristic estimates of the remaining distance to the goal. Frontier paths are expanded in increasing accumulated-length order.

- The search repeatedly examines the shortest path currently on the queue.
- The worked graph expands paths in an order such as S→A with length 3, S→B with length 5, S→A→B with length 7, and so on.
- A path is not extended further when its accumulated length is already equal to or greater than a known goal-path length, assuming all edge lengths are non-negative.
- If a frontier path has accumulated length equal to the goal length, it cannot produce a strictly shorter solution. It could produce another equally short path only through zero-length extensions.

### Queue procedure

1. Initialize the queue.
2. Test the first path on the queue.
3. If the first path reaches the goal, terminate. Because the queue is sorted by path length, every other queued path is at least as long and cannot yield a shorter goal path.
4. If the first path does not reach the goal, extend it, put all extensions back on the queue, sort them by path length, and repeat.

### Worked paths and optimality check

With an oracle-provided goal distance of 11, S→A→B→C reaches length 11 and need not be extended. Other candidates reach lengths 12 and 15, so they cannot improve the result.

Without using the oracle, the search expands S→A with length 3, then S→B with length 5. It next compares S→A→D with length 6, S→A→B with length 7, and two paths of length 9. S→A→D reaches the goal with total length 11; the remaining paths are checked to establish optimality.

> After reaching the goal with length 11, the remaining candidate paths have lengths 11, 12, and 15 after their possible extensions, so none improves the solution.

### Guarantee and scope

With non-negative edge lengths, the method guarantees a path as short as any possible path. There may be multiple shortest paths when zero-length edges exist.

The search may explore many alternative paths and can approach a pathological or exhaustive-search case before finding the shortest path. The lecture then transitions to applying the same comparison to a more complicated map of Cambridge, after briefly contrasting it with depth-first search.

Lecture reference: 0:08–7:20, 7:20–15:22, 15:22–24:24

## Extended lists and repeated-path pruning

> Optimal-path search must track nodes whose paths have already been extended, not only nodes represented by queued paths. This prevents later, longer paths to an already extended node from being extended again, while preserving the shorter-path guarantee and pruning repeated work.

### Why the queued-list rule is insufficient

A queued-list rule prevents adding paths that terminate at nodes already represented by queued paths. However, it does not ensure that the retained path is the shortest path that will be extended. The relevant condition is to extend the first path only when its endpoint has not already been extended.

**Terminology**

> The instructor noted that a prior statistic or column labeled “N queued” should have been labeled as extended for this use case.

### Pruning repeated extensions

If a node has already been reached and extended through a shorter path, extending a later, longer path to the same node cannot produce a better solution. An extended list therefore prunes repeated work and can remove large regions of the search tree.

1. From S, the initial paths reach A with length 3 and B with length 5.
2. Extending A produces paths to B and D with lengths 7 and 6. The path to B is disregarded because B is already represented by a shorter path from S.
3. The shortest available path is then the one to B, which is extended to A and C with lengths 9 and 9.
4. The path to D is next extended to G with length 11.
5. A later path to B is not extended because a path to B has already been extended.
6. Later paths to A are also skipped because A has already been extended. Only the path to C needs extension, producing E with length 15.

The paths to B and A that appear after their earlier extensions are skipped; the remaining extension reaches E at path length 15. The example illustrates that the extended list prunes repeated extensions while preserving the shorter-path guarantee.

### Reported search work

- One reported run placed 1,354 paths onto the queue.
- The same run extended 835,000 paths that reached the front of the queue.
- For a separate stated case, the number of extensions was given as 835 before applying the extended-list concept.

### Branch-and-bound demonstration

The instructor began a slower demonstration of branch-and-bound with an extended list to compare its behavior, but the supplied span does not report the final result.

Lecture reference: 15:22–24:24

## Lower-bound pruning with admissible heuristics

> Lower-bound pruning discards a path when it cannot possibly lead to a winning solution. The lower bound is the accumulated distance plus a heuristic estimate of the remaining distance. If the heuristic never exceeds the actual remaining distance, it is admissible and supports safe pruning. Candidates are extended in order of smallest potential total distance, with lexical order breaking ties.

### Lower bounds and admissibility

A path is discarded as soon as it cannot possibly be part of a winning solution, avoiding unnecessary extensions. This is an efficiency improvement layered onto branching, not a different algorithm.

**Possible-total lower bound**

```latex
\text{lower bound} = \text{accumulated distance} + \text{airline distance to the destination}
```

The accumulated distance is the distance already traveled, and the airline distance estimates the remaining distance.

The airline distance may represent an impossible straight-line route, but it is still a lower bound because no actual road path can be shorter than it. A heuristic is called admissible when its estimate is guaranteed not to exceed the actual remaining distance, so it does not overstate the possible minimum cost.

**Basic consequences**

- A path that has already traveled distance 5 cannot have a total length below 5.
- If the airline distance from the current location to the goal is 6, a path with accumulated distance 5 has a possible-total lower bound of 11.
- The method can perform substantially less work than an unpruned search.

### Choosing and extending candidate paths

At each step, the search extends the path with the smallest potential total distance. Lexical order breaks ties between candidates with the same score.

**Demonstrated candidate ordering**

1. The path through B has accumulated distance 5 and airline distance 6 to G, giving a score of 11.
2. The path through A has accumulated distance 3 and an airline distance slightly greater than 7, giving a score slightly greater than 10. The lecture describes this as 10-plus and compares candidate paths by their resulting lower-bound scores.
3. From A, S-A-B has accumulated distance 7 and airline distance 6, for a score of 13, while S-A-D has accumulated distance 6 and airline distance 5, for a score of 11.
4. When the two best candidates tie at 11, B is expanded before D because it is lexically earlier.
5. Expanding S-B reaches G with accumulated distance 11 and airline distance 0, producing a score of 11, lower than the other candidates.

### Work reduction and comparison

**Methods in the cited comparison**

- Unpruned search: the lecture describes lower-bound pruning as a way to avoid unnecessary extensions and notes that a calculation might otherwise take longer than the remaining lifetime of the universe but could sometimes finish in seconds.
- Airline-distance admissible heuristic: the demonstrated example used 70 extensions.
- Extended-list method: the cited comparison used 38 extensions, so it performed better than the admissible lower-bound heuristic in that instance.

**Qualification about performance**

> The comparison is not universal. Performance depends on the problem itself, and changing the starting position or problem can change the result. A single example is insufficient to conclude that extended lists are always superior to admissible heuristics.

Lecture reference: 24:26–33:37

## A* search

> A* combines branch-and-bound, an extended list, and an admissible heuristic. It ranks paths by accumulated distance plus estimated remaining distance, extending only the path with the smallest evaluation value. In the original problem, A* required 27 extensions; results in another test were 57 for baseline branch-and-bound, 6 with the heuristic alone, and 35 with the extended list alone.

### Core idea

An extended list prevents repeated movements through the same node, while an admissible heuristic estimates the remaining distance to the goal. Combining both produces A*. Paths are ranked by accumulated distance plus the admissible heuristic, rather than by accumulated distance alone.

**Path evaluation**

```latex
f(path)=g(path)+h(path)
```

Here, g(path) is the accumulated distance and h(path) is the admissible estimate of the remaining distance to the goal.

A* expands the path with the smallest sum of accumulated distance and estimated remaining distance. A complete sort is unnecessary: the algorithm only needs to keep track of which path currently has the minimum evaluation value and extend that path.

### Contributions of the two techniques

- The extended list avoids repeated node movements but does not know the remaining airline distance to the goal.
- The admissible heuristic estimates the remaining distance and channels the search toward the goal.
- The extended list and admissible heuristic provide different benefits, so using both can outperform either independently.

**Qualification**

> The benefit of the extended list depends on the search space. When the heuristic channels the search tightly toward the goal, the extended list may add no improvement.

### Extension counts

- Baseline branch-and-bound: 57 extensions
- Admissible heuristic alone: 6 extensions
- Extended list alone: 35 extensions
- A*: 27 extensions

In the original problem, A* required 27 extensions, substantially fewer than either technique used alone.

Lecture reference: 33:42–42:28

## Limits of admissibility and consistency in non-map graphs

> Admissibility is sufficient for optimal search in map-like geometric settings, but it can fail in a general non-geometric graph. A consistent heuristic strengthens admissibility by constraining heuristic differences across connected nodes and retains the optimality guarantee in the general case.

### Why non-map graphs create a problem

The apparent safety of admissibility comes partly from working with a map. Search spaces may instead model other systems with arbitrary link costs, so their arrangements need not be geometrically accurate. In such non-Euclidean arrangements, an admissible heuristic can still lead the search to overlook a shorter route.

**Scope of the lecture material**

> The lecture introduces a small pathological graph to demonstrate this issue, but the supplied transcript ends before the explanation and simulation are complete. The instructor emphasizes that displayed link costs may be arbitrary because the graph may model something other than a physical map.

### Pathological search example

```text
Graph structure: S connects to A and B; A and B merge at C; C connects to G.
Actual link distances: S-A = 1, S-B = 1, A-C = 1, B-C = 1, C-G = 10, with another indicated link assigned 100.
Heuristic estimates shown: one node = 100, two nodes = 0.
```

The graph uses arbitrary link costs and heuristic estimates to illustrate failure in a non-geometric setting.

The estimate of 100 is admissible for the node whose actual remaining distance is 101, and an estimate of 0 is always an underestimate. From S, the path through A is evaluated as 1 + 100 = 101, while the path through B is evaluated as 1 + 0 = 1, so A* selects the path through B first. Here, “actual” distance means the distance already traveled, which is added to the estimated distance remaining.

1. A path through C reaches the goal with total cost 111 and estimated remaining distance 0.
2. After A is extended and B is reached through another route, the accumulated distance is 2 and the heuristic estimate is 0, giving priority 2.
3. Because that node has already been extended, the algorithm stops without finding the shorter path.

**Result**

> Branch-and-bound with an extended list works in this setting, but adding an admissible heuristic is not sufficient for a non-geometric graph. The issue does not arise in the same way when the graph is a geometrically represented map.

### Admissibility and consistency

A heuristic is admissible when its estimated distance to the goal never exceeds the actual distance to the goal. For any node X, the estimated distance from X to the goal must be less than or equal to the actual distance from X to the goal.

**Admissibility**

```latex
h(X) \leq d(X,G)
```

Here, h(X) is the estimated distance from X to the goal, and d(X,G) is the actual distance from X to the goal.

Consistency strengthens admissibility by requiring heuristic differences between any two connected nodes to be no greater than their actual distance apart.

**Consistency**

```latex
|h(X)-h(Y)| \leq d(X,Y)
```

Here, h(X) and h(Y) are heuristic estimates for connected nodes X and Y, and d(X,Y) is their actual distance apart.

**Conditions in the example**

- The heuristic values 100 and 0 differ by 100 across an edge whose actual distance is 2.
- The heuristic remains admissible but violates consistency because |100 - 0| = 100 > 2.
- Changing the relevant estimate from 0 to 2 would preserve admissibility and satisfy consistency in the intended graph configuration.
- A consistent heuristic retains the desired optimality guarantee in the general case where an admissible heuristic may fail.

Lecture reference: 33:42–42:28, 42:28–48:22

## Practical Search Strategy and Computational Cost

> Branch-and-bound can be computationally prohibitive, potentially requiring exponential effort in pathological cases. An extended list prevents repeated expansion of processed nodes, while admissible or consistent heuristics guide the search toward an optimal path efficiently.

### Computational cost and search strategy

Using only branch-and-bound may be computationally prohibitive, including in pathological exponential cases. Search should therefore exploit an extended list and the strongest applicable heuristic information.

**Key components**

- An extended list avoids repeatedly expanding already processed nodes.
- Depending on the circumstances, search should use an extended list together with an admissible or consistent heuristic.
- The overall objective is to find an optimal path while using heuristics to guide the search toward a heuristically good path.

Lecture reference: 42:28–48:22

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 5: Search: Optimal, Branch and Bound, A*. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=gGQ-vAmdAOI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-5-search-optimal-branch-and-bound-a/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
