# Study notes



## If-Then Rules

> If-then rules are a simple and fast method for evaluating potential chess moves. They rely on a set of predefined rules that determine the best move based on the current board state without considering future consequences.

### Examples

**Example 1**

- If the Queen is on the opponent's side, perform a pawn promotion.

### Example 2

**Example 2**

- If the King is in check, capture it immediately.

Lecture reference: 0:08–8:10

## Static Evaluation

> Static evaluation is a process by which the AI evaluates the current state of the board using a scoring polynomial, considering features like pawns and the King's safety.

### Features

**Pawns**

- Pawns are the pieces that control the center of the board, and their movement and placement can significantly impact the outcome of the game.

**King's Safety**

- The King's safety is crucial because it can block multiple lines of attack and restrict the opponent's options.

**King's Position**

- The King's position can affect the overall strength of the position, as it can control key squares and limit the opponent's mobility.

**Pawn Structure**

- The structure of pawns, including their color, starting position, and movement rules, can influence the game's development and potential outcomes.

**Steps**

1. 1. Analyze the current board state and identify key features like pawns and the King's safety.
2. 2. Calculate scores for each feature based on their impact on the game.
3. 3. Sum the scores to arrive at an overall evaluation of the position.

Lecture reference: 0:08–8:10

## Machine Learning Approaches

> Machine learning approaches involve training algorithms to learn patterns from data.

### The Engine Uses Historical Game Data

**The engine might use reinforcement learning to improve its moves based on outcomes of game**

- reinforcement learning
- neural networks
- deep learning

### The Engine Adjusts Strategies

**The engine uses historical game data to improve its decision-making**

- game data
- decision-making

Lecture reference: 0:08–8:10

## Deep Blue's Chess Outcome

> Deep Blue's victory in the World Computer Chess Championship in 1997 is a landmark in AI history.

### Result

**Deep Blue won the World Computer Chess Championship in 1997.**

- Deep Blue won the World Computer Chess Championship in 1997.

**Step 1: Deep Blue's victory demonstrated the potential of AI in chess.**

1. Step 1: Deep Blue's victory demonstrated the potential of AI in chess.

**Comparison**

- It was one of the earliest successful chess-playing AI systems.

**None**

Lecture reference: 0:08–8:10

## Chess Theory

> Chess is a complex game with a large tree of possibilities, making static evaluations impractical for optimal decision-making. The minimax algorithm is used in chess programs to make optimal decisions.

### Chess is a game with a large tree of possibilities.

**Chess is a game with a large tree of possibilities.**

- Chess is a game with a large tree of possibilities.
- The branching factor and depth of this tree are significant.
- The number of leaf nodes is astronomically large, making static evaluations impractical.
- The minimax algorithm is used in chess programs to make optimal decisions.
- Cloud computing is mentioned as a way to handle the computational load of these evaluations.

### The minimax algorithm is used in chess programs to make optimal decisions.

**The minimax algorithm is used in chess programs to make optimal decisions.**

- The minimax algorithm is a recursive algorithm that evaluates game states to make optimal decisions.
- It uses the concept of minimization and maximization to explore possible game outcomes.
- The algorithm assigns a value to each possible game state based on the best possible move.
- The minimax algorithm is used to determine the best possible move in a game of chess.
- It is widely used in chess programs to make optimal decisions.

### A simple game tree with a small depth and branching factor.

**A simple game tree with a small depth and branching factor.**

- A simple game tree with a small depth and branching factor.
- The minimax algorithm can be applied to evaluate such trees.
- The algorithm explores all possible game states up to a certain depth.
- The minimax algorithm can provide an optimal decision in a simple game tree.
- A simple game tree with a small depth and branching factor can be evaluated optimally.

### A chess program using the minimax algorithm to evaluate game states.

**A chess program using the minimax algorithm to evaluate game states.**

- A chess program uses the minimax algorithm to evaluate game states.
- The minimax algorithm explores all possible game states and determines the best outcome.
- The algorithm evaluates game states recursively, considering all possible moves.
- A chess program can use the minimax algorithm to make optimal decisions.
- A chess program can evaluate game states and determine the best move.

Lecture reference: 8:10–17:44

## Minimax and Alpha-Beta Pruning

> A decision-making tool used in game theory and AI to evaluate all possible moves in a game. It determines the best possible outcome by evaluating all possible moves a player can make. Alpha-beta pruning is an optimization technique that reduces the number of nodes evaluated in the minimax algorithm by pruning branches that cannot yield a better result than the current best outcome.

### Purpose of Minimax

**Evaluate all possible moves to determine the best possible outcome.**

- A decision-making tool used in game theory and AI to evaluate all possible moves in a game.
- Determines the best possible outcome by evaluating all possible moves a player can make.
- Optimizes the minimax algorithm by reducing the search space.
- Reduces the number of nodes evaluated in the minimax algorithm.

### Examples of Minimax

**Examples of Minimax in Games**

- Used in adversarial games like chess.
- Optimized for games with large game trees.
- Prunes branches that cannot improve the outcome beyond current best.
- Evaluates all possible moves to determine the best possible outcome.

### How Minimax Works

**How Minimax Works**

- Evaluates all possible moves a player can make.
- Determines the best possible outcome by considering all possible moves.
- Prunes branches in the game tree that cannot yield a better result than the current best outcome.
- Focuses on the most promising moves to reach the best possible outcome.

### Alpha-Beta Pruning

**Alpha-Beta Pruning**

- A technique that reduces the number of nodes evaluated in the minimax algorithm by focusing on the most promising paths.
- Prunes branches in the minimax tree that do not need to be explored further.
- Improves the efficiency of the minimax algorithm by reducing the search space.
- Reduces the computational complexity of evaluating game trees.

Lecture reference: 17:44–24:55

## Game Trees

> A game tree is a hierarchical representation of possible game outcomes, illustrating all possible sequences of moves and their results. It is used in game theory to evaluate strategies and predict optimal moves by considering all possible paths and selecting the one that maximizes the minimum gain.

### What is a Game Tree?

**A representation of possible game outcomes.**

- A hierarchical structure showing all possible game sequences and their results.

### How is a Game Tree Used?

**1. To visualize all possible game outcomes.**

- 1. To illustrate all possible game paths and their outcomes.

### The Minimax Algorithm

**The Minimax Algorithm**

- A decision-making algorithm used in game theory to find the optimal move by evaluating all possible paths and selecting the one that maximizes the minimum gain.

Lecture reference: 24:55–32:55

## Game Playing Algorithms

> Game playing algorithms, including minimax, alpha-beta, and progressive deepening, are essential for improving performance in complex games. These algorithms work together to explore all possible moves, ensuring optimal decisions are made as soon as possible. The text discusses the impact of these algorithms on performance and their distinction between human and machine intelligence, emphasizing their role in enhancing AI's decision-making capabilities in games.

### Game Tree Structure

**Game Tree Structure**

- Game Tree Structure
- Explain the structure of game trees and how they are used in minimax algorithms.
- Minimax Algorithm
- Describe how the minimax algorithm works to make optimal decisions by exploring all possible moves.
- Progressive Deepening
- Explain the concept of progressive deepening and its role in reducing computational load.
- Balancing Accuracy and Performance
- Discuss the trade-off between computational efficiency and accuracy in game algorithms.
- Large Trees and Performance Issues
- 1. Game playing algorithms are essential for improving performance in complex games.

Lecture reference: 32:55–40:53, 40:53–48:01

## Alpha-Beta Pruning

> Alpha-Beta pruning is a technique used to optimize minimization algorithms by maintaining upper and lower bounds (alpha and beta) to eliminate branches that cannot lead to an optimal outcome.

### Alpha

**Alpha (alpha):**

- The best value the current player can achieve.

**Beta**

- The best value the opponent can achieve.

### How it works

**How it works**

1. 1. Initialize alpha and beta.
2. 2. Evaluate the current node's value.
3. 3. If the node's value is better than beta, prune that branch.
4. 4. If the node's value is better than alpha, update the node and move to the next.

### Formula

**Beta = max(max(next level's value), Beta)**

```latex
Beta = oxed{	ext{max(max(next level's value), Beta)} }
```

**Alpha = min(min(next level's value), Alpha)**

```latex
Alpha = oxed{	ext{min(min(next level's value), Alpha)} }
```

Lecture reference: 24:55–32:55

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 6: Search: Games, Minimax, and Alpha-Beta. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=STjW3eH0Cik) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-6-search-games-minimax-and-alpha-beta/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
