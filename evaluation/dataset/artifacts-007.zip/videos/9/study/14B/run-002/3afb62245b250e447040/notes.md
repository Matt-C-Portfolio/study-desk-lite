# Study notes



## Computational Efficiency in Neural Networks

> Computational efficiency in neural networks arises from the reuse of shared computations in calculating partial derivatives, enabling linear scaling of network depth rather than exponential growth. This redundancy reduction is crucial for optimizing training and inference processes.

### Shared Computations in Partial Derivatives

**Key Concepts**

- Partial derivatives of performance with respect to weights share common computations.
- Reusing computations reduces redundant calculations.

Lecture reference: 0:00–8:33

## Biological Inspiration in Neural Networks

> Neural networks mimic biological neural processing through mechanisms like weighted input summation and proportional response generation. The core operation of multiplying weights by inputs and summing them aligns with biological neuron behavior, supporting efficient computation.

### Key Mechanisms

**Neural Network Operations**

- Weights and inputs are multiplied and summed (dot product).
- Biological neurons produce proportional responses, supporting real dot product operations.

Lecture reference: 0:00–8:33

## Performance Evaluation of Neural Networks

> A deep neural network demonstrated strong performance with a 15% error rate when considering the top five answers and a 37% error rate when only the top choice was evaluated. This level of accuracy is notable, particularly given the presence of ambiguous inputs that could complicate decision-making processes.

### Performance Metrics

**Key Performance Indicators**

- Performance metrics: 15% error rate (top five answers)
- Performance metrics: 37% error rate (top one answer)

Lecture reference: 0:00–8:33

## Convolutional Neural Network Operations

> Convolutional neural networks (CNNs) perform operations involving kernels sliding over images to generate feature maps, reducing dimensionality through max pooling, and using multiple kernels to capture various features.

### Key Operations

**Process Overview**

- A kernel (e.g., 10x10) slides over the image to generate outputs at each position.
- Each output corresponds to a specific location in the image, creating a feature map.
- Max pooling is applied by selecting the maximum value in a local neighborhood, reducing dimensionality.
- The pooling operation is applied to the feature map, further reducing its size.
- A typical number of kernels is 100, each producing a feature map for subsequent layers.

Lecture reference: 8:33–17:18

## Neural Network Evolution and Comparison

> The evolution of neural networks has led to more powerful models with millions of parameters, thousands of classes, and large datasets, resulting in improved performance despite limited understanding of their success mechanisms.

### Old Methods

**Characteristics of Early Neural Networks**

- Limited parameters: Hundreds of parameters in early models.
- Few classes: A small number of output categories.
- Minimal examples: Training datasets were relatively small.

### Modern Methods

**Characteristics of Modern Neural Networks**

- Massive parameters: Modern models often have millions of parameters.
- Thousands of classes: Capable of distinguishing between numerous categories.
- Large datasets: Trained on extensive collections of data.

### Resulting Capabilities

**Performance and Understanding**

- Superior performance: Modern models outperform older ones significantly.
- Function approximation: They act as powerful function approximators.
- Limited understanding: The exact reasons for their success remain unclear.

Lecture reference: 8:33–17:18

## Training Methods and Architectures

> This section explores a training approach where each layer is sequentially trained, starting from the input, using self-supervised learning by comparing output to input values. The method involves pre-training hidden layers and fine-tuning output layers for specific tasks.

### Layer-wise Training

**Structure and Process**

- Input values feed into a hidden layer, which expands to an output layer.
- Output is compared to input values for self-supervised learning.
- Training progresses forward, layer by layer.
- Final layer uses class samples for fine-tuning.
- Pre-trained hidden layers are frozen, and output layers are retrained.

### Applications and Examples

**Use Cases**

This method is exemplified by autoencoders, used in tasks like image denoising. The model reconstructs inputs during pre-training and is fine-tuned for classification using labeled data.

Lecture reference: 8:33–17:18, 24:45–33:47, 33:47–42:10

## Case Studies and Network Interpretability

> This case study explores the challenges of interpreting neural network operations, particularly focusing on how hidden layers generalize and encode patterns. The example with animal shadow heights highlights the difficulties in understanding feature representation and the lack of clear correlation between hidden layer activity and input features. Despite advancements, interpretability remains a significant challenge in neural network research.

### Setup and Training

**Network Architecture**

- Three animals: cheetah (short), zebra (medium), giraffe (tall)
- Network input: 10 neurons for shadow height
- Hidden layer: 3 neurons compressing input
- Output layer: 10 neurons matching input
- Training goal: map input to output without explicit classification

### Challenges in Interpretability

**Training Results**

- Initial random weights produce uniform outputs
- Training reduces error but does not lead to clear generalization
- Hidden layer neurons do not specialize as expected
- Some neurons show random activation patterns
- Neural networks learn features without explicit instruction
- Interpretability of hidden layer activity remains unclear
- Challenges in understanding why networks recognize certain patterns
- Recent work has partially addressed interpretability but much remains unknown

### Examples and Observations

**Observed Patterns**

- Cheetah input results in low output values
- Zebra input results in medium output
- Giraffe input results in high output
- Neuron activation patterns do not match expected animal heights
- Lack of clear correlation between hidden layer activity and input features
- Inability to explain why a network recognizes a cheetah
- Limited understanding of feature responses in hidden layers

### Implications and Future Directions

The case study underscores the mystery of neural network operations and the challenges in interpreting hidden layer activity. While networks can generalize and learn features without explicit instruction, the lack of clear patterns in hidden layers highlights the need for more research into network interpretability. Recent advancements have partially addressed these issues, but significant mysteries remain about how neural networks recognize patterns and make decisions.

Lecture reference: 17:18–24:45

## Mathematical Foundations of Neural Networks

> Neural networks rely on mathematical functions like the sigmoid to convert inputs into probabilities, with weights and thresholds shaping the function's behavior. Gradient ascent optimizes these parameters to maximize data likelihood, ensuring outputs represent valid probabilities. Wide networks, with more neurons per layer, often outperform deeper ones in effectiveness.

### Sigmoid Function

**Properties and Parameters**

- The sigmoid function is defined as z = 1 / (1 + e^(-wx - T))
- T shifts the sigmoid function horizontally, affecting the midpoint
- w determines the steepness of the sigmoid curve
- Positive examples influence the alignment of the curve towards 1
- Ensures outputs are between 0 and 1, representing probabilities

### Gradient Ascent

**Optimization Process**

- Gradient ascent adjusts weights and thresholds to maximize the probability of the data
- Converts logits into probabilities by normalizing outputs to sum to 1
- Ensures outputs represent valid probability distributions

### Network Architecture

**Wide vs. Deep Networks**

- Wide networks have many neurons per layer, often leading to better performance than deeper networks
- Deeper networks may require more layers to achieve similar results
- Wide networks can capture complex patterns with fewer layers

### Network Example

**Five-Layer Network**

- A network with five layers was used to classify animals
- This architecture effectively balances complexity and performance

### Training Dynamics

**Initial Training Results**

- Initial training resulted in all outputs being 0.5, indicating no differentiation
- This issue was resolved with further iterations, improving model performance

Lecture reference: 24:45–33:47, 33:47–42:10

## Training Techniques and Regularization

> Dropout is a regularization technique that randomly deactivates neurons during training to improve model generalization by preventing overfitting. Each neuron has a probability of being dropped out in each iteration, introducing randomness and reducing co-adaptation of features.

### Concept

**Key Benefits**

- Improves generalization by introducing randomness.
- Reduces overfitting by preventing co-adaptation of neurons.

### Implementation

**Mechanism**

- Each neuron is independently deactivated with a probability (commonly 0.5).
- Deactivated neurons are temporarily removed from the network during training iterations.

Lecture reference: 33:47–42:10

## Network Architecture and Training Dynamics

> Network width plays a crucial role in optimization dynamics, influencing the ability to escape local maxima and navigate the loss landscape more effectively. Wider networks are generally more effective at avoiding problematic optimization points, making training more stable and efficient.

### Key Concepts

**Network Width and Optimization**

- Reducing the number of neurons per layer can increase the likelihood of encountering local maxima during training.
- Increasing network width helps convert problematic local maxima into saddle points, which are easier to escape during optimization.

Lecture reference: 42:10–49:00

## Perception and Learning in Neural Networks

> Neural networks process images through statistical patterns rather than human-like comprehension. They exhibit sensitivity to specific features and textures but struggle with recognizing subtle changes, highlighting the gap between human and machine perception.

### Key Characteristics

**Perception Limitations**

- Sensitivity to specific features and textures.
- Inability to recognize subtle changes in images.
- Examples demonstrate gap between human and machine perception.

Lecture reference: 42:10–49:00

## Multiple Output Neurons

> In multi-class classification tasks with many categories, each output neuron represents the probability of a specific class, and the softmax function is used to convert logits into a probability distribution.

### Neurons and Class Probabilities

**Key Points**

- 1,000 classes imply 1,000 output neurons.
- Each neuron's activation reflects its class's probability.

### Softmax Function

**Softmax Formula**

```latex
softmax(x_i) = \frac{e^{x_i}}{\sum_{j} e^{x_j}}
```

The softmax function converts logits into probabilities.

**Properties of Softmax**

- Maps logits to probabilities between 0 and 1.
- Sum of all outputs equals 1.

### Training and Loss Function

**Training Considerations**

- Uses cross-entropy loss for training.
- Optimizers like Adam or SGD adjust weights to minimize loss.

### Comparison with Binary Classification

**Comparison**

- Binary Classification: Single neuron with sigmoid activation.
- Multi-class Classification: Multiple neurons with softmax activation.

Lecture reference: 24:45–33:47

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 12B: Deep Neural Nets. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=VrMHA3yX_QI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-12b-deep-neural-nets/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
