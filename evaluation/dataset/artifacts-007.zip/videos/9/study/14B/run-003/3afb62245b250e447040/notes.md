# Study notes



## Neural Network Computations and Optimization

> Neural network computations rely on the chain rule and partial derivatives for weight updates. Despite the apparent complexity, computations exhibit redundancy, enabling efficient reuse of intermediate results. The computational process scales linearly with network depth, avoiding the pitfalls of exponential complexity.

### Mathematical Foundation

**Key Concepts**

- Partial derivatives and the chain rule form the basis of weight update computations in neural networks.
- Backpropagation efficiently computes gradients by reusing intermediate results, avoiding redundant calculations.
- The depth of the network determines the number of layers processed sequentially, ensuring linear computational scaling.

### Computational Efficiency

**Efficiency Considerations**

- Redundancy in computations allows for significant efficiency gains through the reuse of intermediate results.
- The linear scaling of operations with network depth ensures that computational complexity remains manageable.
- This linear relationship avoids the exponential complexity often feared in deep networks.

### Computational Complexity

**Complexity Analysis**

- The computational process scales linearly with the depth of the network, ensuring efficiency.
- This linear relationship simplifies the analysis and optimization of neural network computations.
- Avoiding exponential complexity is crucial for practical applications of deep learning.

Lecture reference: 0:00–8:33

## Fundamental Neural Network Operations

> Neural networks rely on the dot product as a core operation, which is biologically inspired. The dot product between weights and inputs drives neural computation, while non-linear activation functions like the sigmoid introduce complexity and enable learning of intricate patterns. This foundational concept bridges biological neural systems with their artificial counterparts, highlighting the importance of linear operations in neural network design.

### Core Neural Network Concepts

**Key Operations**

- The dot product between weights and inputs is central to neural network computation.
- Biological neurons approximate real dot products through their synaptic inputs and activation functions.
- Non-linearities, such as sigmoid functions, introduce complexity and enable the modeling of intricate patterns.

Lecture reference: 0:00–8:33

## Neural Network Performance Metrics

> Neural networks demonstrate varying performance levels in object recognition tasks. Top-five predictions achieve 85% accuracy, with a 15% error rate, while top-one predictions have 63% accuracy and a 37% error rate. Notably, these results are impressive given the inherent ambiguity and complexity of the tasks involved.

### Performance Metrics

**Key Metrics**

- Top-five predictions accuracy: 85% (error rate 15%).
- Top-one predictions accuracy: 63% (error rate 37%).
- Performance is notable given task ambiguity.

Lecture reference: 0:00–8:33

## Image Processing Techniques

> Image processing involves techniques like sliding kernels, local maxima, and feature extraction to reduce dimensionality and create compressed representations for neural network processing.

### Kernel Operations

**Kernel Sliding**

- A 10x10 kernel slides across a 256x256 image to generate outputs linked to specific locations.
- Outputs are associated with each position in the image.
- Process involves sliding window operations to find local maxima, reducing dimensionality.

### Feature Extraction

**Feature Maps**

- Produces a compressed representation of the image through kernel operations.
- Multiple kernels extract diverse features, enhancing the representation.
- Process repeated 100 times for thorough feature extraction.

### Neural Network Integration

**Integration Steps**

- Outputs from image processing are fed into a neural network for further processing.
- This integration allows for hierarchical feature learning and task-specific analysis.

Lecture reference: 8:33–17:18

## Self-Supervised Learning

> Self-supervised learning involves training neural networks to reproduce inputs by passing them through a smaller hidden layer, enabling generalization and pattern encoding. Autoencoders are a key technique in this approach, where the network learns to reconstruct its input by minimizing the difference between the output and the original input.

### How Autoencoders Work

**Key Components and Training**

- Involves input layer, hidden layer, and output layer
- Desired values are the input values themselves
- Network structure: Input → hidden layer → output
- Training objective: Output matches input
- Hidden layer acts as a bottleneck, encouraging generalization

Lecture reference: 8:33–17:18, 17:18–24:45

## Case Studies and Examples

> A simple neural network demonstrates pattern encoding through shadow height recognition, with a 3-layer structure and 1000 iterations for training.

### Network Architecture

**Network Components**

- Input: Shadow height (10 neurons)
- Hidden layer: 3 neurons
- Output: Match input values (10 neurons)
- Training: 1000 iterations to reduce error

Lecture reference: 17:18–24:45

## Interpretability and Challenges in Neural Networks

> Neural networks, particularly deep learning models, face significant challenges in interpretability due to the abstract and non-intuitive patterns encoded in their hidden layers. This lack of transparency complicates understanding how and why certain patterns are recognized, posing challenges for trust, debugging, and deployment in critical applications.

### Challenges in Neural Network Interpretability

**Key Interpretability Challenges**

- Hidden layer neurons may encode abstract or non-intuitive patterns.
- Lack of interpretability in neural network encodings.
- Difficulty in understanding why networks recognize certain patterns.

Lecture reference: 17:18–24:45

## Training Processes and Activation Functions

> The training process involves layer-by-layer adjustment of weights and thresholds using gradient ascent, with the sigmoid activation function transforming inputs into probabilities. The sigmoid function's parameters (w and T) control the curve's steepness and shift, respectively. Positive and negative examples influence the curve's position, with more positive examples shifting it right and more negative examples shifting it left. Output neurons ultimately represent class probabilities.

### Training Process

**Layer-by-Layer Training**

- Train input layer first
- Use trained input layer to train next layer
- Continue until the final layer
- Adjust final layer with class samples

### Sigmoid Activation Function

**Sigmoid Function**

```latex
z = \frac{1}{1 + e^{-(wx + T)}}
```

The sigmoid function transforms inputs into probabilities, with parameters adjusted to maximize data likelihood.

**Function Parameters**

- T shifts the sigmoid curve
- w affects the steepness of the curve
- Positive examples increase probability on the curve
- Negative examples decrease probability
- Gradient ascent optimizes parameters
- More positive examples shift the curve right
- More negative examples shift the curve left
- Output neurons represent class probabilities

Lecture reference: 24:45–33:47

## Activation Functions and Regularization

> Activation functions like softmax convert logits into probabilities, ensuring they sum to 1. Regularization techniques, such as dropout, randomly deactivate neurons during training to improve model generalization and prevent overfitting.

### How Softmax Works

**Steps in the Softmax Function**

- Each output is exponentiated to scale relative values.
- The sum of these exponentiated values forms the denominator.
- Each output is divided by this sum to produce probabilities.
- The resulting probabilities sum to 1, ensuring valid probability distribution.

### Regularization Through Dropout

**Dropout Mechanism**

- Randomly deactivates neurons during training.
- Reduces reliance on specific neurons.
- Improves generalization by preventing co-adaptation.
- Can be implemented during the forward pass in training.

Lecture reference: 33:47–42:10

## Convolutional Networks and Terminology

> Convolutional networks are effective for training deep networks, particularly with convolutional layers. The distinction between deep and wide networks is based on the number of neurons rather than layers. In the experiment, a five-layer network demonstrated a significant reduction in error rate over many iterations. Wide networks emphasize numerous neurons per layer, while deep networks focus on multiple layers without necessarily increasing the number of layers.

### Key Concepts

**Network Types and Experiment Results**

- Used in the experiment with a five-layer network.
- Showed sharp reduction in error rate after many iterations.
- Wide nets have many neurons per layer.
- Deep nets have multiple layers but not necessarily many layers.

Lecture reference: 33:47–42:10

## Training Dynamics

> Training neural networks can encounter local maxima where optimization stalls. Increasing network width converts these local maxima into saddle points, enabling the optimization process to continue and escape plateaus. This transformation is crucial for successful model training, as evidenced by examples where networks with two neurons per column quickly find solutions and wider networks avoid stagnation.

### Local Maxima and Optimization

**Key Concepts**

- Local maxima can trap networks during training, impeding progress.
- Saddle points are easier to escape compared to local maxima, facilitating continued learning.

### Role of Network Width

**Network Architecture Impact**

- Increasing network width helps transform local maxima into saddle points, aiding in optimization escape.
- Example: Networks with two neurons per column find solutions quickly, demonstrating the effectiveness of wider architectures.

Lecture reference: 42:10–49:00

## Visual Perception and Limitations

> Neural networks process visual data through pattern and texture recognition rather than true comprehension, making them vulnerable to adversarial attacks and misclassification based on superficial features.

### Vulnerabilities in Neural Networks

**Key Limitations**

- Adversarial examples demonstrate susceptibility to minor changes in input.
- Networks misclassify images based on textures rather than conceptual understanding.

### Examples of Limitations

**Illustrative Cases**

- School bus misclassification with minimal pixel changes highlights reliance on specific features.
- Image mutilation tests reveal dependence on particular textures or patterns.

Lecture reference: 42:10–49:00

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 12B: Deep Neural Nets. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=VrMHA3yX_QI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-12b-deep-neural-nets/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
