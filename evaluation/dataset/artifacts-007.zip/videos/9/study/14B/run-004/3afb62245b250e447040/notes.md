# Study notes



## Computation and Efficiency

> The transition from small neural networks with minimal parameters to larger ones with millions of parameters highlights the importance of computational efficiency. Redundancy in backpropagation calculations reduces the need for repetitive computations, emphasizing the exponential growth of computational paths and the principle of reusing shared calculations. The use of partial derivatives and the chain rule in weight updates underscores the efficiency gains in training larger models.

### Key Concepts

**Bullets**

- Emphasis on the exponential growth of paths through the network.
- Efficiency in computation due to shared calculations.
- Use of partial derivatives and chain rule in calculating weight changes.
- Principle: 'What's computed is computed and need not be recomputed.'

Lecture reference: 0:00–8:33

## Biological Inspiration

> Neural networks draw inspiration from biological neurons, particularly in their operation through dot product computations and proportional response mechanisms. These biological principles underpin the design of artificial neural networks, aiming to replicate the efficiency and adaptability observed in biological systems.

### Biological Basis

**Key Neural Operations**

- The dot product operation in artificial neurons mirrors the summation of inputs weighted by synaptic strengths in biological neurons.
- Neural responses in biological systems exhibit proportionality, where output activity increases with input intensity, rather than being all-or-none as in classical models.

### Neural Network Mimicry

**Biological-Like Responses**

- Artificial neural networks approximate biological response curves through activation functions, capturing graded rather than binary responses.
- Proportionality in neural activity allows for nuanced information processing, similar to how biological neurons adjust their firing rates based on input intensity.

Lecture reference: 0:00–8:33

## Evaluation Metrics

> The evaluation metrics from the 2012 neural network system reveal error rates of 15% when considering the top five choices and 37% when considering only the top choice. These metrics highlight the trade-offs between accuracy and confidence in predictions.

### Error Rates

**Error Rate Analysis**

- Error rate: 15% when considering the top five choices.
- Error rate: 37% when considering only the top choice.

Lecture reference: 0:00–8:33

## Convolutional Neural Networks (CNNs)

> CNNs process images by sliding kernels to create feature maps, then applying max pooling for dimensionality reduction. Modern architectures use numerous kernels and larger datasets, leading to improved performance.

### Convolution Process

**Kernel Sliding and Feature Extraction**

Convolution involves sliding kernels over an image to create feature maps. Each kernel detects specific features, and the output is generated for each position the kernel moves to. This process is akin to cross-correlation without kernel memory, differing from traditional mathematical convolution.

### Dimensionality Reduction and Pooling

**Max Pooling**

After convolution, max pooling reduces the spatial size of the feature maps by taking the maximum value in local neighborhoods, aiding in data compression and efficiency.

### Feature Map Creation

**Multiple Kernels**

Using many kernels (e.g., 100) creates numerous feature maps, allowing the network to capture a wide range of features. Each kernel acts as a feature detector, contributing to a richer feature set.

### Modern CNN Architecture

**Advancements in Performance**

Modern CNNs have more parameters and handle larger datasets, leading to better performance. While more parameters can risk overfitting, larger datasets help mitigate this, allowing the model to generalize better.

Lecture reference: 8:33–17:18

## Unsupervised Learning

> Unsupervised learning involves training neural networks to reproduce their input by passing through a narrower hidden layer, enabling generalization. The network learns patterns without explicit labels, using input consistency to form generalizations. This approach compresses input data through a smaller hidden layer, encoding generalized features and processing data without predefined categories.

### Key Concepts

**Characteristics of Unsupervised Learning**

- Involves comparing output layer values with desired input values.
- Forced to compress input through a smaller hidden layer.
- Example with animal shadow heights demonstrates the concept.
- Network processes input data without predefined categories.
- Hidden layer encodes generalized features from input.

Lecture reference: 8:33–17:18, 17:18–24:45

## Applications and Examples

> A deep network with five layers demonstrates input-driven generalization through shadow height recognition, showing resilience to neuron removal while improving performance with training.

### Key Features

**Network Inputs and Outputs**

- Input: Shadow heights of cheetah, zebra, giraffe.
- Output: Attempts to reproduce input values after training.
- Task: Classify animals based on shadow height

**Performance and Training**

- Initially poor performance
- Improves after many iterations
- Removing one neuron per layer still allows effective training

Lecture reference: 17:18–24:45, 33:47–42:10

## Inner workings of Neural Networks

> Neural networks' hidden layers encode abstract features that are not directly tied to input categories. These layers' behavior is difficult to interpret, as some neurons develop specialized activation patterns while others remain random. The decisions made by networks often lack transparency, and while recent research aims to uncover neuron responses, much about their functioning remains mysterious.

### Key Insights

**Behavior of Hidden Layers**

- Initial activation patterns are random.
- Training leads to specialized neuron activation in some cases.
- Network decisions are often inscrutable.
- Recent research seeks to understand neuron responses, but much remains unknown.

Lecture reference: 17:18–24:45

## Training and Output Mechanisms

> Neural networks are trained layer by layer, starting from the input layer and moving to subsequent layers. The final layer uses a sigmoid function to determine class probabilities, adjusting weights and thresholds based on positive and negative examples to maximize data probability. Multiple output neurons handle different classes, with each neuron representing a class probability.

### Training Process

- Start training from the input layer.
- Each layer uses the output of the previous layer.
- Final layer adjusts parameters using class samples.

### Sigmoid Function

```latex
z = \frac{1}{1 + e^{-(w \cdot x + T)}}
```

The sigmoid function transforms inputs into probabilities between 0 and 1.

### Parameters and Their Influence

- Weights (w) adjust steepness.
- Threshold (T) shifts the sigmoid curve.
- Positive examples increase probability in desired regions.
- Negative examples decrease probability in non-desired regions.
- Gradient ascent adjusts weights and thresholds to maximize probability.

### Multiple Output Neurons

- Multiple output neurons handle different classes.
- Each neuron's value represents the probability of its class.
- Highest value neuron determines classification.

### Examples and Training

- Sigmoid curve shifts right with increasing T.
- Sigmoid becomes steeper with larger w.
- Positive examples: sigmoid outputs higher probabilities.
- Negative examples: sigmoid outputs lower probabilities.

Lecture reference: 24:45–33:47

## Regularization Techniques: Dropout

> Dropout is a regularization technique that randomly deactivates neurons during training to prevent co-adaptation and improve generalization. By introducing randomness, it forces the model to learn more robust features, enhancing generalization and reducing overfitting.

### How Dropout Works

**Key Mechanisms**

- Randomly deactivates neurons during training
- Prevents co-adaptation of neurons
- Helps escape local optima
- Improves model generalization

### Implementation Considerations

**Hyperparameters**

Dropout typically uses a probability (e.g., 0.5) where each neuron has a 50% chance of being deactivated during training. This introduces stochasticity, forcing the network to learn more versatile features.

**Trade-offs**

While dropout improves generalization, it may slow training due to inactive neurons. Balancing regularization strength with computational efficiency is crucial.

### Practical Applications

**Combination with Other Techniques**

Dropout is often used with other regularization methods like weight decay. It is implemented in libraries such as TensorFlow or PyTorch, typically as a layer added after dense layers.

Lecture reference: 33:47–42:10

## Network Architecture: Wide vs. Deep Networks

> Wide networks, characterized by a larger number of neurons per layer, are more commonly used due to their balance between complexity and practicality. They offer a good middle ground by capturing complex patterns without the added complexity of multiple layers, making them efficient and effective for many applications.

### Definition of Wide and Deep Networks

**Characteristics**

- Wide networks have many neurons per layer, allowing them to capture more features at each step.
- Deep networks have many layers, enabling hierarchical feature extraction through multiple processing stages.

### Why Wide Networks Are More Common

**Advantages**

- Wide networks balance complexity and practicality, making them easier to train and manage.
- They offer computational efficiency, reducing training time and resource requirements.
- Wider networks can capture complex patterns effectively without the risk of vanishing gradients common in deep networks.

**Practical Implications**

In practical applications, such as image classification, wide networks with large neuron counts in convolutional layers can suffice. They are easier to implement and debug, avoiding the complexity of multiple layers. However, the choice between wide and deep networks often depends on the specific problem and dataset size, with deep networks excelling in hierarchical feature learning when computational resources permit.

Lecture reference: 33:47–42:10

## Training Dynamics

> Widening neural networks transforms local maxima into saddle points, aiding escape from training plateaus and improving optimization dynamics.

### Key Concepts

**Critical Points in Training**

- Local maxima can trap the training process, preventing further improvement.
- Wider networks facilitate smoother traversal of the loss landscape by converting local maxima into saddle points.

### Example: Two-Neuron Experiment

**Initial Success vs. Local Maximum**

- Initial training succeeds but retraining leads to local maximum issues.
- Wider networks demonstrate smoother optimization paths.

Lecture reference: 42:10–49:00

## Limitations and Vulnerabilities

> Neural networks exhibit several limitations and vulnerabilities, including susceptibility to adversarial attacks, overinterpretation by users, reliance on specific frequency bands, and challenges in conveying true comprehension. These factors highlight the need for cautious interpretation and robust testing.

### Key Vulnerabilities

**Vulnerabilities**

- Vulnerability to small adversarial changes in input.
- Overinterpretation by users leads to misconceptions about true comprehension.
- Frequency band manipulation can drastically alter recognition without visible changes.
- Humans often misinterpret network outputs due to their reliance on different visual cues.

### Examples and Implications

**Examples**

- School bus misclassification with minor pixel changes.
- Audience struggles to identify altered images correctly.
- Railroad car misidentified after frequency band alteration.
- Guitar recognition remains robust despite damage.

Lecture reference: 42:10–49:00

## Softmax Function

> The softmax function is crucial in multi-class classification tasks as it converts logits into a probability distribution, ensuring the probabilities sum to 1. This makes it suitable for predicting class probabilities in neural networks.

### Definition and Purpose

**Definition**

The softmax function transforms logits into probabilities by normalizing them. It is defined as: for logits z_i, the probability is exp(z_i) divided by the sum of exp(z_j) for all j.

### Comparison with Sigmoid

**Comparison**

- Sigmoid is for binary classification, outputting probabilities between 0 and 1.
- Softmax generalizes Sigmoid for multi-class classification, ensuring probabilities sum to 1.

### Example Calculation

**Example**

Given logits [2.0, 1.0, 0.5], the Softmax function calculates probabilities as follows: exponentiate each logit, sum these exponentials, then divide each exponential by the sum. This results in probabilities [0.629, 0.231, 0.140].

Lecture reference: 33:47–42:10

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 12B: Deep Neural Nets. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=VrMHA3yX_QI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-12b-deep-neural-nets/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
