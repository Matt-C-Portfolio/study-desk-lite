# Study notes



## Efficiency in Neural Network Computation

> Backpropagation's efficiency stems from reusing partial derivatives across layers, transforming the computation from exponential to linear complexity.

### Overview of Backpropagation Efficiency

Backpropagation revolutionized neural network training by efficiently computing gradients using the chain rule. Instead of recalculating derivatives from scratch for each layer, it reuses intermediate results, drastically reducing computational overhead. This method ensures that the time complexity scales linearly with the network's depth rather than exponentially, making training deep networks feasible.

### Process of Backpropagation

1. Forward pass computes activations and stores intermediate values.
2. Loss is calculated at the output layer.
3. Gradient of loss with respect to output layer weights is computed.
4. Using stored intermediate values, gradients propagate backward through each layer.
5. Each layer's gradient is computed using the previous layer's gradient, reusing computations.
6. Weights are updated using computed gradients.

### Efficiency Comparison

- Without backpropagation: Gradient computation for each layer would require recalculating from the input, leading to O(2^n) complexity where n is the number of layers.
- With backpropagation: Reuses intermediate computations, achieving O(n) complexity, making deep networks tractable.

Lecture reference: 0:00–8:33

## Biological Inspiration

> Neural networks draw inspiration from biological systems, particularly in their use of the dot product operation and activation functions to mimic neural processing.

### Biological Motivation

**Key Biological Insights**

- Neural networks model biological neurons and their connections.
- The dot product operation reflects how neurons process inputs weighted by connection strengths.

### Dot Product in Neural Processing

**Neural Computation**

The interaction between weights and inputs in neural networks mirrors biological processes, where each connection contributes to the overall response of the neuron. This is achieved through the dot product operation, which aggregates these contributions efficiently.

### Activation Functions

**Adding Non-Linearity**

- Non-linear activation functions, such as the sigmoid function, introduce depth and biological plausibility to neural networks.
- These functions approximate the behavior of biological neurons by introducing non-linear transformations to the input signal.

Lecture reference: 0:00–8:33

## Performance Metrics of Early Deep Learning

> Early deep learning models demonstrated significant accuracy levels, achieving 15% error rates for top-five predictions and 37% for top predictions. Their performance was particularly notable given the inherent ambiguity in some datasets, showcasing their effectiveness despite these challenges.

### Key Performance Indicators

**Performance Metrics**

- Error rates were 15% for top five predictions and 37% for top prediction.
- Performance was impressive given the ambiguity in some data.

Lecture reference: 0:00–8:33

## Convolutional Neural Networks

> Convolutional Neural Networks (CNNs) employ kernel operations and pooling techniques to process images. Unlike traditional convolution, CNNs lack signal memory and instead use feature maps to capture spatial patterns. Modern CNNs leverage numerous kernels and large computational resources to achieve superior performance on complex tasks.

### Kernel Operation

**Kernel Functionality**

- Involves a kernel (e.g., 10x10) sliding over the image to generate outputs.
- Each kernel produces a feature map associated with specific image locations.
- Feature maps highlight specific visual patterns or features in the input image.

### Feature Maps and Max Pooling

**Pooling Techniques**

- Max pooling involves taking the maximum value in a local neighborhood.
- Pooling operations slide over the image to produce a compressed representation.
- Downsampling reduces dimensionality while maintaining key features.

### Modern Advancements

**Network Evolution**

- Each kernel generates a feature map.
- Stacking multiple kernels results in a deeper, more detailed representation.
- Older networks had limited parameters and smaller datasets.
- Modern networks feature millions of parameters, thousands of classes, and large datasets, leading to superior performance.

Lecture reference: 8:33–17:18

## Unsupervised Learning Concepts

> In unsupervised learning, a neural network's output layer aims to reconstruct its input, forcing the network to learn general features through a bottleneck hidden layer. This approach encourages dimensionality reduction and feature extraction by compressing input data while maintaining meaningful representations.

### Key Characteristics

**Core Concepts**

- Desired output values are set to input values, creating an identity mapping task.
- The network learns to map inputs to themselves, facilitating feature learning through the bottleneck layer.
- Network structure follows a simple flow: Inputs -> hidden layer -> outputs, with the hidden layer compressing the input data.
- The compression process in the hidden layer enables dimensionality reduction, encouraging the network to generalize better.
- Unsupervised learning through reconstruction promotes feature extraction by identifying essential patterns in the data.

Lecture reference: 8:33–17:18, 17:18–24:45

## Network Architecture and Training

> A neural network with a simple architecture can learn to recognize patterns in input data through training. The network's hidden layer shows signs of encoding generalized features, though the exact interpretation remains unclear.

### Network Structure and Inputs

**Key Components**

- Inputs: Shadow heights of cheetah, zebra, giraffe
- Network structure: 10 input neurons -> 3 hidden neurons -> output layer

### Training and Learning

**Training Objective**

The training objective is for the network's output to match the input values, enabling it to recognize patterns effectively.

**Observations**

- Hidden layer neurons exhibit signs of encoding generalized features.
- Interpretation of the hidden layer's activity remains unclear.

Lecture reference: 17:18–24:45

## Output Layer Functions

> The output layer in neural networks uses sigmoid functions to convert logits into probabilities, with each neuron corresponding to a class. These probabilities are collectively considered for classification, ensuring they sum to 1 through normalization or additional functions like softmax.

### Sigmoid Function

**Equation and Parameters**

- Equation: z = 1 / (1 + e^(-w*x - T))
- w: Weight
- x: Input
- T: Threshold (bias)

**Function Behavior**

- Sigmoid function shifts with changes in T (threshold) and w (weight)
- T affects the position of the sigmoid curve
- w affects the steepness of the sigmoid curve

### Classification and Training

**Data Influence**

- Positive examples correspond to high probabilities on the sigmoid curve
- Negative examples correspond to low probabilities
- Gradient ascent adjusts w and T to fit the curve to the data

### Multi-Class Classification

**Multi-Class Handling**

- Multiple output neurons for multiple classes
- Each neuron's output represents the probability of its class
- Collective consideration of all probabilities for classification
- Ensures probabilities sum to 1.

Lecture reference: 24:45–33:47, 33:47–42:10

## Regularization Techniques

> Regularization techniques, such as dropout, help prevent overfitting by randomly deactivating neurons during training. This process encourages the network to learn more robust features and generalizes better to unseen data. Regularization also promotes the development of multiple, diverse representations of the input data, reducing reliance on any single neuron or feature.

### Key Benefits

**Primary Advantages**

- Improves generalization by preventing over-reliance on specific neurons.
- Encourages the network to learn multiple representations of the data, enhancing robustness.

Lecture reference: 33:47–42:10

## Network Architecture Considerations

> Deep neural networks, though not necessarily very deep, often benefit from width rather than depth. Training requires significant iterations, but architectural choices like redundancy and layer width influence optimization success. Wider networks help escape local optima by converting them into saddle points, improving overall model performance.

### Key Considerations

**Training Dynamics and Architecture**

- Training deep networks requires many iterations.
- Redundancy allows for network robustness even with neuron removal.
- Reducing neurons per layer (e.g., two neurons) still allows solution finding.
- Local maxima can trap training, but wider networks convert them into saddle points, enabling better optimization.

Lecture reference: 33:47–42:10, 42:10–49:00

## Limitations and Feature Importance

> Neural networks exhibit vulnerabilities due to their reliance on specific patterns and features. Adversarial examples demonstrate their susceptibility to small changes, revealing a lack of holistic understanding. Networks depend on local features and frequency bands, which can be manipulated to mislead classifications. These limitations highlight the need for more robust models that account for diverse and invariant features.

### Key Limitations

**Network Vulnerabilities**

- Small pixel changes can mislead network classifications (e.g., school bus to non-school bus).
- Networks identify objects based on local features, not holistic perception.
- Example experiments show networks struggle with certain objects (e.g., lamp, wolf) when features are altered.
- Removing certain frequency bands can disrupt identification, revealing feature reliance.
- Some objects are more resilient to mutilation (e.g., guitar) while others are not (e.g., lamp).

Lecture reference: 42:10–49:00

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 12B: Deep Neural Nets. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=VrMHA3yX_QI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-12b-deep-neural-nets/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
