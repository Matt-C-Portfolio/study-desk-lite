# Study notes



## Transition from Small to Large Neural Networks

> Understanding the transition from small to large neural networks highlights the efficiency and structure implications of scaling parameters.

### Jump from Small to Large Neural Networks

**Key Points**

- Discussed the jump from small to large neural networks.
- Emphasized the transition and its implications.

### Computational Structure

**Efficiency in Computation**

- Partial derivatives and chain rule usage.
- Reuse of computations to reduce redundancy.
- Weights multiplied by inputs sum to a value.
- Passed through a non-linear function like sigmoid.

### Neuron Structure

**Neuron Structure**

> Neurons consist of weights, inputs, and a non-linear activation function like sigmoid.

### Performance Metrics

**Performance Metrics**

```latex
95	ext% accuracy when considering top five choices.
```

2012 system's performance metrics.

**Performance Metrics**

```latex
37	ext% accuracy when considering the exact match.
```

2012 system's performance metrics.

Lecture reference: 0:00–8:33

## Convolutional Neural Networks (CNNs)

> CNNs are efficient and effective for image recognition due to their convolutional and pooling operations, which reduce dimensions and detect features at various scales.

### Convolution and Pooling

**How CNNs Work**

- Convolution involves a kernel sliding over an image to perform operations.
- Pooling reduces spatial dimensions by taking maximum values in local neighborhoods.

**Why CNNs Are Efficient**

1. CNNs share weights, reducing parameters and computational complexity.

### Efficiency and Effectiveness

**Efficiency**

CNNs are more efficient than traditional networks because they process data in parallel and share weights, making them ideal for image data where pixels are not independent.

**Effectiveness**

CNNs excel in image recognition tasks due to their ability to detect features like edges and shapes at different scales, improving translation invariance and robustness.

Lecture reference: 8:33–17:18

## Neural Network Structure

> Neural networks can be structured with input, hidden, and output layers to generalize from input data to produce desired outputs.

### Input Layer

**Input Layer**

```en
Receives raw data (e.g., shadow heights).
```

The input layer receives raw data, such as shadow heights, which are processed by the hidden layer to produce an output that reproduces the input values. In this case, the network is trained to recognize cheetahs, zebras, and giraffes based on their shadow heights, but the hidden layer does not clearly encode specific animal classifications, making the decision-making process difficult to interpret.

### Hidden Layer

**Hidden Layer**

```en
Processes input data to extract features, but in this case, the hidden layer does not clearly encode specific animal classifications.
```

The hidden layer's neurons do not clearly encode specific animal classifications, indicating that the network's decision-making process is not well understood. This suggests that the network may not be effectively learning the necessary features to perform the task accurately.

### Output Layer

**Output Layer**

```en
Produces the desired output that reproduces the input values.
```

The output layer reproduces the input values, but in this example, it is unclear how the network maps shadow heights to specific animal classifications due to the lack of clear encoding in the hidden layer.

Lecture reference: 17:18–24:45

## Boltzmann Machines Training Overview

> Boltzmann machines are trained layer-wise, starting from the input layer to the final layer, using sigmoid functions for class probability prediction and gradient ascent for optimization.

### Layer-wise Training

**Layer-wise Training**

> Boltzmann machines are trained sequentially, starting from the input layer and moving towards the final layer. Each layer is trained based on the previous one, allowing the model to build hierarchical representations of the data.

Lecture reference: 24:45–33:47

## Lecture

> The lecture discusses the normalization of probabilities using the sigmoid and softmax functions, their application in feature learning through autoencoding, and the regularization technique of dropout to prevent overfitting.

### Normalization of Probabilities

**The sigmoid function is used to convert outputs into probabilities.**

- The sigmoid function is used to convert outputs into probabilities.

**Normalization ensures that probabilities sum to one.**

- Normalization ensures that probabilities sum to one.

**Dividing by the sum of all outputs is crucial for accurate probability calculation.**

- Dividing by the sum of all outputs is crucial for accurate probability calculation.

### Regularization Techniques

**Dropout is a regularization technique to prevent overfitting.**

- Dropout is a regularization technique to prevent overfitting.

**Weight decay is another regularization technique to prevent overfitting.**

- Weight decay is another regularization technique to prevent overfitting.

**Dropout randomly deactivates neurons during training to prevent overfitting.**

- Dropout randomly deactivates neurons during training to prevent overfitting.

**Weight decay adds a penalty term to the loss function to prevent overfitting.**

- Weight decay adds a penalty term to the loss function to prevent overfitting.

Lecture reference: 33:47–42:10

## Deep Networks and Robustness

> Deep neural networks maintain performance even when simplified, demonstrating robustness.

### Robustness of Deep Networks

**Classification capability**

- A five-layer deep network classifies animals based on shadow height into cheetah, zebra, or giraffe.

**Shadow height as a feature**

- Shadow height determines the output color (green for positive, red for negative).

**Neural network simplification**

- Reducing the number of neurons per layer does not significantly affect performance.

**Regularization technique**

- Dropout helps maintain performance even with fewer neurons.

Lecture reference: 33:47–42:10

## Adversarial Examples and Vulnerabilities

> Neural networks are highly sensitive to subtle image alterations, known as adversarial examples, which can lead to incorrect classifications. Increasing network width transforms local maxima into saddle points, helping networks avoid suboptimal solutions.

### Explanation

**Adversarial Examples**

- Neural networks are susceptible to slight image changes that cause misclassification, known as adversarial examples.

Lecture reference: 42:10–49:00

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 12B: Deep Neural Nets. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=VrMHA3yX_QI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-12b-deep-neural-nets/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
