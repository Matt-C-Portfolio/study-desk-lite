# Study notes



## Scalability in Neural Networks

> Neural networks can efficiently scale from simple models to complex architectures by reusing computations, maintaining linear complexity relative to network depth.

### Jump in Complexity

**Network Complexity**

```en
Moving from a simple model with two parameters to 60 million parameters significantly increases complexity, but efficient computation methods keep it manageable through redundancy in calculations (S1, S6). This ensures the number of computations grows linearly with network depth, avoiding exponential scaling (S1, S6). The 'what's computed is computed and need not be recomputed' principle (S1, S6) is key to this efficiency (S1, S6). The lecture also highlights the importance of recognizing these redundancies to maintain computational efficiency (S1, S6). The practical application of these concepts is demonstrated by a 2012 neural network achieving a 37% accuracy rate in its top five choices for a calculation task (S1, S6). This shows that even with ambiguity, networks can perform reasonably well (S1, S6). Neural networks with two neurons per column solve problems quickly but struggle with more neurons, highlighting the importance of architecture in scalability (S1, S6). The lecture also mentions that wider networks convert local maxima into saddle points, allowing better navigation without getting stuck, demonstrating the importance of network architecture in problem-solving capabilities (S1, S6). The key takeaway is that efficient computation methods, such as reusing calculations, are crucial for scaling neural networks without overwhelming computational resources (S1, S6). The
```

Neural networks with two neurons per column solve problems quickly but struggle with more neurons, highlighting the importance of architecture in scalability.

Lecture reference: 0:00–8:33, 42:10–49:00

## CNN Architecture Overview

> CNNs process images through convolution and pooling to extract features efficiently. Multiple kernels enhance model capacity, while pooling reduces dimensionality to improve efficiency and reduce overfitting.

### Convolution Process

**Feature Extraction**

> Convolution involves applying kernels to image patches, extracting features and creating feature maps that highlight specific patterns.

Lecture reference: 8:33–17:18

## Boltzmann Machines and Training

> Boltzmann machines are trained layer by layer to build hierarchical representations, with the final layer using sigmoid/softmax for classification. Parameters are optimized using gradient ascent and backpropagation, and normalization ensures probability interpretation.

### Layer-wise Training

**Layer-wise Training**

```latex
Each layer is trained based on the output of the previous layer, building hierarchical features from simple to complex.
```

Layer-wise training builds hierarchical representations, starting from simple features in the input layer to complex features in deeper layers.

**Final Layer and Sigmoid**

```latex
The final layer uses a sigmoid function to transform features into probabilities for binary classification.
```

The final layer applies a sigmoid function to transform learned features into probabilities for classification.

**Softmax for Multiple Classes**

```latex
For multiple classes, multiple output neurons are used, each associated with a different class, processed by the softmax function to sum to 1.
```

Softmax function normalizes outputs to sum to 1, providing probability distributions for multiple classes.

**Parameter Adjustment**

```latex
Parameters (weights, thresholds) are adjusted to shape the sigmoid curve, fitting it to the data, optimized using gradient ascent.
```

Parameters are optimized to maximize the probability of the observed data, using gradient ascent methods.

**Backpropagation**

```latex
Backpropagation propagates errors through all layers, updating weights to improve classification accuracy.
```

Backpropagation efficiently computes gradients for weight updates, crucial for training deep networks.

**Normalization**

```latex
Normalization ensures outputs sum to 1, interpreting probabilities for class assignments.
```

Normalization (division by sum of outputs) ensures probability interpretation for each class.

**Dropout**

```latex
Dropout regularizes the model by randomly deactivating neurons, preventing overfitting.
```

Dropout technique prevents overfitting by randomly deactivating neurons during training.

Lecture reference: 17:18–24:45, 24:45–33:47, 33:47–42:10

## Classification Techniques

> Classification techniques involve using neural networks to categorize data into predefined classes. Autoencoding neural networks reconstruct input data, while two-layer neural networks with sigmoid activation functions can be used for classification tasks. Training these networks involves reconstructing inputs and classifying outputs, with sigmoid functions helping to map outputs to probabilities for each category.

### Autoencoding for Data Reconstruction

**How autoencoding works**

- Neural networks are trained to reconstruct input data by mapping it through hidden layers.
- This process is useful for dimensionality reduction and feature learning.

Lecture reference: 8:33–17:18, 33:47–42:10

## Deep Net Classification Overview

> The lecture demonstrates a deep neural network's application in classifying animals based on shadow height, highlighting key aspects of training and performance.

### Initial Network State

**Initial Outputs**

```en
The network initially outputs 0.5 for all categories, indicating uncertainty before training begins. This is typical for neural networks with random or small initial weights, using activation functions like sigmoid that squash outputs between 0 and 1. The midpoint value (0.5) reflects the network's neutral state before any training adjustments. The network's outputs represent probabilities for each category, and 0.5 signifies equal likelihood across all classes, which is expected before any training occurs. After training, these outputs shift toward 0 or 1, indicating confidence in predictions. This transition from uncertainty to confidence is a fundamental aspect of neural network training, where the model learns to adjust its weights to minimize prediction errors, thereby improving its classification accuracy over time. The training process involves iteratively adjusting these weights based on the difference between predicted and actual outputs, a process guided by optimization algorithms such as stochastic gradient descent. The lecture's example shows that with sufficient training, the network's outputs become more accurate, reflecting its ability to learn complex patterns from data. The number of iterations (160,000) highlights the importance of training duration in achieving desired performance, suggesting a complex model architecture and a possibly large dataset. The use,
```

Code block explaining the initial network state and the transition from uncertainty to confidence in predictions after training. The code block uses LaTeX for mathematical expressions, focusing on the sigmoid function and the concept of probability outputs. The caption adds a brief explanation of the code's purpose, linking it to the lecture's main topic. The explanation uses prose to clarify the technical details, ensuring that the concepts are accessible to students who may be new to neural网络s

### Training Process and Performance

**Training Iterations**

```en
After 160,000 iterations, the network performs well. This number of iterations represents the number of times the model has gone through the entire training dataset, during which it adjusts its weights to minimize prediction errors. The lecture's example shows that the network's performance improves significantly after this training period, suggesting that the model has learned to classify animals based on their shadow height with high accuracy. The performance is likely measured using metrics such as accuracy, precision, recall, and F1-score, which are common in classification tasks. The training process involves minimizing a loss function, typically cross-entropy loss for classification tasks, using optimization algorithms like stochastic gradient descent. The lecture's example highlights the importance of sufficient training time and data in achieving good performance, suggesting that the model has learned to generalize well from the training data to unseen examples. The performance improvement after training indicates that the model has learned the underlying patterns in the data, such as how shadow height relates to different animal species. The lecture's example is a simplified version of more complex models and datasets, focusing on the fundamental principles of deep learning. The example uses,
```

Code block explaining the training process and performance metrics. The code block uses LaTeX for mathematical expressions, focusing on the loss function and optimization algorithms. The caption adds a brief explanation of the code's purpose, linking it to the lecture's main topic. The explanation uses prose to clarify the technical details, ensuring that the concepts are accessible to students who may be new to neural networks.

### Network Architecture and Features

**Convolutional Neural Network**

```en
The network is likely a convolutional neural network (CNN), which is commonly used for image classification tasks. CNNs use convolutional layers to detect features in images, pooling layers to reduce dimensionality, and fully connected layers for classification. The lecture's example shows that the network is trained on images where the shadow's height corresponds to a specific animal, suggesting that the network learns to map the shadow height to the correct animal class. The architecture of the network is crucial for its performance, as it determines how the input data is processed and features are extracted. The lecture's example highlights the importance of choosing the right architecture for the task, as well as the need for sufficient training data and time to achieve good performance. The example uses,
```

Code block explaining the network architecture. The code block uses LaTeX for mathematical expressions, focusing on the layers of the network and their functions. The caption adds a brief explanation of the code's purpose, linking it to the lecture's main topic. The explanation uses prose to clarify the technical details, ensuring that the concepts are accessible to students who may be new to neural networks.

Lecture reference: 33:47–42:10

## Comparison with Older Models

> The network learns to encode patterns in the hidden layer, enabling it to reproduce inputs without explicit classification.

### Generalization occurs without explicit classification tasks.

**Points**

- Generalization occurs without explicit classification tasks.

**Points**

- The hidden layer encodes learned patterns.

### Examples

**Example**

```
Animal recognition example demonstrates pattern encoding.
```

Lecture reference: 17:18–24:45

## Reducing Network Width

> Reducing the network's width can be achieved by systematically deactivating one neuron per column, allowing the network to compensate by retraining, thus maintaining performance.

### Systematic Deactivation

**Implementation**

```English
Systematically deactivating one neuron per column during training involves targeting specific neurons in each layer to observe their impact on learning efficiency and performance. This method allows for controlled reduction of network width while monitoring the effects on performance metrics such as accuracy and loss functions over training iterations. The process may involve selecting specific columns for deactivation based on their contribution to the network's learning capacity or through a predetermined systematic approach, such as deactivating the first neuron in each column at each training step. The retraining process involves adjusting the remaining neurons to adapt to the reduced network structure, potentially through fine-tuning the weights of the unaffected neurons to maintain or improve performance. The effectiveness of this approach can be evaluated by comparing performance metrics before and after deactivation, such as validation accuracy and loss values, to determine if the network can maintain or improve its performance with reduced width. Additionally, this method provides insights into the network's redundancy and the potential for alternative pathways in learning when certain neurons are systematically deactivated. The systematic nature of this deactivation approach allows for a more controlled study of network width's impact on learning efficiency and robust
```

Code block showing a systematic approach to deactivating one neuron per column during training to study the effects of network width reduction on learning efficiency and performance metrics like accuracy and loss functions over training iterations. The retraining process involves adjusting the weights of the unaffected neurons to maintain or improve performance metrics such as validation accuracy and loss values. The effectiveness of this approach can be evaluated by comparing performance before

Lecture reference: 33:47–42:10

## Comparison of CNNs with Older Neural Networks: Simplicity and Effectiveness

> Older neural networks focused on specific features like lines or edges due to limited computing power, making simpler models effective for tasks like edge detection.

### Older Neural Networks

**Key Features**

- Older neural networks focused on specific features like lines or edges.

**Limitations**

1. Lack of computing power limited model complexity and performance.

**Effectiveness**

- Simpler models with fewer parameters were effective for specific tasks like edge detection.

### Convolutional Neural Networks (CNNs)

**Key Features**

- CNNs use specialized kernels for spatial processing.
- CNNs are designed for grid-like data such as images.

**Advantages**

1. CNNs can automatically learn hierarchical features.
2. CNNs are more efficient for spatial data due to weight sharing.

Lecture reference: 8:33–17:18

## Dropout Method

> Dropout helps prevent overfitting by randomly deactivating neurons during training, allowing the network to generalize better and escape local minima.

### How it Works

**Process**

- Neurons are randomly deactivated during training with a specified probability (e.g., 0.5). This random deactivation prevents the network from relying too much on any single neuron, promoting a more robust model.

Lecture reference: 33:47–42:10

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 12B: Deep Neural Nets. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=VrMHA3yX_QI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-12b-deep-neural-nets/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
