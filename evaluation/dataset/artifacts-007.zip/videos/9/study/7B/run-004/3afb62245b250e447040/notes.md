# Study notes



## Transition to Deep Learning

> Deep learning involves transitioning from small neural networks to those with millions of parameters, utilizing efficient computation methods like backpropagation and the chain rule to reduce complexity from exponential to linear with depth.

### Why More Parameters?

**Increased Complexity**

- Neural networks with more parameters allow modeling complex patterns.

**Efficient Computation**

- Backpropagation efficiently computes gradients by reusing previous calculations.

**Complexity Reduction**

- Reduces computational complexity from exponential to linear with depth.

**Dot product of inputs and weights followed by non-linearity like sigmoid.**

```math
$a = Wx + b$ followed by a non-linearity like sigmoid: $y = 	ext{sigmoid}(a)$
```

Code example showing a simple neural network layer computation.

**Historical performance in ambiguous tasks with 15% error rate.**

```text
Example of historical performance in ambiguous tasks with 15% error rate.
```

Example of historical performance in ambiguous tasks with 15% error rate.

**Efficiency and Computation**

1. 1. Use backpropagation to compute gradients efficiently by reusing previous calculations.
2. 2. This reduces computational redundancy, changing the complexity from exponential to linear with depth.

Lecture reference: 0:00–8:33

## Convolution and Pooling in Image Processing

> Understand the fundamental operations of convolution and pooling in image processing and their roles in feature extraction and dimensionality reduction.

### Introduction

**Key Insight**

> Convolution and pooling are essential operations in image processing that enable the extraction of local features and reduction of spatial dimensions, respectively. These operations are fundamental to modern image processing and computer vision systems, particularly in convolutional neural networks (CNNs). While they share similarities, these operations serve distinct purposes in the processing pipeline, each contributing to different aspects of feature extraction and model efficiency. Traditional networks often rely on these operations to handle high-resolution images effectively, but their limitations become apparent when dealing with large-scale data due to computational constraints and reduced parameter efficiency. This insight highlights the importance of optimizing these operations for better performance in modern systems. Source: S2:T1, S2:T2, S2:T3. This insight is particularly relevant when designing efficient models for high-resolution image processing tasks. Understanding these operations is crucial for developing models that can handle large-scale datasets effectively. Source: S2:T1, S2:T2, S2:T3. This insight underscores the significance of convolution and pooling in the context of modern image processing architectures, particularly in the design of efficient and scalable models. Source: S2:T1, S2:T2, S2:T3. This insight emphasizes the role of convolution and Pool:

### Convolution

**Process**

- The kernel slides over the image, computing outputs for each position.
- Each output is linked to a specific part of the image.
- Reduces the size of the feature map.
- Enhances robustness to translations.
- Fewer parameters compared to CNNs.
- Less capability to handle high-resolution images.

### Pooling

**Process**

- Takes the maximum value in local neighborhoods.
- Reduces the spatial dimensions of the feature map.
- Helps in making the representation more invariant to small translations.
- Reduces the number of parameters in the model.

Lecture reference: 8:33–17:18

## Autoencoding Basics

> Autoencoding is an unsupervised learning technique where a neural network reconstructs its input, forcing it to generalize from the data.

### Definition

**Autoencoder Structure**

```latex
An autoencoder consists of an encoder and decoder. The encoder compresses the input into a latent representation, and the decoder reconstructs it. The goal is to minimize reconstruction error, typically using mean squared error or cross-entropy loss. The network learns to capture essential features of the data, enabling generalization beyond the training set. This is exemplified by shadow height reconstruction, where the network learns to encode and decode shadow heights accurately, despite varying animal types. The hidden layer acts as the bottleneck, encoding the input efficiently. The encoder network maps inputs to hidden representations, while the decoder reconstructs the output from these representations. The loss function measures the difference between input and output, guiding weight adjustments to minimize reconstruction error. The hidden layer's efficiency in encoding is crucial for effective generalization. The encoder network transforms inputs into latent variables, which are then used to reconstruct the output. The decoder network reconstructs the output from the latent variables, aiming to match the input. The loss function ensures the reconstructed output closely matches the input, enabling the network to learn essential data features. The encoder network maps inputs to latent variables, capturing the data's essential structure. The decoder network reconstructs a
```

Formula for reconstruction error: L = ||x - 	ilde{x}||^2

Lecture reference: 17:18–24:45

## Introduction to Neural Networks

> Neural networks are structured in layers for incremental training, using sigmoid functions for classification, and employing techniques like gradient ascent for optimization.

### Layered Architecture

**Boltzmann Machines**

> Boltzmann machines are structured in layers for incremental training, starting from the input layer and moving to the final layer, which uses a sigmoid function influenced by weights and thresholds to maximize the probability of observed data. This architecture is inspired by the layered processing in biological neural networks, where information is processed in a hierarchical manner. The sigmoid function is crucial for binary classification, converting outputs into probabilities between 0 and 1, which are then normalized to ensure they sum to one. This normalization is essential for multi-class classification tasks, where each output neuron corresponds to a specific class probability. The use of weights and thresholds allows the model to adjust parameters to improve its fit to the data, a process optimized using techniques like gradient ascent. Gradient ascent is a method for optimizing parameters by moving in the direction of the gradient of the loss function, aiming to minimize the loss and maximize the model's accuracy. The lecture also highlights the importance of avoiding overfitting through techniques like dropout, where neurons are randomly dropped during training to prevent the model from relying too heavily on any single neuron. This regularization technique helps in creating more robust models that generalize better to unseen data. The lecture includes a classroom例an

Lecture reference: 24:45–33:47, 33:47–42:10, 42:10–49:00

## Advantages of CNNs

> Convolutional Neural Networks (CNNs) offer several key advantages, including efficient feature extraction and adaptability across various image recognition tasks.

### Efficient Feature Extraction

**Explanation**

> CNNs utilize convolutional layers to automatically extract hierarchical features from images, reducing manual feature engineering efforts and enhancing pattern recognition efficiency through shared weights and pooling operations. The convolutional layers detect edges, shapes, and more complex features as they slide across the input data, while pooling layers reduce dimensionality, preventing overfitting and speeding up processing. This hierarchical feature extraction ensures that CNNs can capture both local and global patterns in images effectively, making them highly efficient for image-related tasks. Additionally, the use of shared weights in convolutional kernels allows the network to learn features in a translation-invariant manner, improving generalization and reducing the number of parameters compared to fully connected networks. The pooling operations further enhance computational efficiency by decreasing the number of parameters and the spatial dimensions of the representations, making the network more efficient and scalable for large datasets. These mechanisms collectively enable CNNs to handle high-dimensional image data with fewer parameters than traditional models, improving performance and reducing training time. The automatic feature extraction process also makes CNNs adaptable to various tasks, as they can learn diverse representations without requiring extensive

Lecture reference: 8:33–17:18

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 12B: Deep Neural Nets. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=VrMHA3yX_QI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-12b-deep-neural-nets/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
