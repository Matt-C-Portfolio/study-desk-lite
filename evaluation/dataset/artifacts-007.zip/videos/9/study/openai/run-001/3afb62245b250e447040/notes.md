# Study notes



## Neuron computation

> A neuron computes a weighted sum by multiplying each input by its corresponding weight and adding the products, then passes the result through a nonlinear function such as a sigmoid. This computation is represented as a dot product and may apply to both neural-network models and biological neurons.

### Weighted sum and dot product

A neuron multiplies inputs by corresponding weights, sums the products, and passes the result through a nonlinear function such as a sigmoid. The weighted sum is a dot product between the weight vector and the input vector.

**Weighted sum**

```latex
\sum_i w_i x_i
```

Here, w_i is a weight and x_i is the corresponding input.

**Representations and interpretation**

- In the lecture's models, input variables are often binary, taking values 0 or 1.
- Neural activity may also be represented proportionally rather than as strictly all-or-none values, yielding a more conventional real-valued dot product.
- The dot product is presented as a potentially fundamental computation in both neural-network models and biological neurons.

Lecture reference: 0:00–8:33

## Backpropagation computation reuse

> Backpropagation avoids exponential recomputation by reusing derivative terms and intermediate quantities as it moves backward through the network. Although a performance derivative with respect to an earlier weight may receive contributions from multiple downstream paths, those paths share computations, making the overall computation linear in network depth.

### Shared computations in the chain rule

Derivatives of performance with respect to earlier weights can be expanded using the chain rule. A network’s output performance can influence an earlier weight only through a limited number of intermediate output variables, even though the number of paths through the network may grow exponentially.

**What is reused**

- The partial derivative of performance with respect to a weight includes contributions from multiple downstream paths.
- Expressions for different weights share initial derivative terms and intermediate quantities already computed for downstream weights.
- Moving backward from outputs toward inputs reuses previously computed results instead of recomputing them.

### Computational consequence

Because shared terms are reused while moving backward from the outputs toward the inputs, the resulting computation is linear in the depth of the neural network rather than exponential in the number of paths.

Lecture reference: 0:00–8:33

## Deep convolutional networks and scale

> Deep convolutional networks combine local image processing, pooling, and later neural-network layers for classification. Their strong but imperfect performance is associated with much greater computational scale: more classes, samples, and parameters. The lecture emphasizes that the precise reason for this performance is not fully understood.

### Classification performance

A deep neural-network system achieved strong but imperfect image-classification performance. Its top-five error rate was approximately 15%, meaning the correct answer was absent from its five highest-ranked choices about 15% of the time. When only the single highest-ranked choice counted, the error rate was approximately 37%. Some images are ambiguous even for humans.

> The system embodied the essential deep-network structure, even though its exact architecture was not identical to the schematic under discussion.

### Convolution and pooling

Convolution applies a local receptive field across an image, producing an output value associated with each spatial location. A neuron or kernel examines a local region, described here as a 10×10 square, and is shifted across the image. Each placement produces an output tied to a particular image location, and the resulting collection of outputs forms a mapping of the image. The lecturer notes that the term resembles convolution from Signals and Systems but does not involve signal-processing memory in this setting.

Pooling summarizes local neighborhoods of convolution outputs. The pooling window is shifted across the output to produce successive values; taking the maximum value specifically is called max pooling. This creates another spatial mapping.

1. Apply a kernel to local regions as it shifts across the image.
2. Collect the output associated with each spatial location into an image mapping.
3. Examine local neighborhoods in the convolution output.
4. Use the maximum value in each neighborhood for max pooling, producing another spatial mapping.

### A convolutional classification pipeline

A convolutional network can apply many kernels to an image, pool their outputs, and pass the combined representations into later neural-network layers for classification. A typical arrangement may repeat the convolutional process with roughly 100 kernels. The later layers can include fully connected final layers, and the final output can indicate how likely the image is to belong to a category such as a mite.

In the described pipeline, a 256×256 image is processed with a 10×10 kernel, local maximum pooling is applied, and the process is repeated for approximately 100 kernels. The pooled features are then passed to later layers to estimate whether the image depicts a mite.

### Scale in modern neural networks

- Earlier systems could use a small grid of pixels as inputs, followed by a few columns of neurons and an output neuron recognizing a category such as the digit 1.
- The modern comparison uses about 1,000 classes instead of 10 digits.
- The example increases the data to about 1,000 examples per class, or roughly one million samples.
- The example includes about 60 million parameters rather than a few hundred.

Images used in these systems may be compressed to approximately 256×256 pixels rather than being 1,000×1,000 or 4,000×4,000 pixels. The lecturer characterizes the resulting model as a function approximator with unexpectedly strong performance, while stating that the precise reason this performance emerges is not fully understood. The lecture emphasizes the effect of immense computation applied to this arrangement.

Lecture reference: 0:00–8:33, 8:33–17:18

## Autoencoding, reconstruction, and hidden representations

> An autoencoding network compresses an input through a substantially smaller hidden layer and expands it into an output that is compared with the original input. The bottleneck can capture useful regularities, but the resulting internal representation may not be directly interpretable.

### Architecture and reconstruction objective

An autocoding, or autoencoding, network contains an input layer, a substantially smaller hidden layer, and an output layer. The network learns to reconstruct its input after compressing it through the hidden-layer bottleneck. In the described setup, approximately 10 input-side neurons pass information through only a couple of hidden neurons before producing output units labeled z1 through zn.

**Reconstruction target**

```latex
d_i = x_i
```

Each desired output value d_i is set equal to the corresponding input value x_i.

**Features of the objective**

- The desired output is identical to the input.
- All input possibilities must pass through a narrower hidden-layer bottleneck before being reconstructed.
- Successful reconstruction requires the network to capture some generalization about the kinds of inputs it receives.
- This autoencoding idea appears in multiple forms across deep-neural-network research.

### Shadow-height demonstration

A small neural network demonstrates unsupervised reconstruction using shadow-height patterns rather than animal classification. The inputs represent shadow heights for cheetahs, zebras, and giraffes, with 10 input neurons representing one shadow-height level each. Information passes through three hidden-layer neurons and is then expanded into output values.

**Training and result**

- The target output is the original input pattern, not an animal label.
- Before training, the connection weights are random and the outputs are approximately 0.5 across the shadow patterns.
- After 1,000 training iterations, the output values closely match the desired input values for the test cases.
- The network receives only shadow-height data and learns regularities in those inputs; it is not trained to classify animals.

**Demonstration summary**

```text
Input patterns: shadow heights associated with cheetah, zebra, and giraffe
Architecture: 10 input neurons → 3 hidden neurons → output values
Training target: output = input
Result after 1,000 iterations: reconstructed outputs closely match the corresponding inputs
```

The demonstration compares reconstructed shadow-height patterns with their original inputs.

### Connection weights and hidden-neuron interpretation

The demonstration visualizes connection weights by color and intensity. Green connections represent positive weights, with greater green density indicating a more positive weight. Red connections represent negative weights, with greater red intensity indicating a more negative weight. Before substantial training, the mixture of red and green connections appears largely random.

It might be expected that hidden neurons would visibly specialize in concepts such as short, medium, or tall shadows. Examining the input values that maximally stimulate the hidden neurons may instead yield one interpretable pattern and other patterns that appear random or do not correspond to the expected concepts.

**Expected and observed interpretation**

```text
Expected interpretation: hidden neurons visibly represent short, medium, and tall shadows
Observed interpretation: one neuron resembles short, while other neurons do not visibly correspond to medium or tall
Conclusion: the learned generalization is encoded, rather than transparently represented in individual neuron activations
```

The example contrasts an anticipated feature-based interpretation with the less transparent learned representation.

### Interpretability and unresolved questions

The generalization therefore seems to be encoded in a form that is not directly apparent in the maximally stimulating inputs. This hidden encoding helps explain why neural networks can perform recognition tasks while remaining difficult to interpret. The internal representation does not directly reveal why the network recognizes a cheetah or other objects in related settings.

**Remaining uncertainty**

- It is unclear why recognition may succeed for some instances, such as a school bus, but fail for others.
- There has been substantial work aimed at understanding these representations, but significant mystery remains.
- The transcript ends while the reconstruction objective is being introduced, so the subsequent explanation is unresolved.
- The demonstrated technique is identified as the autocoding idea, which occurs in various forms.

Lecture reference: 8:33–17:18, 17:18–24:45

## Layerwise training and binary output optimization

> Training proceeds layer by layer: each trained input layer supplies representations for training the next layer, while class-based training is deferred to the final stage. The final sigmoid output represents the probability of a positive class, and optimization adjusts the weight and threshold to maximize the likelihood of the observed labeled data.

### Layerwise training

Each trained input layer can provide representations for training the next layer. The network first accumulates knowledge about the environment through this layer-by-layer process, and only at the final stage uses labeled samples to train class-specific outputs.

### Sigmoid output

The final output neuron combines a weighted input and a threshold, then passes the result through a sigmoid to produce an output value. The sigmoid output can be interpreted as the probability of a positive class.

**Sigmoid form**

```latex
z = \frac{1}{1 + e^{-(wx + T)}}
```

Here, w is the weight, x is the input, and T is the threshold.

**Parameter effects and probabilities**

- Changing the threshold shifts the sigmoid horizontally.
- Changing the weight changes the sigmoid's steepness.
- For a positive example, the sigmoid value represents the probability assigned to that example.
- For a negative example, the corresponding probability is one minus the sigmoid value.

### Likelihood optimization

The likelihood of the observed labeled data depends on the shape of the sigmoid, which is determined by its parameters. Training adjusts the weight and threshold so that the observed data has the highest possible probability.

**Optimization process**

1. Use partial derivatives or a related optimization procedure to determine how the parameters should change.
2. Apply gradient ascent to raise the probabilities of positive examples and lower the probabilities of negative examples.
3. Continue adjusting the sigmoid parameters to increase the likelihood of the observed data.

### Examples of curve adjustment

A demonstration began with an ordinary sigmoid, several positive examples, and a negative example. Gradient ascent changed the curve so that the probability of the positive examples increased and the probability of the negative example decreased.

**Influence of added examples**

- A positive example near an existing boundary can cause a substantial shift in the curve.
- An isolated point may behave like a noise point.
- Additional negative examples can adjust the curve in the opposite direction.
- Adding a positive example near the boundary produced a dramatic change in the curve, whereas adding a negative example in a less influential location produced little change.

Lecture reference: 24:45–33:47

## Multiclass probabilities and softmax output training

> For many classes, the output layer contains one neuron per class. Softmax normalizes class-associated outputs into probabilities across the entire output vector, allowing several categories to remain plausible. A trained hidden layer can be retained while a replacement output layer is trained separately.

### Multiclass output interpretation

With 1,000 classes, the network would have 1,000 output neurons. Each output neuron is associated with one class, and its value should be higher when the input belongs to that class. The desired interpretation assigns some probability to every class rather than simply declaring the class with the largest raw output the winner.

- An image may be identified primarily as one category while also receiving nonzero probabilities for a second, third, fourth, or fifth category.
- The resulting output can represent a primary classification along with additional plausible classifications.

### Softmax normalization

A sigmoid output for each class is not by itself a normalized probability distribution. Softmax combines the class outputs so that each class receives a probability. The normalization factor operates over the entire output vector.

**Probability for class 1**

```latex
P(\text{class 1})=\frac{\operatorname{sigmoid}(\text{class 1})}{\sum_i \operatorname{sigmoid}(\text{class }i)}
```

The numerator is the sigmoid output for class 1, and the denominator sums the sigmoid outputs for all classes.

### Training a replacement output layer

1. Retain the weights connecting the input to the hidden layer when the earlier output layer is detached.
2. Treat the retained first layer as trained while the replacement output layer begins untrained.
3. Freeze the input-side layer and train the replacement output layer using the sigmoid curve.
4. After training the outer layer, obtain outputs that closely match the desired outputs.

**Before and after training the outer layer**

- Before training: Test samples produce one-half for each category despite the trained middle layer.
- After training: The outputs closely match the desired outputs, and training the outer layer rapidly produces outputs that match the target labels.

This is presented as a combination of the autocoding idea and the softmax idea.

Lecture reference: 24:45–33:47, 33:47–42:10

## Network training variations, width, and optimization landscapes

> The lecture presents dropout and network width as factors that affect optimization. Randomly removing neurons during training may reduce frozen local-maximum behavior, while wider networks can turn local maxima into saddle points. A five-layer classifier illustrates long training plateaus, rapid later improvement, and the difference between narrowing a network after finding a solution and narrowing it before training.

### Dropout and network width

Dropout randomly removes neurons during each training iteration, so different subsets of the network are active on different iterations. A coin is effectively flipped for each neuron. A neuron selected for removal has no influence on the output during that iteration, and a different set can be removed on the next iteration. The lecture presents this as a way to reduce the tendency of a network to become stuck in a frozen local maximum.

- The lecturer suggests that systems with many neurons across their layers might more accurately be called wide nets.
- They are described as often being extremely wide but rarely more than about ten columns deep.
- Many deep networks are characterized as having many neurons across their layers but relatively few layers in depth.

### Backpropagation compared with more elaborate approaches

Despite the sophistication of probabilistic output layers and training approaches such as autocoding or Boltzmann machines, the lecture states that ordinary backpropagation with a convolutional network performs about as well as these alternatives. This is presented as an observation about the current state of the art, and the lecture questions how much the additional output-layer and training sophistication helps.

### Five-layer animal-classification example

A classroom deep network with five columns, each containing approximately nine or ten neurons, is trained to classify an animal as a cheetah, zebra, or giraffe from the height of its shadow. This produces many more parameters than the earlier example. In the visualization, green represents positive and red represents negative.

1. Before training, every test case produces 1/2 regardless of the animal.
2. Early in training, the outputs become entirely negative, represented as red. The lecturer interprets this as a reasonable response when the network does not yet know which animal is present: saying no for every possibility is safer than making an unsupported positive classification.
3. Ordinary backpropagation is used. After approximately 160,000 iterations, the network begins producing good results on test samples.
4. Repeated runs show a long period of little apparent change followed by a rapid decline in error. The error rate is described as falling off a cliff, with substantial progress occurring only after an extended initial plateau.

In one visualization, the network initially turns the right side entirely red. After about 160,000 iterations, the test samples are classified successfully. Later runs similarly show the error remaining high for a long time before dropping rapidly.

### Removing neurons after a solution

The lecture tests a dropout-like variation by permanently removing one neuron from each column of the network and retraining it. The removed neurons are reassigned to another purpose, leaving one fewer neuron per column.

1. The network is trained and a solution is demonstrated.
2. One neuron is killed in each column.
3. The reduced network is retrained.
4. The first retraining run reaches a solution quickly, and additional runs generally rise briefly before rapidly falling to a solution.
5. The observation suggests that the network can perform the task without one neuron in each column, retaining enough capacity and remaining close enough to a workable solution.

> The transcript ends while the lecturer is continuing to remove components and retrain, so the final outcome of that continuing experiment is unresolved.

### Width, local maxima, and saddle points

- A solution was found after reducing each of five layers to two neurons per column. This shows that the reduced network can have a valid solution when reduction follows an already demonstrated solution.
- Repeating the experiment by reducing the network to two neurons per column before training led to increasingly poor progress and a local maximum.
- The lecture attributes a breakthrough in neural-network learning partly to widening the network: local maxima can become saddle points.
- Saddle points allow the optimization process to continue moving through a large search space rather than remaining stuck at a local maximum.

The contrast suggests that network capacity and the timing of narrowing matter. A narrow network may contain a valid solution yet still be difficult to train when optimization starts there, whereas a wider network can provide an optimization route through the search space.

Lecture reference: 33:47–42:10, 42:10–49:00

## Differences between neural-network and human image recognition

> Neural networks can classify images with high confidence from local evidence and exclusion of alternative classes, even when people cannot perceive the relevant cues. Small pixel changes or frequency-band alterations can preserve or change a network’s classification in ways that expose a gap between neural-network categorization and human visual recognition.

### Local evidence and classification changes

Image classifiers may assign high-confidence labels based on local evidence and on rejecting alternative classes, even when people do not perceive the evidence used. The proposed interpretation is that a network collects enough positive local evidence to select one class and enough evidence to reject the other 999 classes.

**Examples of classification behavior**

- Online systems allow users to submit images, and many published studies construct images that fool neural networks.
- Changing a very small number of pixels can shift a network from high confidence that an image is a school bus to deciding that it is not a school bus.
- A school-bus image remained visually similar to people after a small number of pixel changes, yet the neural network’s confidence changed from identifying a school bus to rejecting that label.
- Some altered images may contain recognizable texture, such as baseball-like texture, but the network’s cues need not match human perception.

### Image captioning and human-like understanding

Image-captioning systems can label pictures without understanding activities, objects, or experiences in the human sense. They are described as engineering marvels that perform useful tasks but do not see in the same way humans do.

**Captioning examples and limitations**

- A captioning system produced descriptions that appeared to suggest understanding of playing, being young, moving, or a Frisbee, but the lecture states that the system only learned to label the image.
- Captioning systems also produce incorrect or incomplete descriptions, such as identifying a cat without lying or describing a little girl without correctly identifying that she is blowing bubbles.
- Some captioning outputs were visibly imperfect, including a cat-related description and a description of a little girl that omitted or misidentified bubble blowing.

### Frequency-band experiment

The laboratory experiment separates an image into slices, with each slice representing a particular frequency band. A rectangular region is removed from one band, and the remaining components are reassembled. The amount removed is increased as much as possible while preserving the neural network’s impression that the image belongs to its original class.

**Neural-network classifications and human perception**

- An altered image was classified by the network as a railroad car even though the mutilated result was difficult for people to recognize as one.
- An image classified by the network as a barbell was suggested by audience members to resemble a lamp, toilet, or cello.
- Other mutilated images were classified by the network as a grasshopper, two closely positioned wolves rather than a two-headed wolf, a rabbit, a Russian wolfhound, and an image associated with Venice, while audience guesses often differed.
- Human viewers often identify the resulting images differently from the neural network.

**The guitar example**

> A guitar image could not be heavily mutilated while retaining the network’s guitar classification. It retained enough recognizable structure for people to identify it as a guitar, suggesting that more of its visual content was needed for that classification.

The experiment illustrates a gap between neural-network categorization and human visual recognition: the retained classifier impression may be difficult for humans to recognize, even when the network preserves its original label.

Lecture reference: 42:10–49:00

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 12B: Deep Neural Nets. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=VrMHA3yX_QI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-12b-deep-neural-nets/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
