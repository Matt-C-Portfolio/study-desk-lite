# Study notes



## Backpropagation efficiency

> Backpropagation uses the chain rule to determine how network performance depends on earlier weights. Although the number of paths through a layered network can grow exponentially, shared partial-derivative subexpressions are computed once and reused, making the calculation linear in network depth rather than exponential in the number of paths.

### Shared intermediate variables and paths

In a layered network, an output can influence an earlier weight only through the finite set of intermediate output variables connecting the layers. The number of possible paths may nevertheless grow exponentially.

### Chain-rule computation

The derivative of performance with respect to a weight includes contributions from multiple paths. Applying the chain rule produces many partial derivatives, and derivatives for different weights contain substantial redundancy.

As derivatives are propagated backward from outputs toward inputs, previously computed downstream terms are reused. This reuse avoids recomputing shared partial-derivative subexpressions.

### Efficiency result

> Reusing computed derivatives makes the calculation linear in the depth of the neural network rather than exponential in the number of paths.

Lecture reference: 0:00–8:33

## Neuron computation

> A neuron computes a weighted sum of its inputs, represented as a dot product, and then passes that preactivation through an activation function such as a sigmoid.

### Weighted inputs and activation

The preactivation is formed by multiplying each input by its corresponding weight and summing the products. This weighted sum is then passed through an activation function such as a sigmoid.

**Weighted sum as a dot product**

```latex
\sum_i w_i x_i
```

Here, w_i denotes a weight and x_i denotes its corresponding input.

**Representations and significance**

- The weighted sum is the dot product of the weight vector and input vector.
- Input variables may be binary, taking values of 0 or 1, in the discussed models.
- Neural activity can also be represented with proportional, non-binary values.
- The dot product is presented as a fundamental operation that may also be relevant to how biological neurons process information.

Lecture reference: 0:00–8:33

## Deep image recognition and convolutional networks

> Convolutional neural networks repeatedly apply local kernels, pool neighborhood outputs, and pass the resulting features to later neural-network layers for classification. The lecture describes strong performance at large computational scale, while noting that the precise reason for the arrangement’s success is not fully understood.

### Recognition performance

A deep-network system discussed in the lecture achieved approximately a 15% error rate when correctness included the top five predictions. Under the stricter criterion that counted only the highest-ranked prediction, the error rate was approximately 37%.

- The top-five criterion counts a result as correct if the right answer appears among the system’s five highest-ranked choices.
- The performance was characterized as strong, especially because some image categories are ambiguous even for humans.
- The specific system was not identical to the schematic shown, although the schematic captured its essential structure.

### Convolution and local processing

Convolutional neural networks are described as assemblies of recurring components rather than one special system. The term “convolution” is borrowed from Signals and Systems, but the operation discussed does not involve memory as signals are processed.

1. A compressed image, such as a 256×256-pixel image, is used as input rather than a very large 1,000×1,000 or 4,000×4,000 image.
2. A neuron examines only a local square region, described as a 10×10 region, and the operation is shifted across the image.
3. Each placement produces an output associated with a particular location in the image.
4. The moving neuron or operation is called a kernel, and the resulting operation is called convolution.

For example, a 10×10 kernel can be shifted across a 256×256 image, producing a collection of location-specific outputs.

### Pooling and feature extraction

After convolution, local neighborhoods of outputs are examined and replaced by their maximum values, producing another mapping of the image. Pooling aggregates values in local neighborhoods; when the maximum value is selected, the operation is called max pooling.

1. A pooling window examines a local neighborhood of convolution outputs.
2. The largest value in that neighborhood is selected.
3. The window is shifted across the convolution outputs to produce successive pooled values.
4. The convolution-and-pooling process can be repeated with many kernels.
5. The resulting feature values can be fed into later neural-network layers, potentially including fully connected final layers.

A single kernel can be replicated many times; approximately 100 kernels is given as a typical number. The final output can indicate how likely it is that the image contains a particular class, such as a mite.

### Older and modern network arrangements

- Older systems might operate on a small grid of pixels, with pixel values supplied to neurons and a few subsequent neuron columns. An older classifier might identify whether an image resembles one of ten digits, such as the number 1.
- Modern systems use roughly 1,000 classes instead of 10 digits, about 1,000 examples per class instead of a few hundred samples, and approximately 60 million parameters instead of a few hundred.
- Modern systems differ mainly through much greater computational scale, more classes, more training examples, and many more parameters.

> The resulting network is characterized as a function approximator with unexpectedly strong performance. The lecture states that the precise reason this arrangement works so well is not fully understood, while emphasizing the impact of applying immense computation to it.

Lecture reference: 0:00–8:33, 8:33–17:18

## Autoencoding, learned representations, and layer-wise pretraining

> An autoencoder compresses inputs through a substantially smaller hidden layer and reconstructs them at the output. The bottleneck can capture useful generalizations without producing individually interpretable hidden neurons. In layer-wise pretraining, each trained layer supplies representations for training the next, while class-related supervised training is deferred until the final output layer.

### Autoencoding architecture and objective

An autoencoder consists of an input layer, a much smaller hidden layer, and an output layer. The network is trained so that its output matches its input, with all information passing through the narrow hidden-layer bottleneck. If the output units are z₁ through zₙ and the desired values are d₁ through dₙ, the distinctive setup is to make the desired output values equal to the input values themselves.

- The architecture consists of an input layer, a much smaller hidden layer, and an output layer.
- The example suggests an input layer with 10 neurons and a hidden layer with only a couple of neurons.
- The desired output values are identical to the input values, so the task is reconstruction rather than animal classification.
- The hidden layer acts as a narrow bottleneck that compresses the possible inputs before reconstruction.
- This autoencoding idea appears in various forms across deep-neural-network research, including Boltzmann machines and related approaches.

### Shadow-height reconstruction example

A simplified demonstration represents shadow height with 10 input neurons, compresses it through 3 hidden neurons, and produces output-layer values. The input patterns correspond to short, medium, and tall shadows associated with a cheetah, zebra, and giraffe. The trained network reproduces the corresponding input patterns at its output.

- Before training, the network has random weights and produces outputs near 0.5 for the different shadow heights.
- After 1,000 iterations, the output values are close to the desired values for the cheetah, zebra, and giraffe test cases.
- Green connections represent positive weights, with greater green density indicating greater positivity; red connections represent negative weights, with greater red intensity indicating greater negativity.

### What the bottleneck represents

Successful reconstruction requires the network to capture some generalization about the kinds of inputs it encounters. It is tempting to expect hidden neurons to specialize visibly in concepts such as short, medium, or tall. However, inspecting the input values that maximally stimulate the hidden neurons may yield one apparently short pattern while other neurons produce patterns that do not clearly represent medium or tall.

> The generalization may be encoded in a form that is not directly readable from the maximally stimulating inputs. This helps explain why neural networks can be difficult to understand: it may be unclear what internal neurons respond to or why the network succeeds on some recognition tasks and fails on others. There has been substantial work on interpreting these representations, but significant mystery remains.

### Layer-wise pretraining

1. Train one layer through an autoencoding setup.
2. Retain the trained input-to-hidden portion while removing the original output layer.
3. Use the retained layer’s output as the representation for training the next layer.
4. Continue successively through the network, accumulating knowledge about the environment.
5. After the intermediate layers have been trained, use samples from particular classes to train the class-related output layer.

A previously trained first layer can be detached from its original output layer, retained, and combined with a newly trained output layer. The weights connecting the input to the hidden layer are kept, while the original output layer is removed. The retained input/hidden portion is frozen, leaving an untrained output layer.

- Before the output layer is trained, test samples produce approximately one-half probability for each category even though the middle layer is trained.
- Training the outer layer with the sigmoid-based output mechanism quickly produces outputs that closely match the desired outputs.
- The combined approach brings together the autoencoding idea and the softmax idea.

Lecture reference: 8:33–17:18, 17:18–24:45, 24:45–33:47, 33:47–42:10

## Probabilistic output layers and supervised optimization

> A sigmoid output combines an input with a weight and threshold to produce a value that can represent the probability of a positive example. Training adjusts these parameters to increase the probability of observed data. For multiple classes, one output neuron is used per class, and softmax normalizes the outputs into class-associated probabilities.

### Sigmoid output and parameter effects

A final output neuron combines an input x with a weight w and a threshold T, then passes the result through a sigmoid to produce an output z. The threshold shifts the sigmoid horizontally, changing where the curve transitions between low and high output. The weight changes the steepness of the sigmoid.

**Sigmoid output**

```latex
z = \frac{1}{1 + e^{(...)}}
```

The sigmoid output depends on the weight w, input x, and threshold T.

### Probabilistic interpretation and optimization

The sigmoid output can be interpreted probabilistically. For a positive example, the probability is associated with the sigmoid value at that example’s input. For a negative example, the probability is 1 - z, where z is the sigmoid output for that input. The probability of observing the complete dataset depends on the shape of the sigmoid, which depends on w and T.

**Adjusting the output-layer parameters**

1. Change the weight and threshold so the classification behavior matches the observed samples.
2. Use partial derivatives or a related optimization procedure to adjust the parameters.
3. Maximize the probability of the observed data; the lecture characterizes this as ordinary gradient ascent rather than something mysterious.

**Demonstration**

A demonstration begins with an ordinary sigmoid, several positive examples, and a negative example. Gradient ascent changes the curve so that the probability of the positive examples increases while the probability of the negative example decreases. Adding a negative example in a compatible region produces little change. Adding a positive example in a conflicting region causes a dramatic shift in the curve and may indicate a noise point. Additional negative examples then adjust the curve further.

### Multiple output neurons and softmax

With many classes, the network uses one output neuron per class. For 1,000 classes, the output layer would contain 1,000 output neurons. The output for class 1 should be higher when the input belongs to class 1, while the output for class m should be higher when the input belongs to class m. This multiple-output interpretation is presented as another idea layered onto the basic back-propagation framework.

**Output values and class probabilities**

- A neural network produces one output for each class, but these outputs are not probabilities until they are normalized across all classes.
- Selecting the single largest output identifies a winner, but does not associate probabilities with every class.
- Softmax converts the entire output vector into class-associated probabilities, allowing several possible classifications to receive probabilities, such as a primary classification plus second, third, fourth, or fifth alternatives.

**Class-specific normalization**

```latex
P(\text{class } 1)=\frac{\text{output}_1}{\sum_i \text{output}_i}
```

The probability for class 1 is computed from its output divided by the sum of the outputs for all classes.

Lecture reference: 24:45–33:47, 33:47–42:10

## Deep-network training, width, and optimization behavior

> The lecture describes dropout, the apparent breadth of deep networks, and experiments showing that width and initialization affect optimization. A five-layer network can learn an animal classification task, while reducing width before training can trap the network at a local maximum. Widening can turn such local maxima into saddle points, allowing optimization to continue.

### Dropout and network behavior

Dropout randomly determines which neurons remain active during each training iteration. A coin flip is used for each neuron; a neuron selected for removal has no influence on the output during that iteration. A different subset may be removed on the next iteration. The intended effect is to reduce the tendency of the network to settle into a frozen local-maximum state.

### Width, depth, and training methods

The lecturer argues that networks commonly called deep nets might more accurately be called wide nets. They can contain many neurons per layer but usually have fewer than about ten columns of depth.

**Methods discussed**

- Methods involving probabilistic output layers, autocoding, or Boltzmann machines do not appear to improve substantially over plain backpropagation in the comparison described.
- Backpropagation with a convolutional network is presented as performing about as well as the more sophisticated alternatives discussed.

### Five-layer animal-classification demonstration

A five-layer classroom network classifies an animal as a cheetah, zebra, or giraffe using the height of its shadow. Green indicates positive outputs and red indicates negative outputs. Before training, every test sample produces an output of one-half regardless of the animal.

**Training behavior**

1. Ordinary backpropagation is applied to the deeper network, which has five columns with approximately nine or ten neurons per column and many more parameters.
2. During training, the outputs initially become entirely negative. This is interpreted as the safest response when the actual animal is uncertain and many possibilities exist.
3. After approximately 160,000 iterations, the network classifies the test samples successfully.
4. Repeated runs show a long period with little visible change, followed by a sharp decline in the error rate and rapid convergence toward a solution.

### Redundancy and retraining after removing neurons

The demonstration tests network redundancy by removing one neuron from every column and retraining the reduced network. One neuron in each column is removed and reassigned to another purpose, leaving fewer neurons in the network.

**Reducing the network before or after training**

- When the network is first trained and then reduced to two neurons per column, it retains a solution. The reduced network can retrain very quickly, suggesting that it remains sufficiently close to a workable solution.
- Repeated trials generally rise briefly and then quickly settle into a solution.
- The transcript ends while the lecturer is continuing to remove components and retrain, so the broader effect remains unresolved.

### Width and local maxima

A five-layer network with only two neurons in each column can still have a solution when trained normally. However, if all but two neurons in each column are removed before training, the network can become trapped in a local maximum even though a solution exists.

**Optimization interpretation**

> Widening the network turns local maxima into saddle points. This gives the optimization process a path through the high-dimensional parameter space instead of leaving it stuck. The lecture presents this behavior as one reason for breakthroughs in neural-network learning.

Lecture reference: 33:47–42:10, 42:10–49:00

## Limits of neural-network visual understanding

> Neural networks can classify images successfully while remaining vulnerable to barely visible or highly unnatural changes. Their classifications may rely on local evidence and visual patterns without constituting human-like recognition or understanding.

### Sensitivity to small and local image changes

Small changes to only a few pixels can change a classifier’s high-confidence judgment. In one example, changing a very small number of pixels in a school-bus image was not perceptible to the lecturer, yet caused the classifier to stop identifying the image as a school bus. Online tools and research papers demonstrate ways to construct images that fool neural networks.

- The proposed explanation is that the classifier accumulates enough local negative evidence to exclude other classes and enough local positive evidence to select the school-bus class.
- Some images may trigger recognition through texture-like features that human viewers do not regard as decisive.
- A visually ambiguous example appeared to contain baseball-like texture, suggesting that texture may contribute to the classifier’s decision.

### Fluent captions without human-like concepts

Image-captioning systems can produce plausible labels without possessing the concepts or experiences implied by their captions. The system is characterized as labeling visual patterns rather than understanding the depicted activity or situation. It may lack knowledge of what it is like to play, be young, move, or use a Frisbee.

The captioning examples included cases where a cat was identified correctly but described inaccurately, and a little girl was identified without correctly recognizing that she was blowing bubbles. These partially incorrect captions illustrate that fluent labeling does not guarantee semantic understanding.

### Preserved classifications after severe image mutilation

1. Separate an image into slices corresponding to frequency bands.
2. Remove a rectangle from one frequency band.
3. Reassemble the remaining components.
4. Increase the removal as much as possible while retaining the neural network’s impression that the image belongs to its original class.

The resulting images can be difficult for people to recognize, revealing a substantial gap between network classification and human visual perception. An image originally classified as a railroad car was altered so extensively that the human interpretation became unclear, yet the network retained the railroad-car classification. A guitar image could not be mutilated as much while preserving the network’s guitar classification. Other altered images were classified by the network as a barbell, grasshopper, two nearby wolves, a rabbit, and a Russian wolfhound, although audience members often perceived different objects.

> These demonstrations show strong task performance alongside vulnerability to imperceptible or highly unnatural image changes. The network’s internal evidence can remain sufficient for a classification even when the image no longer supports the corresponding human interpretation. Neural networks are an engineering marvel and accomplish important tasks, but they do not see as humans see.

Lecture reference: 42:10–49:00

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 12B: Deep Neural Nets. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=VrMHA3yX_QI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-12b-deep-neural-nets/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
