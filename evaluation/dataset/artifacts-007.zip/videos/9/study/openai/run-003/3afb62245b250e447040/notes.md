# Study notes



## Neural computation and efficient backpropagation

> Although a neural network may contain exponentially many paths from inputs to outputs, derivatives of output performance with respect to earlier weights can be computed efficiently. Chain-rule expansions reuse shared intermediate derivatives while moving backward through the network, making the calculation linear in network depth rather than exponential in the number of paths.

### Neuron computation

A neuron multiplies inputs by weights, sums the products, and passes the result through a nonlinear function such as a sigmoid. The pre-activation value is the weighted sum of corresponding weights and inputs, which is also the dot product of the weight vector and the input vector.

**Weighted sum**

```latex
\sum_i w_i x_i
```

Here, w_i denotes a weight and x_i denotes the corresponding input.

**Context for the dot product**

- In the lecture’s models, inputs are often binary, taking values 0 or 1.
- Biological neural activity need not be strictly all-or-none; proportional activity would support a more literal real-valued dot-product interpretation.
- The dot product is presented as a fundamental calculation that may also occur in cognition.

### Efficient derivative computation

A network’s influence is organized through a limited number of variables at each layer. An output cannot affect an earlier weight except through the finite set of variables connecting the layers. Derivatives of performance with respect to weights are expanded using the chain rule along the relevant paths.

**Backpropagation through shared computations**

1. Expand derivatives of performance with respect to weights using the chain rule along the relevant paths.
2. Identify shared initial factors and intermediate expressions among different weight derivatives.
3. Reuse quantities already computed for downstream weight updates.
4. Move backward from outputs toward inputs, repeatedly reusing computations instead of recomputing them.

**Computational result**

> Different weight derivatives share initial factors and intermediate expressions. Reusing these computations makes the resulting calculation linear in the depth of the neural network, rather than exponential in the number of paths.

Lecture reference: 0:00–8:33

## Convolutional networks and large-scale image classification

> The lecture presents convolutional networks as assemblies of local convolution, pooling, repeated kernels, and later neural-network layers. A 2012 system achieved about 15% top-five error and about 37% top-choice error, while large computational resources enabled roughly 60 million parameters, 1,000 classes, and about one million training samples.

### Performance and system structure

The lecture discusses the performance of a 2012 system using two error measures. A system counted as correct when the right answer appeared among its five highest-ranked choices had an error rate of about 15%. When correctness required the right answer to be the single highest-ranked choice, the error rate was about 37%. This performance was characterized as strong, particularly because some cases are ambiguous even for humans.

**Interpreting the diagram**

> The system did not have exactly the simple diagram shown, but the diagram captured its essential structure. The lecture focuses on the components from which such systems are made, treating the system as one particular assembly of components commonly found in neural-network systems rather than as something uniquely special.

### Convolution over local image regions

Convolution applies a neuron to local regions of an image and shifts it across the image to produce spatially associated outputs. In the example, an image is compressed to approximately 256-by-256 pixels, and a neuron examines only a local 10-by-10 square. The neuron is shifted across the image, producing an output at each deployment; each output is associated with a particular image location. The local neuron or convolution operation is called a kernel.

**Terminology qualification**

> The term “convolution” is borrowed from Signals and Systems, but the operation described here is not the same as convolution involving impulse responses, convolution integrals, or memory. The processing described has no memory involved in how the signals are handled.

### Pooling and repeated kernels

After convolution produces a set of points, local neighborhoods of those points are examined. The maximum value in each local neighborhood is used to construct another mapping of the image. The pooling operation is shifted across the outputs to produce further values. Because the maximum is selected, this specific form is called max pooling.

**From an image to pooled features**

1. A 10-by-10 kernel is repeatedly shifted across a 256-by-256 image, producing output points associated with image locations.
2. A local neighborhood of convolution outputs is scanned, and its maximum value is retained.
3. The pooling operation is shifted to neighboring regions to create a new mapping.
4. The output produced by one kernel can be replicated using many kernels; a typical number mentioned is 100.
5. The resulting features are fed into further neural-network layers, potentially including fully connected final layers.

The combined process described uses a 256-by-256 image, a 10-by-10 kernel, local maximum selection, and repetition across approximately 100 kernels. The ultimate output can indicate how likely it is that the image contains a particular object, such as a mite.

### Scale of modern systems

**Older and modern arrangements**

- Older systems might use a small grid of pixels, with pixel values supplied as inputs to neurons arranged in a few successive columns. An output might identify a digit, such as whether an image represents the number 1.
- The modern comparison uses 1,000 classes rather than 10 digits, approximately 1,000 examples per class, and about one million samples in total.
- The modern example has about 60 million parameters, described as many more than the few hundred parameters in older systems.
- Greater computational resources support more parameters, more classes, and many more training examples than were typical in earlier neural-network systems.

The resulting network is characterized as a function approximator whose performance is surprising and not fully explained. The lecture states that no one quite knows why this arrangement works so well, while immense computation makes unexpectedly high performance possible.

Lecture reference: 0:00–8:33, 8:33–17:18

## Autoencoders, bottleneck representations, and layerwise pretraining

> An autoencoder, also called autocoding in the lecture, compresses an input through a smaller hidden layer and reconstructs it at the output. Training uses desired values identical to the inputs, so the network learns regularities in the data rather than external class labels. The encoded representation can support recognition while remaining difficult to interpret.

### Bottleneck architecture and reconstruction

The proposed network has an input layer, a much smaller hidden layer, and an output layer. Information is forced through the narrow hidden-layer bottleneck before being reconstructed at the output. For example, an input layer may have 10 neurons, a hidden layer may have only a couple of neurons, and the output may contain values z₁ through zₙ. These outputs are compared with desired values d₁ through dₙ.

**Desired values equal the inputs**

```latex
d_i = x_i
```

The desired output value for each position is set equal to the corresponding input value.

The lecture proposes setting the desired values equal to the inputs, so the network learns to reproduce what it receives. The explanation ends before fully developing the training procedure or purpose. Successfully compressing many possible inputs into a smaller hidden layer and reproducing them requires the network to capture regularities in the inputs.

### Shadow-height reconstruction example

A simplified network receives shadow-height patterns for a cheetah, a zebra, and a giraffe. Ten input neurons represent levels of the shadow, the information passes through three hidden-layer neurons, and the output layer produces reconstructed values. The patterns correspond qualitatively to short for a cheetah, medium for a zebra, and tall for a giraffe.

1. Before training, the network contains random values and produces outputs near 0.5 for the test shadow patterns.
2. Using a simple backpropagation-like setup, described as the same approach used in the world's simplest neural net, train the network for the demonstration.
3. After 1,000 training iterations, the output values become very close to the desired input values for the test cases.

**What the network learns**

> The network is not learning animal classifications. Because its only input is shadow height, it has no direct information about animal categories that might later be associated with those inputs. Successful reconstruction indicates consistency in the input data rather than explicit classification knowledge.

### Encoded representations and interpretability

The bottleneck suggests that some generalization is necessary because varied inputs must be represented through only a few hidden neurons. However, the learned representation is encoded rather than necessarily expressed as a directly visible generalization in individual neuron activations.

- Inspecting the input values that maximally stimulate hidden neurons does not reliably reveal obvious short, medium, or tall representations.
- One hidden neuron appears related to short inputs, while the other neurons produce patterns that look random or uninterpretable.
- The hidden layer can contain an encoded generalization without making that generalization transparent through individual neuron activations.
- This opacity makes it difficult to explain why a neural network recognizes a cheetah or a school bus in one situation but not another.
- Substantial work has aimed to interpret these representations, but much remains mysterious.

The demonstration is identified as the autocoding or autoencoding idea, which appears in multiple forms and in many deep-neural-network papers.

### Visualizing learned weights

The demonstration visualizes learned weights using color and intensity. Green connections represent positive weights, with greater green density indicating a more positive weight. Red connections represent negative weights, with greater red intensity indicating a more negative weight. Before substantial training, the mixture of red and green connections appears largely random.

### Layerwise pretraining

1. Train the input layer or first layer on the available data.
2. Use the trained layer to provide the basis for training the next layer.
3. Continue sequentially through the network, with each trained layer supporting training of the next.
4. After the network has accumulated knowledge about the environment and its observable structure, train on particular labeled classes at the final stage.

In this approach, training on particular classes is deferred until the final stage. Boltzmann machines are presented as following essentially the same general idea.

Lecture reference: 8:33–17:18, 17:18–24:45, 24:45–33:47

## Sigmoid likelihoods, multiclass probabilities, and output-layer training

> A sigmoid output models the probability of a positive or negative example through parameters controlling the curve. For multiple classes, sigmoid outputs are normalized with softmax so every class receives a probability. A retained, frozen hidden layer can then support separate training of a new softmax-related output layer.

### Sigmoid output and likelihood

A final output neuron combines an input with a weight and threshold, then passes the result through a sigmoid. The output can be related to the probability of observing a positive class example. For a negative example, the modeled probability is 1 minus the sigmoid value at that input.

**Sigmoid expression**

```latex
z = \frac{1}{1 + e^{-wx + T}}
```

The lecture presents this sigmoid expression while correcting the placement of the sign in the exponent.

**Effect of the parameters**

- The sigmoid depends on the weight w and threshold T.
- Changing T shifts the sigmoid horizontally, changing where its transition occurs.
- Changing w changes the steepness of the sigmoid.
- The probability of the complete observed dataset depends on the curve’s shape, which depends on w and T.

### Adjusting the curve to fit observed data

The weight and threshold are adjusted so that the sigmoid assigns high probability to positive examples and low probability to negative examples. Maximizing the probability of the observed data requires adjusting these parameters using partial derivatives and gradient-based optimization.

**Gradient-ascent behavior**

1. Begin with an ordinary sigmoid and observed positive and negative examples.
2. Adjust the curve through gradient ascent.
3. Increase the probability assigned to positive examples and decrease the probability assigned to non-examples.
4. Treat a positive example in an unexpected region as a possible noise point when it causes a dramatic shift in the curve; additional negative examples can shift the curve in response.

In the demonstration, adding a negative example in a region already consistent with the current curve produces little change. Adding a positive example in that region causes a substantial adjustment.

### From sigmoid outputs to multiclass probabilities

For many classes, the network has one output neuron per class. With 1,000 classes, the output layer would contain 1,000 output neurons. Each neuron produces a higher value when the input corresponds to its associated class: the output for class 1 should be higher for class 1 inputs, while the output for class m should be higher for class m inputs.

**Why normalization is needed**

> A sigmoid-based output for each class is not by itself a complete probability distribution. The lecture distinguishes assigning probabilities to all classes from merely declaring the class with the largest output the winner. Softmax normalizes the outputs across classes and assigns a probability to every possible classification.

**Class 1 probability**

```latex
p(\text{class 1}) = \frac{\text{output}_1}{\text{sum of all class outputs}}
```

The probability for class 1 is its output divided by the sum of the outputs across all classes.

The resulting predictions can express one likely class while retaining probabilities for several alternatives. A sample may be classified primarily as one category while also receiving nonzero probabilities for a second, third, fourth, or fifth category.

### Retaining a hidden layer and retraining the output layer

**Separate output-layer training**

1. Detach the original output layer from a trained hidden layer.
2. Retain the weights connecting the input to the hidden layer.
3. Freeze the retained input-to-hidden portion.
4. Use a new, initially untrained output layer.
5. Train the new output layer with softmax-related classification.

Before the output layer is trained, test samples produce approximately one-half output for each category despite the trained middle layer. After the outer layer is trained, the outputs closely match the desired outputs. This is presented as a combination of the autocoding idea and the softmax idea.

Lecture reference: 24:45–33:47, 33:47–42:10

## Optimization, dropout, network width, and local maxima

> Dropout changes the active subnetwork across training iterations, while increasing network width can turn problematic local maxima into saddle points. The lecture also presents ordinary backpropagation with a convolutional network as performing about as well as more elaborate alternatives in the discussed context.

### Dropout and changing active subnetworks

For every neuron on each training iteration, a random decision determines whether it remains active. A neuron selected for removal has no influence on the output during that iteration, and a different set of neurons may be removed on the next iteration. This changing active subnetwork is described as helping prevent the network from settling into a frozen local-maximum state.

### Network width and alternative methods

- The lecturer suggests that these models might more accurately be called wide nets because they can be extremely wide while rarely exceeding about ten columns in depth.
- Methods involving probabilistic output layers, autocoding, or Boltzmann machines are said not to provide much improvement over plain backpropagation in the discussed context.
- Backpropagation with a convolutional net is presented as performing about as well as the more elaborate alternatives.

### Five-layer classification demonstration

A classroom demonstration uses ordinary backpropagation to train a five-layer network to classify an animal as a cheetah, zebra, or giraffe from the height of its shadow. Before training, every test sample produces an output of one-half regardless of the animal. The network has five columns, each containing approximately nine or ten neurons, creating many more parameters than the earlier example.

- During training, the outputs initially become negative for all possibilities, represented as red.
- The all-negative result is interpreted as a reasonable response when the network is uncertain among many possibilities: answering no for everyone is treated as the most probable answer under uncertainty.
- After approximately 160,000 iterations, the network classifies the test samples successfully.
- Repeated runs show a long period with little visible progress followed by a rapid decline in the error rate, described as the error falling off a cliff.

**Demonstration summary**

- Input: height of an animal's shadow; possible outputs: cheetah, zebra, giraffe.
- Initial untrained output: 1/2 for each test sample.
- Training method: ordinary backpropagation.
- Observed result: successful classification after about 160,000 iterations.

### Width, initialization, and local maxima

A network with only two neurons per column can have a valid solution, but discovering it depends on initialization. The lecturer raises the unresolved question of what would happen if the network were narrower. When training begins with all but two neurons per column removed, the network can become stuck in a local maximum despite the existence of a solution. The same two-neuron-per-column architecture had previously reached a solution under a different experimental setup.

Increasing network width can transform local maxima into saddle points. This gives the optimization process a way to move through the parameter space instead of remaining stuck.

### Removal-and-retraining experiments

1. The network is retrained after one neuron is removed from each column.
2. It still reaches a solution quickly, suggesting that the network remains close enough to a workable solution without those neurons.
3. In repeated removal-and-retraining trials, the network may rise somewhat in error but then quickly fall back to a solution. The transcript ends while this experiment is continuing.
4. In another experiment, extra neurons are removed before training from a network that had previously found a solution quickly with two neurons in each of five columns.
5. The repeated experiment produces increasingly poor results and apparent entrapment in a local maximum.

Lecture reference: 33:47–42:10, 42:10–49:00

## Limits of neural-network vision and understanding

> Neural networks can perform highly capable recognition and labeling tasks while relying on visual evidence that differs from human perception. Small pixel changes can alter classifications, and severe frequency-based image damage can preserve them. Image captions likewise do not establish that a system understands the objects, activities, or experiences it describes.

### Recognition can depend on imperceptible cues

Online demonstrations allow users to submit images and observe neural-network classifications. A network may change a high-confidence classification after only a very small number of pixels are modified, even when the image appears unchanged to a human observer.

In one example, an image classified with high confidence as a school bus was altered by changing a very small number of pixels. The change was imperceptible to the lecturer but caused the network to stop classifying it as a school bus. The apparent school-bus judgment may result from enough local evidence against the other 999 classes combined with enough positive local evidence for the school-bus class.

**Human and machine cues can differ**

> Humans may not perceive the visual cues that drive a network’s decision. Recognition success therefore does not establish that the system has formed a human-style interpretation of the object or scene.

### Captioning is labeling, not demonstrated understanding

Image-captioning systems can produce descriptions that may lead a naive viewer to believe that the system understands the activities, objects, or experiences depicted in an image. Their demonstrated capability is labeling the image, not understanding what it is like to play, be young, move, or use a Frisbee.

- A caption may correctly identify a cat without making a meaningful claim beyond the object label.
- A system may identify a little girl while incorrectly saying that she is blowing bubbles.
- Examples of incorrect or incomplete captions expose the gap between labeling and understanding.
- The systems can be highly capable while still failing in ways that humans readily recognize.

### Frequency-band alterations reveal a perception mismatch

An image can be decomposed into slices, each representing a particular frequency band. A rectangular region is removed from one frequency band, after which the frequency components are reassembled into a modified image. The procedure removes as much information as possible while retaining the network’s impression that the image belongs to its original class.

The resulting images may be difficult or impossible for people to identify, even when the network retains its classification. An image originally identified as a railroad car was heavily altered through frequency-band removal while retaining the network’s railroad-car classification. An image identified as a barbell was perceived by audience members as a lamp, toilet, or cello.

- A guitar image could be altered only modestly before the network lost its guitar classification.
- Other altered images retained classifications such as grasshopper, rabbit, giraffe, or Russian wolfhound despite being difficult for people to recognize.
- The systems can exploit local visual evidence and texture-like cues without forming a human-style holistic interpretation.

### Overall implication

The demonstrations support the conclusion that machine vision and human visual perception are fundamentally different in important respects. Neural networks are engineering achievements that perform useful recognition tasks, but they do not see in the same manner as humans. Recognition success does not establish understanding of the object, scene, activity, or experience represented.

Lecture reference: 42:10–49:00

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 12B: Deep Neural Nets. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=VrMHA3yX_QI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-12b-deep-neural-nets/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
