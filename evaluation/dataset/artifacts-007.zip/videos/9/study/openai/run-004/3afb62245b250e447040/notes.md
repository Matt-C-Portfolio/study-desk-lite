# Study notes



## Backpropagation computational reuse

> Although a neural network may contain exponentially many paths from weights to outputs, derivatives can be computed efficiently because paths share variables and partial-derivative factors. The chain rule exposes these repeated terms, allowing intermediate quantities to be computed once and reused. This makes the calculation linear in network depth rather than exponential in the number of paths.

### Shared derivative structure

The derivative of performance with respect to an early weight includes contributions from multiple paths through the network. However, the finite number of variables connecting successive columns constrains how these paths influence one another.

**Sources of reuse**

- Expressions for derivatives of different weights share initial and internal factors.
- Intermediate calculations used for downstream weight updates can reappear when calculating derivatives farther back toward the inputs.
- The key principle is that computed quantities need not be recomputed.

### Computational consequence

Applying the chain rule reveals repeated partial-derivative terms. Computing these terms once and reusing them avoids separately evaluating every path, making the calculation linear in the depth of the neural network rather than exponential in the number of paths.

Lecture reference: 0:00–8:33

## Neuron Dot Products and Nonlinear Activation

> A neuron computes a weighted sum by multiplying each input by its corresponding weight and summing the products. This pre-activation value is then passed through a nonlinear function, such as a sigmoid. The weighted sum is the dot product of the weight and input vectors.

### Weighted sum and activation

The neuron first computes the pre-activation value by multiplying each input by its corresponding weight and summing the products. The summation occurs before the nonlinear activation.

**Pre-activation value**

```latex
\sum_i w_i x_i
```

Here, w_i denotes a weight and x_i denotes its corresponding input.

The resulting weighted sum is the dot product of the weight and input vectors. A nonlinear function, such as a sigmoid, then transforms this value.

### Interpretive connections

- The lecture connects dot products with the idea that they may be a fundamental computation in the brain.
- Simple models often use binary inputs.
- Biological neuron values may vary proportionally, yielding a more directly real-valued dot product.

Lecture reference: 0:00–8:33

## Deep-network image-classification performance and scale

> A 2012 deep-network system achieved strong image-classification performance despite ambiguity in some images. Its top-five error rate was about 15%, while its top-choice error rate was about 37%. Compared with older neural networks, modern systems use much more computation, more parameters, more classes, and far more training data, although the lecture states that there is no complete explanation for why this arrangement performs so well.

### Classification performance

The system’s top-five error rate was approximately 15%. This means that the correct answer was absent from the system’s five highest-ranked choices about 15% of the time. Its top-choice error rate was approximately 37%, meaning that the single highest-ranked answer was incorrect about 37% of the time.

The lecturer describes this performance as strong, particularly because some examples are ambiguous even for humans.

### Essential structure and earlier systems

The system did not literally have the exact diagram shown, but the diagram represented its essential structure. Earlier systems could use a small grid of pixels as inputs, with columns of neurons processing those pixels and later neurons recognizing categories such as the digit 1.

### How modern systems differ in scale

- Parameters: a shift from a few hundred parameters to about 60 million parameters.
- Classes: a shift from 10 digit classes to 1,000 classes.
- Training data: roughly 1,000 examples per class, or about one million samples in total.
- Computation: the modern arrangement is described as using far more computation than older systems.

The resulting network is characterized as a function approximator with unexpectedly strong performance. The lecture states that there is no complete explanation for why immense computation in this arrangement produces such performance.

Lecture reference: 0:00–8:33, 8:33–17:18

## Convolutional neural networks: kernels, pooling, and classification

> Convolution applies a kernel repeatedly across local image regions to produce spatially associated outputs. Pooling summarizes neighborhoods, with max pooling selecting their largest values. Repeating these operations with many kernels produces features that can be passed to later neural-network layers for classification.

### Convolution and kernels

The term “convolution” is borrowed from Signals and Systems, but the operation described here does not involve memory or the same convolution integrals used for signal processing. A neuron, also called a kernel, is shifted across local regions of an image. Each deployment produces an output associated with a particular image location, and a single kernel produces a collection of output points, or a mapping, over the image.

**Example dimensions**

> The example uses an image compressed to 256×256 pixels and a 10×10 local region. The stated sequence begins with a 256×256 image and a 10×10 kernel moved across it.

### Pooling

After convolution, local neighborhoods of the resulting points are examined. Pooling summarizes values in these local neighborhoods. In max pooling, the maximum value in each neighborhood is selected, and the pooling operation is shifted across the mapping to produce further outputs.

**Max pooling in this example**

- The maximum value in each neighborhood is retained.
- The operation produces another mapping or further outputs.
- The operation is specifically called max pooling because it uses maximum values.

### Repeated processing and classification

**Stated processing sequence**

1. Start with a 256×256 image.
2. Move a 10×10 kernel across local image regions to produce spatially associated outputs.
3. Apply max pooling to local neighborhoods of the resulting points.
4. Repeat convolutional processing across many kernels; a typical arrangement may use approximately 100 kernels.
5. Pass the resulting features to later neural-network layers, potentially including fully connected final layers.
6. Produce an output indicating how likely the image is to belong to a category such as a mite.

Lecture reference: 8:33–17:18

## Autocoding, bottleneck representations, and layer-wise training

> Autocoding trains a network to reconstruct its input after the input passes through a substantially smaller hidden layer. The bottleneck encourages the network to capture regularities in the data rather than animal-class labels. Representational layers can be trained successively, with class-specific training deferred until the final stage.

### Architecture and reconstruction objective

An autocoding network has an input layer, a substantially smaller hidden layer, and an output layer. All input information must pass through the narrow hidden-layer bottleneck before the network reconstructs the input at the output.

- The illustrative structure mentions 10 neurons in the input layer and only a couple in the hidden layer.
- The hidden layer is a narrow bottleneck through which all input information must pass.
- The output values are labeled z1 through zn and are compared with desired values d1 through dn.
- The desired output values are defined as the original input values, so the network is trained to reproduce its input.

**Desired output**

```latex
d_i = x_i
```

Each desired output value is identical to the corresponding input value.

### Shadow-pattern example

A toy network receives a shadow represented by 10 input neurons, one for each shadow-height level. It compresses the input into 3 hidden-layer neurons and then produces output values. The cheetah, zebra, and giraffe shadows provide input patterns whose reconstructed outputs become close to the corresponding input patterns after training.

**Before and after training**

- Before training, the network has random weights and produces values near 0.5 for the test shadows.
- After 1,000 training iterations, the output closely matches the desired input values for the cheetah, zebra, and giraffe examples.

Connection colors visualize weights: green indicates positive weights, red indicates negative weights, and greater color intensity indicates a larger magnitude.

### What the bottleneck represents

The network is not explicitly trained to classify animals. Because it receives only shadow heights, it has no direct knowledge of the animal categories that a later system might use. To reproduce the input after compression, it must capture regularities or generalizations in the kinds of inputs it receives. Successful reconstruction indicates that consistency in the input data has been captured in the hidden representation.

**Limits of interpretation**

The bottleneck suggests that the hidden layer performs some form of generalization, but the generalization is encoded rather than necessarily visible in individual neuron activations. Inspecting the input values that maximally stimulate hidden neurons does not reliably reveal clear short, medium, or tall categories: one neuron may resemble short, while others may appear random. This illustrates why neural networks are difficult to understand. Although substantial work attempts to explain what such networks respond to, their internal behavior remains partly mysterious.

**Scope of the supplied explanation**

> The supplied lecture span ends while the reconstruction idea is being explained; no further training objective or interpretation is provided.

### Layer-wise training and deferred classification

1. Train the input layer first.
2. Use the trained layer to provide the input for training the next layer.
3. Continue training layer by layer so the network accumulates knowledge about the environment.
4. After the representational layers are trained, use samples from particular classes for class-specific training.

Each trained layer provides the input for training the next layer. Class-specific training is deferred until the final stage, after the network has accumulated knowledge about the environment. This staged procedure is identified as the story of autocoding. Boltzmann machines are presented as another instance of essentially the same general idea.

Lecture reference: 8:33–17:18, 17:18–24:45, 24:45–33:47

## Sigmoid outputs, likelihood optimization, and softmax classification

> A sigmoid neuron combines an input with a weight and threshold to produce an output. Adjusting these parameters can maximize the likelihood of labeled examples. For many classes, softmax normalizes the complete output vector so each class receives a probability, including multiple plausible alternatives.

### Sigmoid output and parameter effects

A final-layer neuron combines an input x with a weight w and threshold T, then passes the result through a sigmoid to produce an output value z. The output is interpreted in relation to the probability of a class.

**Sigmoid output**

```latex
z = \frac{1}{1 + e^{-wx + T}}
```

The lecture notes that the exact sign placement of T was being checked during the explanation.

**Effects of the parameters**

- Changing T shifts the sigmoid horizontally, changing where the curve transitions.
- Changing w changes the steepness of the sigmoid.

### Likelihood optimization

The sigmoid parameters are adjusted so that the observed labeled examples have the highest possible probability under the model. The probability of the observed data depends on the shape of the sigmoid, which depends on w and T.

**Probabilities for labeled examples**

- For positive examples, the probability is associated with the sigmoid value at their input locations.
- For negative examples, the probability is one minus the sigmoid value at their input locations.

**Gradient-ascent adjustment**

1. Adjust w and T using partial derivatives or an equivalent optimization procedure.
2. Change the curve so that the likelihood of positive examples increases.
3. Change the curve so that the likelihood of negative examples decreases.

**Demonstration**

A demonstration begins with positive and negative examples placed along an ordinary sigmoid curve. Gradient ascent changes the curve to increase the probability of the positive examples and decrease the probability of the negative example. Adding a negative example in a region where the current curve already handles it well produces little change. Adding a positive example in a conflicting location causes a dramatic shift in the curve and may indicate a noise point. Additional negative examples then adjust the curve further.

### Many classes and softmax normalization

For a problem with many classes, the output layer contains one neuron per class. With 1,000 classes, it has 1,000 output neurons. Each output neuron is associated with one class: the output for class 1 should be higher when the input belongs to class 1, and the output for class m should be higher when the input belongs to class m.

**Why sigmoid outputs alone are insufficient**

> A sigmoid output for each class is not by itself a normalized probability across all classes. The desired interpretation is to associate a probability with every class, rather than simply select whichever output has the largest value.

**Class-output normalization**

```latex
P(\text{class 1}) = \frac{\text{sigmoid output for class 1}}{\sum\text{corresponding class outputs}}
```

The normalization factor converts the set of class outputs into probabilities.

Softmax normalizes the complete output vector. The resulting predictions can assign probability to several possible classifications, such as a primary object and additional alternatives, rather than retaining only a single winner-take-all score.

Lecture reference: 24:45–33:47, 33:47–42:10

## Pretrained hidden layers and output-layer retraining

> A hidden layer can be trained first and then detached from its original output layer. Its input-to-hidden weights are retained and frozen while a new output layer is trained using sigmoid-based outputs. Before retraining, test samples produce approximately one-half for every category; afterward, outputs match the desired outputs very closely. This combines the autocoding idea with the softmax idea.

### Retraining process

The hidden layer is trained first and then detached from its original output layer. The input-to-hidden weights are retained and frozen, while a new output layer is trained using sigmoid-based outputs.

### Observed outputs

- Before retraining the output layer, test samples produce approximately one-half for every category despite the trained middle layer.
- After the outer layer is trained, the outputs match the desired outputs very closely.

### Conceptual connection

This combines the autocoding idea with the softmax idea.

Lecture reference: 33:47–42:10

## Backpropagation, dropout, network width, and optimization landscapes

> The lecture presents dropout and network widening as methods that can improve optimization. Wider networks may transform local maxima into saddle points, while convolutional networks trained with ordinary backpropagation are described as a strong baseline against more sophisticated output-layer and pretraining techniques.

### Dropout and training behavior

Dropout randomly removes neurons during each training iteration. A neuron is treated as inactive when its randomly assigned coin flip indicates removal, and a different subset of neurons may be removed on the next iteration. The stated motivation is to prevent a neural network from becoming trapped in a frozen local maximum.

The lecture presents a dropout-like variation in which one neuron is removed from each column and the network is retrained for the same task. After this removal, the network retrains rapidly, suggesting that it remains close enough to a usable solution. Repeated trials generally rise briefly and then quickly settle into a solution.

### Classification example and backpropagation baseline

A classroom deep network with five layers classifies an animal as a cheetah, zebra, or giraffe using the height of its shadow. Green represents a positive output and red a negative output. Before training, every test output is one-half regardless of the animal.

The network uses ordinary backpropagation and has substantially more parameters: five columns with roughly nine or ten neurons per column. At an early stage, the outputs become entirely negative, interpreted as the network choosing “no” for every category when uncertainty is high. After approximately 160,000 iterations, it begins classifying the test samples successfully.

Repeated runs show a long period with little visible change followed by a rapid decline in the error rate. The error curve is described as falling off a cliff after the prolonged plateau.

**Comparison with more sophisticated approaches**

- Despite probability-based output layers and training approaches such as autocoding or Boltzmann machines, the lecture states that convolutional networks trained with ordinary backpropagation perform about as well as these alternatives.
- Convolutional-network backpropagation is presented as a strong baseline.
- The claimed comparison is between advanced output-layer and pretraining techniques and plain backpropagation.

### Network width and optimization landscapes

The lecture characterizes deep networks as typically very wide and rarely more than about ten columns deep. It raises the unresolved question of what would happen if the network were made less wide.

**Two-neuron-per-column experiments**

- In one experiment, training found a solution after the network had been reduced to two neurons in each of five columns.
- In a second experiment, the same reduction was performed before training; optimization appeared to become stuck at a local maximum despite the existence of a solution.
- The two conditions show that reaching a solution depends on initialization and training dynamics.

**Key optimization claim**

> The lecture characterizes a key neural-network-learning breakthrough as the use of wider networks to turn local maxima into saddle points. This transformation gives optimization a route through a large parameter space without remaining trapped at a local maximum.

Lecture reference: 33:47–42:10, 42:10–49:00

## Limits of neural-network visual understanding

> Neural networks can classify images confidently using distributed local or frequency-specific cues that do not correspond to the visual evidence humans use. Small pixel changes can reverse a classification, captioning systems can produce plausible but incomplete labels without understanding activities or situations, and frequency-band alterations can preserve a network’s label after humans lose the object’s recognizable structure.

### Classification can depend on non-human visual evidence

Online demonstrations and published research show that very small pixel changes can make a network change from high-confidence recognition of a school bus to rejection of the school-bus class, even when humans cannot readily see the difference. Some images also expose texture-based cues that humans do not treat as defining the object.

The lecture suggests that a network’s apparent school-bus judgment may combine enough local negative evidence against the other 999 classes with enough local positive evidence for the school-bus label. This challenges the idea that neural-network classification reflects human-like visual perception.

**Examples**

- An image initially classified with high confidence as a school bus was altered by changing a small number of pixels. Humans could not readily see the difference, but the network no longer classified it as a school bus.
- A visually ambiguous image appeared to contain some baseball-like texture, suggesting that texture could contribute to the network’s classification.

### Image captioning without demonstrated understanding

Image-captioning systems can assign labels or captions without knowing what it is like to play, be young, move, or understand what a Frisbee is. Their outputs may appear impressive to a naive viewer while remaining limited to learned visual-label associations.

**Observed limitations**

- A captioning system correctly identified a cat but produced an inaccurate or incomplete description for an image of a girl, failing to identify that she was blowing bubbles.
- Some captions are plausible but incomplete or incorrect, such as identifying a girl while missing that she is blowing bubbles.
- The concern surrounding artificial intelligence is partly stimulated by interpreting fluent image labels as evidence of understanding.
- The lecture credits the cited researchers for showing examples where the captioning system performs poorly.

### Frequency-band image-mutilation procedure

A laboratory procedure decomposes an image into slices corresponding to frequency bands. A rectangular region is removed from one selected band, and the bands are then reassembled. The amount of removal is increased while retaining the network’s impression that the image belongs to its original class.

**Procedure**

1. Decompose an image into slices corresponding to frequency bands.
2. Remove a rectangle from one selected frequency band.
3. Reassemble the frequency bands into an image.
4. Increase the amount of removal while preserving the network’s original classification.

The resulting images can preserve the network’s classification despite losing the visual structure humans use for recognition. A network can retain an object label after substantial image mutilation that makes the object difficult or impossible for people to identify.

**Examples and contrasting responses**

- An image originally classified as a railroad car was heavily altered through frequency-band removal while remaining classified as a railroad car.
- A guitar image could not be mutilated as extensively while preserving the network’s guitar classification, suggesting that more of its recognizable structure was needed for that result.
- An image identified by the network as a barbell was perceived by viewers as possibilities including a lamp or toilet.
- Other altered images were identified by the network as a grasshopper, two closely positioned wolves rather than a two-headed wolf, a rabbit, a Russian wolfhound, and an object associated with Venice, while viewers often proposed different interpretations.

### Implication for visual understanding

**Network classifications and human perception**

- Neural network: Can retain an object label after small pixel changes or substantial frequency-band removal, using distributed local or frequency-specific cues.
- Human viewers: May see little or no relevant evidence, fail to recognize the altered object, or assign an entirely different category.
- Overall result: Impressive classification does not establish human-like visual understanding.

The demonstrations support the conclusion that neural networks are powerful engineering systems whose image recognition is not equivalent to human seeing. Their classifications can depend on cues that remain effective after human-recognizable content has been removed.

Lecture reference: 42:10–49:00

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 12B: Deep Neural Nets. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=VrMHA3yX_QI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-12b-deep-neural-nets/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
