# Study notes



## Neural-network computation and basic neuron operation

> A neuron forms a weighted sum of its inputs and passes that value through a nonlinear activation such as a sigmoid. Although a neural network may have exponentially many input-to-output paths, gradients can be computed efficiently by applying the chain rule and reusing shared intermediate derivatives during a backward pass.

### Efficient gradient computation

Network influence is organized through a limited number of intermediate output variables between layers. Downstream performance can affect an earlier weight only through these intermediate variables. The dependence of performance on a weight is expanded with the chain rule across the relevant paths.

**Backward reuse of derivatives**

1. Expand the dependence of performance on a weight with the chain rule across the relevant paths.
2. Reuse partial-derivative terms shared by the gradient expressions for different weights, including terms already computed for downstream weights.
3. Proceed backward from outputs toward inputs, reusing previously computed quantities instead of recomputing them.
4. Obtain a calculation that is linear in the depth of the neural network rather than exponential in the number of paths.

### Basic neuron operation

A neuron's inputs are multiplied by weights and summed to form a pre-activation value. This weighted sum is a dot product between the weight vector and the input vector. The result is then passed through a nonlinear activation such as a sigmoid.

**Pre-activation value**

```latex
z = \sum_i w_i x_i
```

Here, w_i are the corresponding weights and x_i are the inputs.

**Input conventions and biological analogy**

- In the lecture's simplified models, inputs are often binary, taking values 0 or 1.
- Biological neurons may produce values with proportional rather than all-or-none behavior, making the dot-product analogy more direct.

Lecture reference: 0:00–8:33

## Deep neural networks and recognition performance

> Deep neural networks extend layered neural-network structures and achieved notable image-recognition results in 2012. Their performance was reported using both top-five and top-choice error criteria. Compared with earlier systems, modern networks use far more parameters, classes, training examples, and computation, producing unexpectedly strong empirical results even though the reasons for their success are not fully understood.

### Recognition results and evaluation criteria

A 2012 system achieved notable image-recognition performance. Under the top-five criterion, a system counted as successful when the correct answer appeared among its five highest-ranked choices. The reported top-five error rate was about 15%. Under the stricter top-choice criterion, where only the highest-ranked choice counts, the reported error rate was about 37%.

These results were considered strong, particularly because some image categories are ambiguous even for humans.

### From earlier neural networks to modern systems

Earlier systems could process a small grid of pixels, with pixel values fed into neurons arranged in successive columns. An output neuron might detect whether an image resembles a particular digit, such as the number 1. The lecturer noted that the actual system did not look exactly like the simple diagram, although the diagram captured its essential structure.

**Scale contrasts**

- Earlier systems used a few hundred parameters; modern systems use about 60 million parameters.
- Earlier systems addressed 10 digit classes; modern systems address approximately 1,000 classes.
- Earlier systems used a few hundred samples; modern systems use roughly 1,000 examples per class, or about one million samples in total.
- Modern systems use vastly greater computation and scale than earlier neural networks.

### Function approximation and unresolved explanations

Modern systems act as function approximators with unexpectedly strong performance. The lecture states that the reasons for this success are not fully understood, beyond the observation that immense computation applied to this layered arrangement can produce results beyond prior expectations.

Lecture reference: 0:00–8:33, 8:33–17:18

## Convolutional neural networks for image classification

> A convolutional neural network shifts local kernels across an image to produce location-specific mappings, applies pooling to summarize local neighborhoods, and repeats convolution with many kernels before classification layers estimate whether the image contains a target class such as a mite.

### Convolution across an image

A local neuron, called a kernel, is shifted across an image. Each placement examines a local region and produces an output associated with a particular image location. The lecture uses “convolution” for this sliding local operation, while noting that it differs from convolution in Signals and Systems because no memory is involved in the signal processing described.

- The example image is approximately 256 by 256 pixels, contrasted with much larger 1,000-by-1,000 or 4,000-by-4,000 images.
- A kernel examines a local 10-by-10 image region and is shifted repeatedly across the image.
- Each kernel placement produces an output, yielding a mapping of values over image locations.

### Pooling and max pooling

After convolution produces a set of values, local neighborhoods are examined. A representative value is retained from each neighborhood; when the maximum value is selected, the operation is called max pooling. Sliding this pooling operation across the map produces successive pooled values and constructs another mapping.

### Multiple kernels and classification

Convolution is repeated with many kernels to produce multiple sets of results. A single kernel can be replaced by a collection of kernels; the lecture gives 100 kernels as a typical example. For a 256-by-256 image, the described pipeline applies 10-by-10 kernels, performs local maximum selection, and repeats the process across approximately 100 kernels.

1. Apply 10-by-10 kernels across the image.
2. Use local maximum selection to perform max pooling.
3. Repeat the process across approximately 100 kernels.
4. Feed the resulting values into a neural network, potentially including fully connected final layers.
5. Produce an output indicating how likely it is that the image contains a target class, such as a mite.

Lecture reference: 8:33–17:18

## Autoencoding and learned representations

> An autoencoder maps an input through a substantially smaller hidden layer and reconstructs it at the output. Training makes the desired output identical to the input, so successful reconstruction requires the hidden layer to capture regularities and generalizations. These encoded representations can be effective without forming simple, human-readable concepts.

### Network structure and training objective

An autoencoder begins with input values entering an input layer. The inputs are mapped to a substantially smaller hidden layer and then expanded into an output layer. In the simplified example, the input layer has 10 neurons, while the hidden layer has only a couple of neurons in one description and three neurons in the shadow-height demonstration.

**Reconstruction target**

```latex
z_i \approx d_i = x_i \quad \text{for } i=1,\ldots,n
```

The output values z_i are trained to match desired values d_i, which are set equal to the input values x_i.

**Key features**

- The network passes information through a narrow hidden layer before reconstructing it at the output.
- The output values are labeled z_1 through z_n and are compared with desired values d_1 through d_n.
- The desired output values are identical to the input values, making the task reconstruction rather than animal classification.
- Successful reconstruction requires the hidden layer to capture regularities in the input data.
- The autoencoding idea occurs in multiple forms and appears in many deep-neural-network systems.

### Shadow-height demonstration

A simplified network uses shadow height as input for cheetahs, zebras, and giraffes. Shadow height is represented with 10 input neurons, one for each shadow-height level, and the inputs pass through three hidden-layer neurons before producing the output values. The example associates cheetahs with shorter shadows, zebras with medium-height shadows, and giraffes with taller shadows, but the network is not explicitly trained with those classifications.

**Training and reconstruction**

1. Before training, the network contains random values and produces outputs around 0.5 for the different shadow heights.
2. The network is trained to reproduce each input pattern rather than to output an animal classification.
3. After 1,000 training iterations, the output values are very close to the desired values for the test cases.
4. For cheetah, zebra, and giraffe test cases, the outputs are close to their corresponding input values.

### What the hidden representation reveals

Because all information is forced through a narrow hidden layer, that layer must encode some form of generalization needed for reconstruction. The network learns consistency in the shadow-height data, but inspecting the hidden neurons does not reveal a simple, human-readable classification scheme such as short, medium, or tall.

**Encoded generalization and human interpretation**

- One hidden neuron appears related to short shadows.
- The other hidden neurons produce patterns that look random or do not clearly represent medium or tall shadows.
- The learned generalization is better understood as an encoded generalization rather than a directly visible one.
- The network’s internal responses do not make it clear why it recognizes particular categories, although substantial work has investigated how to interpret such behavior.
- Encoded representations help explain why neural networks can be effective while remaining difficult to understand.

**Qualification**

> The supplied explanation introduces the autoencoding construction and its implications, but its further implications remain unresolved in the supplied span.

Lecture reference: 8:33–17:18, 17:18–24:45

## Layer-wise representation training

> In an autocoding approach, representations are trained successively from the input layer upward. The network first accumulates knowledge about the environment, then uses labeled examples of particular classes to train the final classification layer. Boltzmann machines share essentially the same general idea.

### Successive layer training

After training the input layer, its representation can be used to train the next layer. This process continues layer by layer, building representations upward from the input.

### Transition to classification

The network first accumulates knowledge about the environment. At the final stage, examples of particular classes are used to train the classification layer.

### Related model

Boltzmann machines are presented as sharing essentially the same general idea.

Lecture reference: 24:45–33:47

## Sigmoid models and maximum-likelihood training

> A sigmoid output neuron combines an input with a weight and threshold to produce a value related to class probability. Maximum-likelihood training adjusts the weight and threshold so the observed positive and negative labels become more probable.

### Sigmoid output

A final output neuron combines an input x with a weight w and threshold T, then passes the result through a sigmoid to produce an output z. The output value can be interpreted as related to the probability that an input belongs to a class.

**Sigmoid model**

```latex
z = \frac{1}{1 + e^{-wx + T}}
```

The output z depends on the input x, weight w, and threshold T.

**Effects of the parameters**

- Changing the threshold shifts the sigmoid horizontally, changing where its transition occurs.
- Changing the weight changes the steepness of the sigmoid.

### Likelihood of labeled data

The weight and threshold are selected to maximize the probability of the observed labeled data under the sigmoid model. The likelihood depends on the curve’s shape, and the curve’s shape depends on w and T.

**Probabilities for labeled examples**

- Positive examples receive probabilities corresponding to the sigmoid value at their inputs.
- For negative examples, the probability is represented by one minus the sigmoid value.

**Parameter adjustment**

Maximizing the likelihood requires adjusting w and T using partial derivatives and related optimization calculations. As the curve is adjusted, the probability of the positive examples increases while the probability of the non-example decreases.

### Gradient-ascent demonstration

**Demonstration process**

1. Begin with an ordinary sigmoid.
2. Add positive and negative examples.
3. Apply gradient ascent to modify the curve so the observed labels become more probable.

**Effects of added examples**

Positive and negative sample locations determine how the sigmoid should shift and steepen so that positive samples receive higher probabilities and negative samples receive lower probabilities. Adding a negative example in a relatively compatible location may cause little change, while adding a positive example in a location inconsistent with the current curve can produce a dramatic shift.

**Possible noise**

> A potentially anomalous positive point is described as possibly being noise. Additional negative examples can then adjust the curve in response.

Lecture reference: 24:45–33:47

## Multiclass outputs and softmax training

> For many-class problems, each output neuron represents one class. Softmax normalizes the class outputs so they can be interpreted as probabilities for all possible classifications, while separate output-layer training aligns those outputs with the desired classifications.

### Outputs for many classes

A problem with many classes uses one output neuron for each class. For example, a problem with 1,000 classes has 1,000 output neurons. Each output is associated with one class and should be higher when the input belongs to that class.

- The desired interpretation is a probability for each class, rather than only a winner-takes-all choice based on the largest output.
- Test outputs can indicate one likely object while also assigning probabilities to several other possible classifications.
- Softmax supports probabilities for multiple possible classifications, such as first, second, third, fourth, and fifth candidates.

### Normalization with softmax

A sigmoid-like output for each class is not, by itself, a normalized probability. The earlier interpretation of sigmoid outputs as probabilities requires an additional normalization step. Softmax divides each class output by the sum of the outputs for all classes, producing a probability for every possible classification rather than selecting only the maximum.

```latex
p_1 = \frac{\text{sigmoid output for class 1}}{\sum_{j=1}^{K} \text{sigmoid output for class } j}
```

The numerator is the output for class 1, and the denominator is the sum of the outputs for all classes.

> The lecture first introduces the multiclass probability idea without yet specifying the normalization or probability function; the later description identifies this normalization as softmax.

### Training the output layer

1. Train the hidden layer first, then detach it from its original output layer while retaining the weights connecting the input to the hidden layer.
2. Freeze the trained input-to-hidden weights initially and leave the new output layer untrained.
3. Because the output layer is untrained, test samples produce one-half for each of two categories, despite the trained middle layer.
4. Train the outer layer with the sigmoid-based output mechanism so that its outputs align with the desired classifications.
5. After a short training run, the outputs show an extraordinarily good match with the desired outputs.

This procedure is presented as a combination of the autocoding idea and the softmax idea.

Lecture reference: 24:45–33:47, 33:47–42:10

## Dropout, width, and optimization behavior in deep networks

> Dropout randomly removes neurons during training, changing the network configuration from one iteration to the next. The lecture presents this as a way to reduce convergence to a frozen local maximum. It also contrasts networks that are wide and shallow with narrower versions: widening can turn local maxima into saddle points, allowing optimization to continue through the search space.

### Dropout during training

For each neuron on each training iteration, a coin flip determines whether it remains active. A neuron selected for removal has no influence on that iteration’s output, and a different set of neurons may be removed on the next iteration. The changing configuration is described as helping prevent convergence to a frozen local maximum.

- One iteration may omit one set of neurons, while the next iteration omits a different set.
- A removed neuron has no influence on the output for that iteration.
- The changing network configuration is described as helping prevent convergence to a frozen local maximum.

### Depth, width, and training approaches

The lecturer suggests that “wide nets” may be a more accurate description of networks commonly called deep. They can be enormously wide but are often fewer than ten columns deep. Despite probability-based output layers and approaches such as autocoding or Boltzmann machines, ordinary backpropagation with a convolutional network may perform about as well as the more elaborate alternatives.

- Networks called deep are often very wide and rarely exceed about ten columns in depth.
- The current state of the art is characterized as showing limited practical benefit from some added output-layer and pretraining sophistication relative to plain backpropagation.
- Backpropagation combined with a convolutional network is described as performing about as well as the more elaborate alternatives.

### Five-column animal-classification demonstration

A classroom network with five columns, each containing approximately nine or ten neurons, is trained to classify an animal as a cheetah, zebra, or giraffe using the height of its shadow. The network therefore has substantially more parameters than the earlier example. Green indicates a positive output and red a negative output.

1. Before training, every test sample produces an output of 1/2, regardless of the animal.
2. During early training, the output region turns red. This is interpreted as the network choosing “no” for every animal while uncertain among many possibilities.
3. After approximately 160,000 iterations, the network performs well on the test samples.

Repeated runs show a long period with little apparent progress followed by a rapid decline in the error rate. The lecture raises the unresolved question of what would happen if the network were less wide.

### Removing neurons and retraining

In a variation on dropout, one neuron in each column is killed and reassigned to another purpose. The network then has one fewer neuron per column and is retrained. The first retraining run reaches a good solution very quickly. In repeated runs, the error may rise somewhat initially but then quickly falls to a solution.

- Removing one neuron from every column still allows rapid recovery of a working classification solution.
- Repeated retraining runs may rise somewhat initially and then quickly fall to a solution.
- The transcript ends while the lecturer is considering repeated neuron removal and retraining.

### Width and local maxima

- A network was trained successfully even after being reduced to two neurons in each column.
- When the network was initialized with only two neurons in each column before training, it appeared to become stuck in a local maximum.
- The lecture presents widening the network as a breakthrough because it can turn local maxima into saddle points.
- At a saddle point, optimization can continue crawling through the large search space instead of remaining trapped at a local maximum.

The experiments show that the same architecture can behave differently depending on whether neurons are removed before or after training. A network can first find a solution and then remain successful after reduction, whereas starting with the reduced width can leave training stuck at a local maximum.

Lecture reference: 33:47–42:10, 42:10–49:00

## Limits of neural-network visual understanding

> Neural networks can classify images successfully while relying on local positive and negative evidence rather than recognizing objects, activities, and situations in a human-like way. Small pixel changes can alter classifications, and heavily altered images can retain a network’s label even when people interpret them differently.

### Sensitivity to small pixel changes

Neural-network classifications can be changed by very small pixel modifications that humans do not notice. The lecture interprets this as evidence that the network aggregates local negative and positive evidence rather than recognizing objects in a human-like way.

- A small number of changed pixels can reduce a network’s high confidence that an image depicts a school bus and cause it to classify the image differently.
- The proposed explanation is that the network gathers enough local evidence against the other 999 classes and enough positive local evidence for the school-bus class.
- Some altered images may contain texture associated with a class, such as baseball texture, even when the overall object is not recognizable to a person.
- Online tools allow users to submit their own images and observe neural-network behavior.
- The lecture describes a body of published work that deliberately fools neural networks.

In one example, a school-bus image was modified in ways that were not visibly apparent to people, yet the network changed from high confidence in the school-bus classification to rejecting that class.

### Captioning without conceptual understanding

Image-captioning systems can produce plausible labels or descriptions without understanding the activities, objects, or situations that humans associate with an image. A prominent Google paper used related ideas to generate captions for pictures.

- The apparent sophistication of captions has contributed to concern about artificial intelligence because viewers may mistake labeling ability for conceptual understanding.
- The lecture emphasizes that the system knows how to label an image, not what it is like to play, be young, move, or use a Frisbee.
- The paper included examples where captions were only partially correct or misleading, such as identifying a cat without lying about it, or identifying a girl without recognizing that she was blowing bubbles.

The lecture contrasts a picture caption that identifies a girl with the incorrect implication that she is blowing bubbles, illustrating that object or person recognition does not guarantee understanding of the depicted action.

### Removing frequency-band information

The lecture describes an experiment in which images were decomposed into frequency-band slices. A rectangular region was removed from one band, and the remaining components were reassembled. The amount of information removed was increased while preserving the neural network’s original classification.

1. Separate each image into slices representing particular frequency bands.
2. Remove a rectangle from one frequency band.
3. Reassemble the remaining components.
4. Increase the amount of removed information while retaining the network’s original impression of the image.
5. Compare the network’s classification with human interpretations of the altered image.

> If no region had been removed, reconstruction would have reproduced the starting image exactly. The experiment removed as much information as possible while retaining the neural network’s original impression of the image.

### Different network classifications and human interpretations

- An image classified by the network as a railroad car was heavily altered while retaining that classification.
- A guitar image could not be mutilated as extensively while preserving the network’s guitar classification.
- An image recognized by the network as a barbell was interpreted by people as a lamp or toilet.
- Other altered images retained classifications such as grasshopper, two nearby wolves rather than a two-headed wolf, rabbit, and Russian wolfhound even though the human interpretations differed.

Human viewers frequently supplied different interpretations from the neural network’s classification. The overall conclusion is that neural networks are powerful engineering systems but do not see as humans see.

Lecture reference: 42:10–49:00

<!-- ocw-attribution -->
## Source and license

Patrick Henry Winston. 6.034 — Lecture 12B: Deep Neural Nets. MIT OpenCourseWare, Massachusetts Institute of Technology.

[Original lecture](https://www.youtube.com/watch?v=VrMHA3yX_QI) · [MIT OCW source](https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/resources/lecture-12b-deep-neural-nets/)

Source and these adapted notes: [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/). Noncommercial use; share adaptations under the same license.

Changes: AI-generated study notes adapted from the lecture; transcript source: manual captions. May contain errors. MIT and the instructors do not endorse these notes.

OCW materials unless otherwise marked; separately credited third-party material may have different terms. [OCW terms](https://ocw.mit.edu/pages/privacy-and-terms-of-use/).
